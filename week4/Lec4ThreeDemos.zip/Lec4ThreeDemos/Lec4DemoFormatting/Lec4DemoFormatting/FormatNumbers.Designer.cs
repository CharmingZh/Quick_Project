﻿namespace Lec4DemoFormatting
{
    partial class FrmFormatNumbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblDisplay = new System.Windows.Forms.Label();
            this.BtnAussieShort = new System.Windows.Forms.Button();
            this.BtnMakeDate = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TbxYear = new System.Windows.Forms.TextBox();
            this.TbxMonth = new System.Windows.Forms.TextBox();
            this.TbxDay = new System.Windows.Forms.TextBox();
            this.BtnAussieMedium = new System.Windows.Forms.Button();
            this.BtnShortFormat = new System.Windows.Forms.Button();
            this.BtnLongFormat = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TbxInteger = new System.Windows.Forms.TextBox();
            this.BtnMultiple = new System.Windows.Forms.Button();
            this.BtnFloat = new System.Windows.Forms.Button();
            this.TbxFloat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TbxResult = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TbxSpecifier = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnInteger = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblDisplay
            // 
            this.LblDisplay.AutoSize = true;
            this.LblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblDisplay.Location = new System.Drawing.Point(20, 273);
            this.LblDisplay.MinimumSize = new System.Drawing.Size(260, 20);
            this.LblDisplay.Name = "LblDisplay";
            this.LblDisplay.Size = new System.Drawing.Size(260, 20);
            this.LblDisplay.TabIndex = 27;
            this.LblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnAussieShort
            // 
            this.BtnAussieShort.Location = new System.Drawing.Point(54, 232);
            this.BtnAussieShort.Name = "BtnAussieShort";
            this.BtnAussieShort.Size = new System.Drawing.Size(86, 23);
            this.BtnAussieShort.TabIndex = 20;
            this.BtnAussieShort.Text = "Aussie short";
            this.BtnAussieShort.UseVisualStyleBackColor = true;
            this.BtnAussieShort.Click += new System.EventHandler(this.BtnAussieShort_Click);
            // 
            // BtnMakeDate
            // 
            this.BtnMakeDate.Location = new System.Drawing.Point(122, 134);
            this.BtnMakeDate.Name = "BtnMakeDate";
            this.BtnMakeDate.Size = new System.Drawing.Size(86, 23);
            this.BtnMakeDate.TabIndex = 18;
            this.BtnMakeDate.Text = "Make date";
            this.BtnMakeDate.UseVisualStyleBackColor = true;
            this.BtnMakeDate.Click += new System.EventHandler(this.BtnMakeDate_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Enter the year";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(73, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Enter the month";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(82, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Enter the day";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxYear
            // 
            this.TbxYear.Location = new System.Drawing.Point(167, 108);
            this.TbxYear.Name = "TbxYear";
            this.TbxYear.Size = new System.Drawing.Size(100, 20);
            this.TbxYear.TabIndex = 17;
            // 
            // TbxMonth
            // 
            this.TbxMonth.Location = new System.Drawing.Point(167, 71);
            this.TbxMonth.Name = "TbxMonth";
            this.TbxMonth.Size = new System.Drawing.Size(100, 20);
            this.TbxMonth.TabIndex = 16;
            // 
            // TbxDay
            // 
            this.TbxDay.Location = new System.Drawing.Point(167, 35);
            this.TbxDay.Name = "TbxDay";
            this.TbxDay.Size = new System.Drawing.Size(100, 20);
            this.TbxDay.TabIndex = 15;
            // 
            // BtnAussieMedium
            // 
            this.BtnAussieMedium.Location = new System.Drawing.Point(167, 232);
            this.BtnAussieMedium.Name = "BtnAussieMedium";
            this.BtnAussieMedium.Size = new System.Drawing.Size(86, 23);
            this.BtnAussieMedium.TabIndex = 23;
            this.BtnAussieMedium.Text = "Unambiguous";
            this.BtnAussieMedium.UseVisualStyleBackColor = true;
            this.BtnAussieMedium.Click += new System.EventHandler(this.BtnAussieMedium_Click);
            // 
            // BtnShortFormat
            // 
            this.BtnShortFormat.Location = new System.Drawing.Point(167, 203);
            this.BtnShortFormat.Name = "BtnShortFormat";
            this.BtnShortFormat.Size = new System.Drawing.Size(86, 23);
            this.BtnShortFormat.TabIndex = 22;
            this.BtnShortFormat.Text = "Shorter format";
            this.BtnShortFormat.UseVisualStyleBackColor = true;
            this.BtnShortFormat.Click += new System.EventHandler(this.BtnShortFormat_Click);
            // 
            // BtnLongFormat
            // 
            this.BtnLongFormat.Location = new System.Drawing.Point(54, 203);
            this.BtnLongFormat.Name = "BtnLongFormat";
            this.BtnLongFormat.Size = new System.Drawing.Size(86, 23);
            this.BtnLongFormat.TabIndex = 21;
            this.BtnLongFormat.Text = "Long format";
            this.BtnLongFormat.UseVisualStyleBackColor = true;
            this.BtnLongFormat.Click += new System.EventHandler(this.BtnLongFormat_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.LblDisplay);
            this.groupBox2.Controls.Add(this.BtnAussieShort);
            this.groupBox2.Controls.Add(this.BtnMakeDate);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.TbxYear);
            this.groupBox2.Controls.Add(this.TbxMonth);
            this.groupBox2.Controls.Add(this.TbxDay);
            this.groupBox2.Controls.Add(this.BtnAussieMedium);
            this.groupBox2.Controls.Add(this.BtnShortFormat);
            this.groupBox2.Controls.Add(this.BtnLongFormat);
            this.groupBox2.Location = new System.Drawing.Point(342, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(300, 329);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Date formats";
            // 
            // TbxInteger
            // 
            this.TbxInteger.Location = new System.Drawing.Point(21, 33);
            this.TbxInteger.Name = "TbxInteger";
            this.TbxInteger.Size = new System.Drawing.Size(125, 20);
            this.TbxInteger.TabIndex = 1;
            this.TbxInteger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnMultiple
            // 
            this.BtnMultiple.Location = new System.Drawing.Point(218, 130);
            this.BtnMultiple.Name = "BtnMultiple";
            this.BtnMultiple.Size = new System.Drawing.Size(75, 23);
            this.BtnMultiple.TabIndex = 10;
            this.BtnMultiple.Text = "Multiple";
            this.BtnMultiple.UseVisualStyleBackColor = true;
            this.BtnMultiple.Click += new System.EventHandler(this.BtnMultiple_Click);
            // 
            // BtnFloat
            // 
            this.BtnFloat.Location = new System.Drawing.Point(119, 130);
            this.BtnFloat.Name = "BtnFloat";
            this.BtnFloat.Size = new System.Drawing.Size(75, 23);
            this.BtnFloat.TabIndex = 9;
            this.BtnFloat.Text = "Float";
            this.BtnFloat.UseVisualStyleBackColor = true;
            this.BtnFloat.Click += new System.EventHandler(this.BtnFloat_Click);
            // 
            // TbxFloat
            // 
            this.TbxFloat.Location = new System.Drawing.Point(169, 33);
            this.TbxFloat.Name = "TbxFloat";
            this.TbxFloat.Size = new System.Drawing.Size(124, 20);
            this.TbxFloat.TabIndex = 2;
            this.TbxFloat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Output";
            // 
            // TbxResult
            // 
            this.TbxResult.Location = new System.Drawing.Point(67, 208);
            this.TbxResult.Multiline = true;
            this.TbxResult.Name = "TbxResult";
            this.TbxResult.Size = new System.Drawing.Size(166, 56);
            this.TbxResult.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Specifier";
            // 
            // TbxSpecifier
            // 
            this.TbxSpecifier.Location = new System.Drawing.Point(21, 88);
            this.TbxSpecifier.Name = "TbxSpecifier";
            this.TbxSpecifier.Size = new System.Drawing.Size(272, 20);
            this.TbxSpecifier.TabIndex = 4;
            this.TbxSpecifier.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(210, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Float";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Integer";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TbxInteger);
            this.groupBox1.Controls.Add(this.BtnMultiple);
            this.groupBox1.Controls.Add(this.BtnInteger);
            this.groupBox1.Controls.Add(this.BtnFloat);
            this.groupBox1.Controls.Add(this.TbxFloat);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.TbxResult);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.TbxSpecifier);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(306, 329);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Number formats";
            // 
            // BtnInteger
            // 
            this.BtnInteger.Location = new System.Drawing.Point(21, 130);
            this.BtnInteger.Name = "BtnInteger";
            this.BtnInteger.Size = new System.Drawing.Size(75, 23);
            this.BtnInteger.TabIndex = 0;
            this.BtnInteger.Text = "Integer";
            this.BtnInteger.UseVisualStyleBackColor = true;
            this.BtnInteger.Click += new System.EventHandler(this.BtnInteger_Click);
            // 
            // FrmFormatNumbers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 352);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmFormatNumbers";
            this.Text = "Numeric format specifiers";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label LblDisplay;
        internal System.Windows.Forms.Button BtnAussieShort;
        internal System.Windows.Forms.Button BtnMakeDate;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.TextBox TbxYear;
        internal System.Windows.Forms.TextBox TbxMonth;
        internal System.Windows.Forms.TextBox TbxDay;
        internal System.Windows.Forms.Button BtnAussieMedium;
        internal System.Windows.Forms.Button BtnShortFormat;
        internal System.Windows.Forms.Button BtnLongFormat;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TbxInteger;
        private System.Windows.Forms.Button BtnMultiple;
        private System.Windows.Forms.Button BtnFloat;
        private System.Windows.Forms.TextBox TbxFloat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TbxResult;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TbxSpecifier;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnInteger;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec4DemoFormatting
{
    public partial class FrmFormatNumbers : Form
    {
        // Simon, May 2015
        // Last updated August 2021
        // Explore some of the number format specifiers in String.Format
        // Also some of the date formatting options

        // This is an instance (class-level) variable, used in several methods
        private DateTime dtmDate;

        public FrmFormatNumbers()
        {
            InitializeComponent();
        }

        private void BtnInteger_Click(object sender, EventArgs e)
        {
            // Format the integer according to the specifier
            // Notice how the format string is made up from the entered text and the other components
            int iNumber = Convert.ToInt32(TbxInteger.Text);
            string sFormat = "{0:" + TbxSpecifier.Text + "}";
            TbxResult.Text = String.Format(sFormat, iNumber);
        }

        private void BtnFloat_Click(object sender, EventArgs e)
        {
            // Format the double according to the specifier
            double dNumber = Convert.ToDouble(TbxFloat.Text);
            string sFormat = "{0:" + TbxSpecifier.Text + "}";
            TbxResult.Text = String.Format(sFormat, dNumber);
        }

        private void BtnMultiple_Click(object sender, EventArgs e)
        {
            // Format three particular numbers - after filling the input textboxes
            TbxInteger.Text = "17";
            TbxFloat.Text = "1.68742 & 72.45677";
            TbxSpecifier.Text = "You are {0:d} years old, {1:n}m tall, and you weigh {2:n1} kilos.";
            int iAge = 17; double dHeight = 1.68742; double dWeight = 72.45677;
            TbxResult.Text = String.Format("You are {0:d} years old, {1:n}m tall, and you weigh {2:n1} kilos.", iAge, dHeight, dWeight);
        }

        private void BtnMakeDate_Click(object sender, EventArgs e)
        {
            // Convert the 3 textbox values to a date and display it

            // These variables are 'local', existing only in this handler, because they're not needed once
            // the handler finishes.

            int iYear = Convert.ToInt32(TbxYear.Text);
            int iMonth = Convert.ToInt32(TbxMonth.Text);
            int iDay = Convert.ToInt32(TbxDay.Text);
            dtmDate = new DateTime(iYear, iMonth, iDay);

            // After adding DtpInDate to the form, uncomment the next two lines and comment all above
            //dtmDate = DtpInDate.Value;
            //MessageBox.Show("You selected " + DtpInDate.Text);

            LblDisplay.Text = Convert.ToString(dtmDate);

        }  // end BtnMakeDate_Click

        private void BtnLongFormat_Click(object sender, EventArgs e)
        {
            // Display the date with full day name, day, full month name, and 4-digit year
            LblDisplay.Text = String.Format("{0:dddd d MMMM yyyy}", dtmDate);
        }

        private void BtnShortFormat_Click(object sender, EventArgs e)
        {
            // Display the date with short day name, day, short month name, and 4-digit year
            LblDisplay.Text = String.Format("{0:ddd d MMM yyyy}", dtmDate);
        }

        private void BtnAussieShort_Click(object sender, EventArgs e)
        {
            // Display the date with 2-digit day, 2-digit month, and 2-digit year
            LblDisplay.Text = String.Format("{0:dd/MM/yy}", dtmDate);
        }

        private void BtnAussieMedium_Click(object sender, EventArgs e)
        {
            // Display the date with day, short month name, and 2-digit year
            LblDisplay.Text = String.Format("{0:d MMM yy}", dtmDate);
        }
    }  // end class
}  // end namespace

﻿namespace Lec4DemoCarpark
{
    partial class FrmCarpark
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TmrEvacuate = new System.Windows.Forms.Timer(this.components);
            this.LblEvacuate = new System.Windows.Forms.Label();
            this.BtnEmergency = new System.Windows.Forms.Button();
            this.TkbarFullness = new System.Windows.Forms.TrackBar();
            this.LblCarParkFull = new System.Windows.Forms.Label();
            this.BtnLeaving = new System.Windows.Forms.Button();
            this.BtnArriving = new System.Windows.Forms.Button();
            this.TbxVacantSpaces = new System.Windows.Forms.TextBox();
            this.LblSpaces = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TkbarFullness)).BeginInit();
            this.SuspendLayout();
            // 
            // TmrEvacuate
            // 
            this.TmrEvacuate.Interval = 3000;
            this.TmrEvacuate.Tick += new System.EventHandler(this.TmrEvacuate_Tick);
            // 
            // LblEvacuate
            // 
            this.LblEvacuate.AutoSize = true;
            this.LblEvacuate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEvacuate.ForeColor = System.Drawing.Color.Red;
            this.LblEvacuate.Location = new System.Drawing.Point(45, 144);
            this.LblEvacuate.Name = "LblEvacuate";
            this.LblEvacuate.Size = new System.Drawing.Size(127, 13);
            this.LblEvacuate.TabIndex = 39;
            this.LblEvacuate.Text = "Evacuate! Evacuate!";
            this.LblEvacuate.Visible = false;
            // 
            // BtnEmergency
            // 
            this.BtnEmergency.BackColor = System.Drawing.Color.OrangeRed;
            this.BtnEmergency.Location = new System.Drawing.Point(213, 168);
            this.BtnEmergency.Name = "BtnEmergency";
            this.BtnEmergency.Size = new System.Drawing.Size(140, 23);
            this.BtnEmergency.TabIndex = 38;
            this.BtnEmergency.Text = "Press in emergency";
            this.BtnEmergency.UseVisualStyleBackColor = false;
            this.BtnEmergency.Click += new System.EventHandler(this.BtnEmergency_Click);
            // 
            // TkbarFullness
            // 
            this.TkbarFullness.Location = new System.Drawing.Point(32, 93);
            this.TkbarFullness.Maximum = 200;
            this.TkbarFullness.Name = "TkbarFullness";
            this.TkbarFullness.Size = new System.Drawing.Size(304, 45);
            this.TkbarFullness.TabIndex = 37;
            this.TkbarFullness.Scroll += new System.EventHandler(this.TkbarFullness_Scroll);
            // 
            // LblCarParkFull
            // 
            this.LblCarParkFull.BackColor = System.Drawing.Color.PeachPuff;
            this.LblCarParkFull.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.LblCarParkFull.Location = new System.Drawing.Point(56, 213);
            this.LblCarParkFull.Name = "LblCarParkFull";
            this.LblCarParkFull.Size = new System.Drawing.Size(272, 32);
            this.LblCarParkFull.TabIndex = 36;
            this.LblCarParkFull.Text = "CAR PARK IS FULL";
            this.LblCarParkFull.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LblCarParkFull.Visible = false;
            // 
            // BtnLeaving
            // 
            this.BtnLeaving.Location = new System.Drawing.Point(216, 21);
            this.BtnLeaving.Name = "BtnLeaving";
            this.BtnLeaving.Size = new System.Drawing.Size(96, 48);
            this.BtnLeaving.TabIndex = 35;
            this.BtnLeaving.Text = "Car Leaving";
            this.BtnLeaving.Click += new System.EventHandler(this.BtnLeaving_Click);
            // 
            // BtnArriving
            // 
            this.BtnArriving.Location = new System.Drawing.Point(56, 21);
            this.BtnArriving.Name = "BtnArriving";
            this.BtnArriving.Size = new System.Drawing.Size(88, 48);
            this.BtnArriving.TabIndex = 34;
            this.BtnArriving.Text = "Car Arriving";
            this.BtnArriving.Click += new System.EventHandler(this.BtnArriving_Click);
            // 
            // TbxVacantSpaces
            // 
            this.TbxVacantSpaces.Location = new System.Drawing.Point(141, 168);
            this.TbxVacantSpaces.Name = "TbxVacantSpaces";
            this.TbxVacantSpaces.Size = new System.Drawing.Size(40, 20);
            this.TbxVacantSpaces.TabIndex = 33;
            this.TbxVacantSpaces.Text = "200";
            // 
            // LblSpaces
            // 
            this.LblSpaces.Location = new System.Drawing.Point(21, 168);
            this.LblSpaces.Name = "LblSpaces";
            this.LblSpaces.Size = new System.Drawing.Size(112, 24);
            this.LblSpaces.TabIndex = 32;
            this.LblSpaces.Text = "Vacant car spaces:";
            this.LblSpaces.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FrmCarpark
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 267);
            this.Controls.Add(this.LblEvacuate);
            this.Controls.Add(this.BtnEmergency);
            this.Controls.Add(this.TkbarFullness);
            this.Controls.Add(this.LblCarParkFull);
            this.Controls.Add(this.BtnLeaving);
            this.Controls.Add(this.BtnArriving);
            this.Controls.Add(this.TbxVacantSpaces);
            this.Controls.Add(this.LblSpaces);
            this.Name = "FrmCarpark";
            this.Text = "The car park";
            ((System.ComponentModel.ISupportInitialize)(this.TkbarFullness)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Timer TmrEvacuate;
        internal System.Windows.Forms.Label LblEvacuate;
        internal System.Windows.Forms.Button BtnEmergency;
        internal System.Windows.Forms.TrackBar TkbarFullness;
        internal System.Windows.Forms.Label LblCarParkFull;
        internal System.Windows.Forms.Button BtnLeaving;
        internal System.Windows.Forms.Button BtnArriving;
        internal System.Windows.Forms.TextBox TbxVacantSpaces;
        internal System.Windows.Forms.Label LblSpaces;
    }
}


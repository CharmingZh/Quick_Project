﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec4DemoCarpark
{
    // Simon, May 2007
    // Last updated August 2021
    // Inft2012 lecture illustrating Random, track bars, timers, and a few other features

    public partial class FrmCarpark : Form
    {
        // Instance variables
        private int iMaxSpaces = 200; // Car park size
        private int iSpaceCount = 200; // Initial number of free spaces
        Random rndChance = new Random();

        public FrmCarpark()
        {
            InitializeComponent();
        }

        private void BtnArriving_Click(object sender, EventArgs e)
        {
            // Simulates a car arriving at the car park
            if (iSpaceCount == 0)
            {
                // There are no vacant spaces
                // The car cannot enter or park so do not decrement iSpaceCount
                MessageBox.Show("Sorry, there's no room!", "Car park full");
            }
            else
            {
                // There are still vacant spaces
                iSpaceCount = iSpaceCount - 1;
                TbxVacantSpaces.Text = Convert.ToString(iSpaceCount);
                TkbarFullness.Value = iMaxSpaces - iSpaceCount;

                // Check to see if this was the last vacant space
                // If so, display the CAR PARK FULL sign
                if (iSpaceCount == 0)
                {
                    LblCarParkFull.Visible = true;
                }  // end inner if
            }  // end outer if
        }  // end BtnArriving_Click

        private void BtnLeaving_Click(object sender, EventArgs e)
        {
            // Simulates a car leaving the car park
            // Check to see if the car park was full
            // If so, turn off the CAR PARK FULL sign, ie
            //    set the Visible property of lblFullCarPark to false
            if (LblCarParkFull.Visible)
            {
                LblCarParkFull.Visible = false;
            }
            // allocate another vacant space (up to the limit)
            if (iSpaceCount < iMaxSpaces)
            {
                iSpaceCount = iSpaceCount + 1;
                TbxVacantSpaces.Text = Convert.ToString(iSpaceCount);
                TkbarFullness.Value = iMaxSpaces - iSpaceCount;
            }  // end second if
        }  // end BtnLeaving_Click

        private void TkbarFullness_Scroll(object sender, EventArgs e)
        {
            // If the trackbar is scrolled, adjust the carcount and consequences
            iSpaceCount = iMaxSpaces - TkbarFullness.Value;
            TbxVacantSpaces.Text = Convert.ToString(iSpaceCount);
            // Look carefully at this boolean assignment statement;
            // most programmers would code it unnecessarily as an If statement.
            LblCarParkFull.Visible = iSpaceCount == 0;
        }  // end TkbarFullness_Scroll

        #region Emergency procedure
        private void BtnEmergency_Click(object sender, EventArgs e)
        {
            // Start the timer that controls an emergency evacuation
            TmrEvacuate.Interval = 3000; // Start tick interval at 3sec (3000ms)
            TmrEvacuate.Start();
            // The Evacuate label turns on
            LblEvacuate.Visible = true;
        }  // end BtnEmergency_Click

        private void TmrEvacuate_Tick(object sender, EventArgs e)
        {
            // Each time the timer ticks . . .
            // . . . a car leaves . . .
            if (LblCarParkFull.Visible)
            {
                LblCarParkFull.Visible = false;
            }
            // The Evacuate label flashes on or off
            LblEvacuate.Visible = !LblEvacuate.Visible;

            if (iSpaceCount < iMaxSpaces)
            {
                iSpaceCount = iSpaceCount + 1;
                TbxVacantSpaces.Text = Convert.ToString(iSpaceCount);
                TkbarFullness.Value = iMaxSpaces - iSpaceCount;
            }
            // . . . the tick interval is reduced a little
            TmrEvacuate.Interval = TmrEvacuate.Interval * 15 / 16;
            // . . . and if it's dropped to less than 2 . . .
            if (TmrEvacuate.Interval < 2)
            {
                TmrEvacuate.Stop();
                // Simon's 9-year-old son Calum suggested this addition - a 15% chance of it being a false alarm
                if (rndChance.NextDouble() < 0.15)
                {
                    MessageBox.Show("You can stop evacuating - it was a false alarm!", "Panic's over");
                }
                // The rest was in the original
                else if (iSpaceCount < iMaxSpaces)
                {
                    MessageBox.Show("Too late!", "Kaboom!");
                }
                else
                {
                    MessageBox.Show("Phew - everyone got out!", "Kaboom!");
                }
            }  // end if
        }  // end TmrEvacuate_Tick
        #endregion

    }  // end class
}  // end namespace

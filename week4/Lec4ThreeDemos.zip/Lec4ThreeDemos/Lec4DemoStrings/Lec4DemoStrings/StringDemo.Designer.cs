﻿namespace Lec4DemoStrings
{
    partial class FrmStringDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCompare = new System.Windows.Forms.Button();
            this.BtnSubstringOnward = new System.Windows.Forms.Button();
            this.BtnSubstringSize = new System.Windows.Forms.Button();
            this.BtnLastIndexOf = new System.Windows.Forms.Button();
            this.BtnIndexOf = new System.Windows.Forms.Button();
            this.BtnRemove = new System.Windows.Forms.Button();
            this.BtnInsert = new System.Windows.Forms.Button();
            this.BtnS2ToLower = new System.Windows.Forms.Button();
            this.BtnS1ToUpper = new System.Windows.Forms.Button();
            this.TbxNumber2 = new System.Windows.Forms.TextBox();
            this.LblNum2 = new System.Windows.Forms.Label();
            this.BtnElementN1S1 = new System.Windows.Forms.Button();
            this.TbxNumber1 = new System.Windows.Forms.TextBox();
            this.TbxString2 = new System.Windows.Forms.TextBox();
            this.TbxString1 = new System.Windows.Forms.TextBox();
            this.LblNum1 = new System.Windows.Forms.Label();
            this.LblStr2 = new System.Windows.Forms.Label();
            this.LblStr1 = new System.Windows.Forms.Label();
            this.BtnConcatenate = new System.Windows.Forms.Button();
            this.TbxOutput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnCompare
            // 
            this.BtnCompare.Location = new System.Drawing.Point(129, 138);
            this.BtnCompare.Name = "BtnCompare";
            this.BtnCompare.Size = new System.Drawing.Size(104, 23);
            this.BtnCompare.TabIndex = 96;
            this.BtnCompare.Text = "Compare";
            this.BtnCompare.UseVisualStyleBackColor = true;
            this.BtnCompare.Click += new System.EventHandler(this.BtnCompare_Click);
            // 
            // BtnSubstringOnward
            // 
            this.BtnSubstringOnward.Location = new System.Drawing.Point(17, 412);
            this.BtnSubstringOnward.Name = "BtnSubstringOnward";
            this.BtnSubstringOnward.Size = new System.Drawing.Size(216, 40);
            this.BtnSubstringOnward.TabIndex = 95;
            this.BtnSubstringOnward.Text = "Substring of String 1 from index Number 1 onward";
            this.BtnSubstringOnward.Click += new System.EventHandler(this.BtnSubstringOnward_Click);
            // 
            // BtnSubstringSize
            // 
            this.BtnSubstringSize.Location = new System.Drawing.Point(17, 363);
            this.BtnSubstringSize.Name = "BtnSubstringSize";
            this.BtnSubstringSize.Size = new System.Drawing.Size(216, 40);
            this.BtnSubstringSize.TabIndex = 94;
            this.BtnSubstringSize.Text = "Substring of String 1 at index Number 1 of size Number 2";
            this.BtnSubstringSize.Click += new System.EventHandler(this.BtnSubstringSize_Click);
            // 
            // BtnLastIndexOf
            // 
            this.BtnLastIndexOf.Location = new System.Drawing.Point(17, 331);
            this.BtnLastIndexOf.Name = "BtnLastIndexOf";
            this.BtnLastIndexOf.Size = new System.Drawing.Size(216, 23);
            this.BtnLastIndexOf.TabIndex = 93;
            this.BtnLastIndexOf.Text = "LastIndexOf String 2 in String 1";
            this.BtnLastIndexOf.Click += new System.EventHandler(this.BtnLastIndexOf_Click);
            // 
            // BtnIndexOf
            // 
            this.BtnIndexOf.Location = new System.Drawing.Point(17, 299);
            this.BtnIndexOf.Name = "BtnIndexOf";
            this.BtnIndexOf.Size = new System.Drawing.Size(216, 23);
            this.BtnIndexOf.TabIndex = 92;
            this.BtnIndexOf.Text = "IndexOf String 2 in String 1";
            this.BtnIndexOf.Click += new System.EventHandler(this.BtnIndexOf_Click);
            // 
            // BtnRemove
            // 
            this.BtnRemove.Location = new System.Drawing.Point(17, 267);
            this.BtnRemove.Name = "BtnRemove";
            this.BtnRemove.Size = new System.Drawing.Size(216, 23);
            this.BtnRemove.TabIndex = 91;
            this.BtnRemove.Text = "Remove Num2 from Str1 at index Num1";
            this.BtnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // BtnInsert
            // 
            this.BtnInsert.Location = new System.Drawing.Point(17, 235);
            this.BtnInsert.Name = "BtnInsert";
            this.BtnInsert.Size = new System.Drawing.Size(216, 23);
            this.BtnInsert.TabIndex = 90;
            this.BtnInsert.Text = "Insert Str2 before index Num1 of Str1";
            this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
            // 
            // BtnS2ToLower
            // 
            this.BtnS2ToLower.Location = new System.Drawing.Point(129, 203);
            this.BtnS2ToLower.Name = "BtnS2ToLower";
            this.BtnS2ToLower.Size = new System.Drawing.Size(104, 23);
            this.BtnS2ToLower.TabIndex = 89;
            this.BtnS2ToLower.Text = "String 1 ToLower";
            this.BtnS2ToLower.Click += new System.EventHandler(this.BtnS2ToLower_Click);
            // 
            // BtnS1ToUpper
            // 
            this.BtnS1ToUpper.Location = new System.Drawing.Point(17, 203);
            this.BtnS1ToUpper.Name = "BtnS1ToUpper";
            this.BtnS1ToUpper.Size = new System.Drawing.Size(104, 23);
            this.BtnS1ToUpper.TabIndex = 88;
            this.BtnS1ToUpper.Text = "String 1 ToUpper";
            this.BtnS1ToUpper.Click += new System.EventHandler(this.BtnS1ToUpper_Click);
            // 
            // TbxNumber2
            // 
            this.TbxNumber2.Location = new System.Drawing.Point(97, 108);
            this.TbxNumber2.Name = "TbxNumber2";
            this.TbxNumber2.Size = new System.Drawing.Size(136, 20);
            this.TbxNumber2.TabIndex = 80;
            // 
            // LblNum2
            // 
            this.LblNum2.Location = new System.Drawing.Point(9, 108);
            this.LblNum2.Name = "LblNum2";
            this.LblNum2.Size = new System.Drawing.Size(80, 23);
            this.LblNum2.TabIndex = 87;
            this.LblNum2.Text = "Number 2";
            this.LblNum2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnElementN1S1
            // 
            this.BtnElementN1S1.Location = new System.Drawing.Point(17, 171);
            this.BtnElementN1S1.Name = "BtnElementN1S1";
            this.BtnElementN1S1.Size = new System.Drawing.Size(216, 23);
            this.BtnElementN1S1.TabIndex = 86;
            this.BtnElementN1S1.Text = "Element Number 1 of String 1";
            this.BtnElementN1S1.Click += new System.EventHandler(this.BtnElementN1S1_Click);
            // 
            // TbxNumber1
            // 
            this.TbxNumber1.Location = new System.Drawing.Point(97, 76);
            this.TbxNumber1.Name = "TbxNumber1";
            this.TbxNumber1.Size = new System.Drawing.Size(136, 20);
            this.TbxNumber1.TabIndex = 79;
            // 
            // TbxString2
            // 
            this.TbxString2.Location = new System.Drawing.Point(65, 44);
            this.TbxString2.Name = "TbxString2";
            this.TbxString2.Size = new System.Drawing.Size(168, 20);
            this.TbxString2.TabIndex = 78;
            // 
            // TbxString1
            // 
            this.TbxString1.Location = new System.Drawing.Point(65, 12);
            this.TbxString1.Name = "TbxString1";
            this.TbxString1.Size = new System.Drawing.Size(168, 20);
            this.TbxString1.TabIndex = 77;
            // 
            // LblNum1
            // 
            this.LblNum1.Location = new System.Drawing.Point(9, 76);
            this.LblNum1.Name = "LblNum1";
            this.LblNum1.Size = new System.Drawing.Size(80, 23);
            this.LblNum1.TabIndex = 85;
            this.LblNum1.Text = "Number 1";
            this.LblNum1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblStr2
            // 
            this.LblStr2.Location = new System.Drawing.Point(9, 44);
            this.LblStr2.Name = "LblStr2";
            this.LblStr2.Size = new System.Drawing.Size(48, 23);
            this.LblStr2.TabIndex = 84;
            this.LblStr2.Text = "String 2";
            this.LblStr2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblStr1
            // 
            this.LblStr1.Location = new System.Drawing.Point(9, 12);
            this.LblStr1.Name = "LblStr1";
            this.LblStr1.Size = new System.Drawing.Size(48, 23);
            this.LblStr1.TabIndex = 83;
            this.LblStr1.Text = "String 1";
            this.LblStr1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnConcatenate
            // 
            this.BtnConcatenate.Location = new System.Drawing.Point(18, 138);
            this.BtnConcatenate.Name = "BtnConcatenate";
            this.BtnConcatenate.Size = new System.Drawing.Size(103, 23);
            this.BtnConcatenate.TabIndex = 82;
            this.BtnConcatenate.Text = "Concatenate";
            this.BtnConcatenate.Click += new System.EventHandler(this.BtnConcatenate_Click);
            // 
            // TbxOutput
            // 
            this.TbxOutput.Location = new System.Drawing.Point(241, 11);
            this.TbxOutput.Multiline = true;
            this.TbxOutput.Name = "TbxOutput";
            this.TbxOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxOutput.Size = new System.Drawing.Size(344, 441);
            this.TbxOutput.TabIndex = 81;
            // 
            // FrmStringDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 462);
            this.Controls.Add(this.BtnCompare);
            this.Controls.Add(this.BtnSubstringOnward);
            this.Controls.Add(this.BtnSubstringSize);
            this.Controls.Add(this.BtnLastIndexOf);
            this.Controls.Add(this.BtnIndexOf);
            this.Controls.Add(this.BtnRemove);
            this.Controls.Add(this.BtnInsert);
            this.Controls.Add(this.BtnS2ToLower);
            this.Controls.Add(this.BtnS1ToUpper);
            this.Controls.Add(this.TbxNumber2);
            this.Controls.Add(this.LblNum2);
            this.Controls.Add(this.BtnElementN1S1);
            this.Controls.Add(this.TbxNumber1);
            this.Controls.Add(this.TbxString2);
            this.Controls.Add(this.TbxString1);
            this.Controls.Add(this.LblNum1);
            this.Controls.Add(this.LblStr2);
            this.Controls.Add(this.LblStr1);
            this.Controls.Add(this.BtnConcatenate);
            this.Controls.Add(this.TbxOutput);
            this.Name = "FrmStringDemo";
            this.Text = "String demonstrations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCompare;
        internal System.Windows.Forms.Button BtnSubstringOnward;
        internal System.Windows.Forms.Button BtnSubstringSize;
        internal System.Windows.Forms.Button BtnLastIndexOf;
        internal System.Windows.Forms.Button BtnIndexOf;
        internal System.Windows.Forms.Button BtnRemove;
        internal System.Windows.Forms.Button BtnInsert;
        internal System.Windows.Forms.Button BtnS2ToLower;
        internal System.Windows.Forms.Button BtnS1ToUpper;
        internal System.Windows.Forms.TextBox TbxNumber2;
        internal System.Windows.Forms.Label LblNum2;
        internal System.Windows.Forms.Button BtnElementN1S1;
        internal System.Windows.Forms.TextBox TbxNumber1;
        internal System.Windows.Forms.TextBox TbxString2;
        internal System.Windows.Forms.TextBox TbxString1;
        internal System.Windows.Forms.Label LblNum1;
        internal System.Windows.Forms.Label LblStr2;
        internal System.Windows.Forms.Label LblStr1;
        internal System.Windows.Forms.Button BtnConcatenate;
        internal System.Windows.Forms.TextBox TbxOutput;
    }
}


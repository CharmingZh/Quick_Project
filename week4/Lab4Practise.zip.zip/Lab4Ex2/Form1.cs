﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4Ex2
{
    //Created by Latha - Tutor , 3/10/21
    //To demonstrate user define functions/methods
    //To demonstrate calling forms and methods from another  form
    public partial class Form1 : Form
    {
        //String str;
       
        public Form1()
        {
            InitializeComponent();
        }
      public string display(String msg)
        {
           return msg.ToUpper();  
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(display("Iam Happy"),"From method display");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show( display("Iam excited!"), "From Method display");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show( display("Iam Sad!"), "From Method display");
        }

        private int calc(int i, int j, String s)
        {
            int result;
            if(s.Equals("+"))
            {
                result = i + j;
            }
            else if(s.Equals("-"))
            {
                result = i - j;
            }
            else if(s.Equals("*"))
            {
                result = i * j;
            }
            else
            {
                result = i / j;
            }

            return result;

        }
        private void button4_Click(object sender, EventArgs e)
        {
            String number1 = textBox1.Text;
            String number2 = textBox2.Text;
            String str = textBox3.Text;
            label4.Text = calc(Convert.ToInt32(number1), Convert.ToInt32(number2), str).ToString();
           
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 obj= new Form2();
           obj.Show();
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4Ex2
{
    public partial class Form2 : Form
    {
     //Created by Latha - Tutor , 3/10/21

        public Form2()
        {
            InitializeComponent();
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frmobj;
            frmobj = new Form1();
            String str= frmobj.display("Iam from Form2");
            MessageBox.Show(str, "Form2");
                 
         
        }
    }
}

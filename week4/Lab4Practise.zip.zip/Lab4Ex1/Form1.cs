﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4Ex1
{
    public partial class Form1 : Form
    {
        String dob;
        int age;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { //DateTime.Now.ToString("DD/MM/YYYY")

            MessageBox.Show("Date:" + DateTime.Now.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                String dob = textBox1.Text;
                DateTime bday = Convert.ToDateTime(dob);
                DateTime cdate = DateTime.Now;
                age = cdate.Year - bday.Year;
                label2.Text = age.ToString();
            }catch(Exception ex) { MessageBox.Show("Error"+ex.ToString()); }
            
        }
           
        }
    }


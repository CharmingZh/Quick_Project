﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec9Demo
{
    public partial class BinaryCheckboxesBruteForce : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Was a lab exercise; now an illustration of problem solving
        // Also illustrates a method that handles multiple events

        public BinaryCheckboxesBruteForce()
        {
            InitializeComponent();
        }

        private void Chbx128_CheckedChanged(object sender, EventArgs e)
        {
            // Created as an event handler for one checkbox
            // Whenever the 128 checkbox changes, compute the sum of the lot

            // Brute force approach - one if for each checkbox
            // Note: none of the tests says '== true' or '== false'; they're already boolean!

            int iDecimalValue = 0;
            if (Chbx128.Checked) iDecimalValue = iDecimalValue + 128;
            if (Chbx64.Checked) iDecimalValue = iDecimalValue + 64;
            if (Chbx32.Checked) iDecimalValue = iDecimalValue + 32;
            if (Chbx16.Checked) iDecimalValue = iDecimalValue + 16;
            if (Chbx8.Checked) iDecimalValue = iDecimalValue + 8;
            if (Chbx4.Checked) iDecimalValue = iDecimalValue + 4;
            if (Chbx2.Checked) iDecimalValue = iDecimalValue + 2;
            if (Chbx1.Checked) iDecimalValue = iDecimalValue + 1;

            LblDecimal.Text = string.Format("The decimal value is {0:d}", iDecimalValue);

            // Now change the name of this method to AnyCheckbox_CheckedChanged,
            // and add it as an event-handler to each of the other checkboxes.
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close the form and return to the main menu
            this.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec9Demo
{
    // Simon, June 2015
    // Last updated August 2021
    // Count the times a specified day number falls on each day of the week
    // during a specified interval.

    public partial class Thirteenths : Form
    {
        public Thirteenths()
        {
            InitializeComponent();
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close the form and return to the main menu
            this.Dispose();
        }

        private void BtnCount_Click(object sender, EventArgs e)
        {   // Count the number of times the specified day number falls on
            // a Monday, a Tuesday, etc in the specified interval

            // Collect the data from the form
            DateTime dtRunningDate = DtpStartDate.Value;  // Will change as we proceed
            DateTime dtEndDate = DtpEndDate.Value;
            int iDayNum = 13;  // A default value in case of poor data
            int iMonCount = 0, iTueCount = 0, iWedCount = 0, iThuCount = 0, iFriCount = 0, iSatCount = 0, iSunCount = 0;

            iDayNum = Convert.ToInt32(TbxDayNum.Text);

            // Get to the real starting date - the first instance of the specified
            // day number
            while (dtRunningDate.Day != iDayNum)
            {
                dtRunningDate.AddDays(1);
                //dtRunningDate = dtRunningDate.AddDays(1);  //Corrected version
            }
            MessageBox.Show(Convert.ToString(dtRunningDate.Day)); // For debugging

            // Check that day in every month until we reach the end date
            while (dtRunningDate <= dtEndDate)
            {
                // Work out what day of the week it is
                if (dtRunningDate.DayOfWeek == DayOfWeek.Monday)
                    iMonCount = iMonCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Tuesday)
                    iTueCount = iTueCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Wednesday)
                    iWedCount = iWedCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Thursday)
                    iThuCount = iThuCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Friday)
                    iFriCount = iFriCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Saturday)
                    iSatCount = iSatCount + 1;
                else if (dtRunningDate.DayOfWeek == DayOfWeek.Sunday)
                    iSunCount = iSunCount + 1;
                //MessageBox.Show(Convert.ToString(runningDate.DayOfWeek)); // For debugging

                // And then move to the same day of the next month
                dtRunningDate = dtRunningDate.AddMonths(1);
            }

            // Counting's finished - display the results
            LblMon.Text = String.Format("Monday: {0:d}", iMonCount);
            LblTue.Text = String.Format("Tuesday: {0:d}", iTueCount);
            LblWed.Text = String.Format("Wednesday: {0:d}", iWedCount);
            LblThu.Text = String.Format("Thursday:  {0:d}", iThuCount);
            LblFri.Text = String.Format("Friday: {0:d}", iFriCount);
            LblSat.Text = String.Format("Saturday: {0:d}", iSatCount);
            LblSun.Text = String.Format("Sunday: {0:d}", iSunCount);
        } // end BtnCount_Click
    } // end class
} // end namespace

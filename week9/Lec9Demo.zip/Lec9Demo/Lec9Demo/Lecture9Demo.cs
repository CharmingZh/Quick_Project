﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec9Demo
{
    public partial class FrmLec9Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Illustrating problem solving and incremental design for lecture 9

        public FrmLec9Demo()
        {
            InitializeComponent();
        }

        private void BtnBinaryBruteForce_Click(object sender, EventArgs e)
        {   // Launch a brute force binary checkboxes form
            BinaryCheckboxesBruteForce FrmBinaryChbx = new BinaryCheckboxesBruteForce();
            FrmBinaryChbx.ShowDialog();
        }

        private void BtnBinaryIterative_Click(object sender, EventArgs e)
        {   // Launch an iterative binary checkboxes form
            BinaryCheckboxesIterative FrmBinaryChbx = new BinaryCheckboxesIterative();
            FrmBinaryChbx.ShowDialog();
        }

        private void BtnThirteenths_Click(object sender, EventArgs e)
        {   // Lanuch the form that counts the thirteenths (or any other day number)
            Thirteenths FrmThirteenths = new Thirteenths();
            FrmThirteenths.ShowDialog();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Quit the program
            Application.Exit();
        }
    }
}

﻿namespace Lec9Demo
{
    partial class FrmLec9Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnBinaryBruteForce = new System.Windows.Forms.Button();
            this.BtnBinaryIterative = new System.Windows.Forms.Button();
            this.BtnThirteenths = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnBinaryBruteForce
            // 
            this.BtnBinaryBruteForce.Location = new System.Drawing.Point(55, 40);
            this.BtnBinaryBruteForce.Name = "BtnBinaryBruteForce";
            this.BtnBinaryBruteForce.Size = new System.Drawing.Size(180, 23);
            this.BtnBinaryBruteForce.TabIndex = 0;
            this.BtnBinaryBruteForce.Text = "Binary checkboxes - brute force";
            this.BtnBinaryBruteForce.UseVisualStyleBackColor = true;
            this.BtnBinaryBruteForce.Click += new System.EventHandler(this.BtnBinaryBruteForce_Click);
            // 
            // BtnBinaryIterative
            // 
            this.BtnBinaryIterative.Location = new System.Drawing.Point(55, 91);
            this.BtnBinaryIterative.Name = "BtnBinaryIterative";
            this.BtnBinaryIterative.Size = new System.Drawing.Size(180, 23);
            this.BtnBinaryIterative.TabIndex = 1;
            this.BtnBinaryIterative.Text = "Binary checkboxes - iterative";
            this.BtnBinaryIterative.UseVisualStyleBackColor = true;
            this.BtnBinaryIterative.Click += new System.EventHandler(this.BtnBinaryIterative_Click);
            // 
            // BtnThirteenths
            // 
            this.BtnThirteenths.Location = new System.Drawing.Point(55, 142);
            this.BtnThirteenths.Name = "BtnThirteenths";
            this.BtnThirteenths.Size = new System.Drawing.Size(180, 23);
            this.BtnThirteenths.TabIndex = 2;
            this.BtnThirteenths.Text = "Thirteenths";
            this.BtnThirteenths.UseVisualStyleBackColor = true;
            this.BtnThirteenths.Click += new System.EventHandler(this.BtnThirteenths_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Location = new System.Drawing.Point(108, 193);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 23);
            this.BtnExit.TabIndex = 3;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // FrmLec9Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnThirteenths);
            this.Controls.Add(this.BtnBinaryIterative);
            this.Controls.Add(this.BtnBinaryBruteForce);
            this.Name = "FrmLec9Demo";
            this.Text = "Lecture 9 demo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnBinaryBruteForce;
        private System.Windows.Forms.Button BtnBinaryIterative;
        private System.Windows.Forms.Button BtnThirteenths;
        private System.Windows.Forms.Button BtnExit;
    }
}


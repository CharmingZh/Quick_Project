﻿namespace Lec9Demo
{
    partial class BinaryCheckboxesBruteForce
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Chbx1 = new System.Windows.Forms.CheckBox();
            this.GpboxBits = new System.Windows.Forms.GroupBox();
            this.Chbx2 = new System.Windows.Forms.CheckBox();
            this.Chbx4 = new System.Windows.Forms.CheckBox();
            this.Chbx8 = new System.Windows.Forms.CheckBox();
            this.Chbx16 = new System.Windows.Forms.CheckBox();
            this.Chbx32 = new System.Windows.Forms.CheckBox();
            this.Chbx64 = new System.Windows.Forms.CheckBox();
            this.Chbx128 = new System.Windows.Forms.CheckBox();
            this.LblDecimal = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.GpboxBits.SuspendLayout();
            this.SuspendLayout();
            // 
            // Chbx1
            // 
            this.Chbx1.Location = new System.Drawing.Point(24, 184);
            this.Chbx1.Name = "Chbx1";
            this.Chbx1.Size = new System.Drawing.Size(104, 24);
            this.Chbx1.TabIndex = 7;
            this.Chbx1.Text = "1";
            // 
            // GpboxBits
            // 
            this.GpboxBits.Controls.Add(this.Chbx1);
            this.GpboxBits.Controls.Add(this.Chbx2);
            this.GpboxBits.Controls.Add(this.Chbx4);
            this.GpboxBits.Controls.Add(this.Chbx8);
            this.GpboxBits.Controls.Add(this.Chbx16);
            this.GpboxBits.Controls.Add(this.Chbx32);
            this.GpboxBits.Controls.Add(this.Chbx64);
            this.GpboxBits.Controls.Add(this.Chbx128);
            this.GpboxBits.Location = new System.Drawing.Point(70, 7);
            this.GpboxBits.Name = "GpboxBits";
            this.GpboxBits.Size = new System.Drawing.Size(144, 216);
            this.GpboxBits.TabIndex = 8;
            this.GpboxBits.TabStop = false;
            this.GpboxBits.Text = "Binary digits";
            // 
            // Chbx2
            // 
            this.Chbx2.Location = new System.Drawing.Point(24, 160);
            this.Chbx2.Name = "Chbx2";
            this.Chbx2.Size = new System.Drawing.Size(104, 24);
            this.Chbx2.TabIndex = 6;
            this.Chbx2.Text = "2";
            // 
            // Chbx4
            // 
            this.Chbx4.Location = new System.Drawing.Point(24, 136);
            this.Chbx4.Name = "Chbx4";
            this.Chbx4.Size = new System.Drawing.Size(104, 24);
            this.Chbx4.TabIndex = 5;
            this.Chbx4.Text = "4";
            // 
            // Chbx8
            // 
            this.Chbx8.Location = new System.Drawing.Point(24, 112);
            this.Chbx8.Name = "Chbx8";
            this.Chbx8.Size = new System.Drawing.Size(104, 24);
            this.Chbx8.TabIndex = 4;
            this.Chbx8.Text = "8";
            // 
            // Chbx16
            // 
            this.Chbx16.Location = new System.Drawing.Point(24, 88);
            this.Chbx16.Name = "Chbx16";
            this.Chbx16.Size = new System.Drawing.Size(104, 24);
            this.Chbx16.TabIndex = 3;
            this.Chbx16.Text = "16";
            // 
            // Chbx32
            // 
            this.Chbx32.Location = new System.Drawing.Point(24, 64);
            this.Chbx32.Name = "Chbx32";
            this.Chbx32.Size = new System.Drawing.Size(104, 24);
            this.Chbx32.TabIndex = 2;
            this.Chbx32.Text = "32";
            // 
            // Chbx64
            // 
            this.Chbx64.Location = new System.Drawing.Point(24, 40);
            this.Chbx64.Name = "Chbx64";
            this.Chbx64.Size = new System.Drawing.Size(104, 24);
            this.Chbx64.TabIndex = 1;
            this.Chbx64.Text = "64";
            // 
            // Chbx128
            // 
            this.Chbx128.Location = new System.Drawing.Point(24, 16);
            this.Chbx128.Name = "Chbx128";
            this.Chbx128.Size = new System.Drawing.Size(104, 24);
            this.Chbx128.TabIndex = 0;
            this.Chbx128.Text = "128";
            this.Chbx128.CheckedChanged += new System.EventHandler(this.Chbx128_CheckedChanged);
            // 
            // LblDecimal
            // 
            this.LblDecimal.Location = new System.Drawing.Point(70, 231);
            this.LblDecimal.Name = "LblDecimal";
            this.LblDecimal.Size = new System.Drawing.Size(144, 24);
            this.LblDecimal.TabIndex = 9;
            this.LblDecimal.Text = "The decimal value is";
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(106, 268);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 10;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // BinaryCheckboxesBruteForce
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 302);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.GpboxBits);
            this.Controls.Add(this.LblDecimal);
            this.Name = "BinaryCheckboxesBruteForce";
            this.Text = "Binary checkboxes";
            this.GpboxBits.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.CheckBox Chbx1;
        internal System.Windows.Forms.GroupBox GpboxBits;
        internal System.Windows.Forms.CheckBox Chbx2;
        internal System.Windows.Forms.CheckBox Chbx4;
        internal System.Windows.Forms.CheckBox Chbx8;
        internal System.Windows.Forms.CheckBox Chbx16;
        internal System.Windows.Forms.CheckBox Chbx32;
        internal System.Windows.Forms.CheckBox Chbx64;
        internal System.Windows.Forms.CheckBox Chbx128;
        internal System.Windows.Forms.Label LblDecimal;
        private System.Windows.Forms.Button BtnClose;
    }
}
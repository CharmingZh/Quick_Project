﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec9Demo
{
    // Simon, June 2015
    // Last updated August 2021
    // Was a lab exercise; now an illustration of problem solving
    // Also illustrates a method that handles multiple events

    public partial class BinaryCheckboxesIterative : Form
    {
        public BinaryCheckboxesIterative()
        {
            InitializeComponent();
        }

        private void AnyCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            // Created as an event handler for one checkbox, this was then added
            // to all the others

            // Whenever any of the checkboxes changes, compute the sum of the lot

            // Iterative approach, using foreach and the Text value of each checkbox

            int iDecimalValue = 0;

            foreach (CheckBox Chbx in GpboxBits.Controls)
            {
                if (Chbx.Checked) iDecimalValue = iDecimalValue + Convert.ToInt32(Chbx.Text);
            }
            LblDecimal.Text = string.Format("The decimal value is {0:d}", iDecimalValue);
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close the form and return to the main menu
            this.Dispose();
        }
    }
}

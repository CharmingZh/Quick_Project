﻿namespace Lec9Demo
{
    partial class Thirteenths
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Thirteenths));
            this.LblSun = new System.Windows.Forms.Label();
            this.LblSat = new System.Windows.Forms.Label();
            this.LblFri = new System.Windows.Forms.Label();
            this.LblThu = new System.Windows.Forms.Label();
            this.LblWed = new System.Windows.Forms.Label();
            this.LblTue = new System.Windows.Forms.Label();
            this.LblMon = new System.Windows.Forms.Label();
            this.BtnCount = new System.Windows.Forms.Button();
            this.TbxInfo = new System.Windows.Forms.TextBox();
            this.TbxDayNum = new System.Windows.Forms.TextBox();
            this.DtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.DtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblSun
            // 
            this.LblSun.AutoSize = true;
            this.LblSun.Location = new System.Drawing.Point(259, 352);
            this.LblSun.Name = "LblSun";
            this.LblSun.Size = new System.Drawing.Size(49, 13);
            this.LblSun.TabIndex = 29;
            this.LblSun.Text = "Sunday: ";
            // 
            // LblSat
            // 
            this.LblSat.AutoSize = true;
            this.LblSat.Location = new System.Drawing.Point(259, 316);
            this.LblSat.Name = "LblSat";
            this.LblSat.Size = new System.Drawing.Size(55, 13);
            this.LblSat.TabIndex = 28;
            this.LblSat.Text = "Saturday: ";
            // 
            // LblFri
            // 
            this.LblFri.AutoSize = true;
            this.LblFri.Location = new System.Drawing.Point(259, 280);
            this.LblFri.Name = "LblFri";
            this.LblFri.Size = new System.Drawing.Size(41, 13);
            this.LblFri.TabIndex = 27;
            this.LblFri.Text = "Friday: ";
            // 
            // LblThu
            // 
            this.LblThu.AutoSize = true;
            this.LblThu.Location = new System.Drawing.Point(62, 388);
            this.LblThu.Name = "LblThu";
            this.LblThu.Size = new System.Drawing.Size(57, 13);
            this.LblThu.TabIndex = 26;
            this.LblThu.Text = "Thursday: ";
            // 
            // LblWed
            // 
            this.LblWed.AutoSize = true;
            this.LblWed.Location = new System.Drawing.Point(62, 352);
            this.LblWed.Name = "LblWed";
            this.LblWed.Size = new System.Drawing.Size(70, 13);
            this.LblWed.TabIndex = 25;
            this.LblWed.Text = "Wednesday: ";
            // 
            // LblTue
            // 
            this.LblTue.AutoSize = true;
            this.LblTue.Location = new System.Drawing.Point(62, 316);
            this.LblTue.Name = "LblTue";
            this.LblTue.Size = new System.Drawing.Size(54, 13);
            this.LblTue.TabIndex = 24;
            this.LblTue.Text = "Tuesday: ";
            // 
            // LblMon
            // 
            this.LblMon.AutoSize = true;
            this.LblMon.Location = new System.Drawing.Point(62, 280);
            this.LblMon.Name = "LblMon";
            this.LblMon.Size = new System.Drawing.Size(51, 13);
            this.LblMon.TabIndex = 23;
            this.LblMon.Text = "Monday: ";
            // 
            // BtnCount
            // 
            this.BtnCount.Location = new System.Drawing.Point(130, 212);
            this.BtnCount.Name = "BtnCount";
            this.BtnCount.Size = new System.Drawing.Size(222, 43);
            this.BtnCount.TabIndex = 22;
            this.BtnCount.Text = "Count the days";
            this.BtnCount.UseVisualStyleBackColor = true;
            this.BtnCount.Click += new System.EventHandler(this.BtnCount_Click);
            // 
            // TbxInfo
            // 
            this.TbxInfo.Location = new System.Drawing.Point(36, 22);
            this.TbxInfo.Multiline = true;
            this.TbxInfo.Name = "TbxInfo";
            this.TbxInfo.ReadOnly = true;
            this.TbxInfo.Size = new System.Drawing.Size(415, 75);
            this.TbxInfo.TabIndex = 21;
            this.TbxInfo.Text = resources.GetString("TbxInfo.Text");
            // 
            // TbxDayNum
            // 
            this.TbxDayNum.Location = new System.Drawing.Point(124, 171);
            this.TbxDayNum.Name = "TbxDayNum";
            this.TbxDayNum.Size = new System.Drawing.Size(100, 20);
            this.TbxDayNum.TabIndex = 20;
            this.TbxDayNum.Text = "13";
            // 
            // DtpEndDate
            // 
            this.DtpEndDate.Location = new System.Drawing.Point(124, 137);
            this.DtpEndDate.Name = "DtpEndDate";
            this.DtpEndDate.Size = new System.Drawing.Size(200, 20);
            this.DtpEndDate.TabIndex = 19;
            this.DtpEndDate.Value = new System.DateTime(2400, 12, 31, 0, 0, 0, 0);
            // 
            // DtpStartDate
            // 
            this.DtpStartDate.Location = new System.Drawing.Point(124, 102);
            this.DtpStartDate.Name = "DtpStartDate";
            this.DtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.DtpStartDate.TabIndex = 18;
            this.DtpStartDate.Value = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Day number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "End date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Start date";
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(204, 413);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 30;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // Thirteenths
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 462);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.LblSun);
            this.Controls.Add(this.LblSat);
            this.Controls.Add(this.LblFri);
            this.Controls.Add(this.LblThu);
            this.Controls.Add(this.LblWed);
            this.Controls.Add(this.LblTue);
            this.Controls.Add(this.LblMon);
            this.Controls.Add(this.BtnCount);
            this.Controls.Add(this.TbxInfo);
            this.Controls.Add(this.TbxDayNum);
            this.Controls.Add(this.DtpEndDate);
            this.Controls.Add(this.DtpStartDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Thirteenths";
            this.Text = "Thirteenths";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblSun;
        private System.Windows.Forms.Label LblSat;
        private System.Windows.Forms.Label LblFri;
        private System.Windows.Forms.Label LblThu;
        private System.Windows.Forms.Label LblWed;
        private System.Windows.Forms.Label LblTue;
        private System.Windows.Forms.Label LblMon;
        private System.Windows.Forms.Button BtnCount;
        private System.Windows.Forms.TextBox TbxInfo;
        private System.Windows.Forms.TextBox TbxDayNum;
        private System.Windows.Forms.DateTimePicker DtpEndDate;
        private System.Windows.Forms.DateTimePicker DtpStartDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnClose;
    }
}
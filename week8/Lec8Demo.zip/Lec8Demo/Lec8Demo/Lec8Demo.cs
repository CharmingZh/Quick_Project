﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec8Demo
{
    public partial class FrmLec8Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // A combined demo of lists and file handling

        public FrmLec8Demo()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Stop the program
            Application.Exit();
        }

        private void BtnListDemo_Click(object sender, EventArgs e)
        {   // Simple demo of List<string>
            
            List<string> lisName = new List<string>();

            // Add some names to the list
            lisName.Add("Simon");
            PopulateList(lisName);
            // Display the list
            DisplayList(lisName, "names before the shift");

            // Shift the first name to the end, by adding it there then removing it from the start
            lisName.Add(lisName[0]);
            lisName.RemoveAt(0);
            // Display the list
            DisplayList(lisName, "names after the shift");

            // Add a few more names
            lisName.Add("Simon");
            lisName.Add("Han Kee");
            lisName.Add("David");
            // Display the list
            DisplayList(lisName, "names before sorting");

            // Reverse the list
            lisName.Reverse();
            // Display the list
            DisplayList(lisName, "names after reversing");

            // Sort the list
            lisName.Sort();
            // Display the list
            DisplayList(lisName, "names after sorting");
        } // end BtnListDemo_Click

        private void PopulateList(List<string> lisName)
        {
            // Clear the list, then add some names to it
            lisName.Clear();
            lisName.Add("Zoe");
            lisName.Add("Alexis");
            lisName.Add("Benjamin");
            lisName.Add("Calum");
            lisName.Add("Derelie");
            lisName.Add("Ermyntrude");
        }

        private void DisplayList(List<string> lisName, string sMessage)
        {   // Display the list
            // This version is a slight improvement on the demo version provided
            string sOut = "";
            foreach (string sName in lisName)
            {
                sOut += sName + ", ";
            }
            sOut = sOut.Substring(0, sOut.Length - 2);
            MessageBox.Show(sOut, Convert.ToString(lisName.Count) + " " + sMessage);
        }

        private void BtnCaesarShift_Click(object sender, EventArgs e)
        {   // Create a new Caesar shift form and show it modally
            CaesarShift frmCaesarShift = new CaesarShift();
            frmCaesarShift.ShowDialog();
        }

        private void BtnRainfall_Click(object sender, EventArgs e)
        {   // Create a new RainfallDemo form and show it modally
            RainfallDemo frmRainfallDemo = new RainfallDemo();
            frmRainfallDemo.ShowDialog();
        }

        private void BtnTextFile_Click(object sender, EventArgs e)
        {
            TextFileByLine FrmTextFileByLine = new TextFileByLine();
            FrmTextFileByLine.ShowDialog();
        }
    }  // end class
}  // end namespace

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec8Demo
{
    public partial class TextFileByLine : Form
    {
        // Simon, August 2021
        // Illustrate reading a text file until reaching the end, signified by ReadLine() == null

        public TextFileByLine()
        {
            InitializeComponent();
        }

        private void BtnFileLoad_Click(object sender, EventArgs e)
        {   // Find and open a text file, and copy its contents line by line to TxbLines
            string sFilename;
            if (DlgOpenFile.ShowDialog() == DialogResult.OK)
            {
                try
                {   // Open a stream reader based on the file name from the dialog
                    sFilename = DlgOpenFile.FileName;
                    StreamReader srInstream = new StreamReader(sFilename);
                    // Read the file line by line, appending it to TbxLines
                    string sLine = "";
                    while (sLine != null)
                    {
                        sLine = srInstream.ReadLine();
                        TbxLines.AppendText(sLine + "\r\n");
                    }
                    srInstream.Close();  // Close the file as soon as you finish reading
                }
                catch
                {
                    MessageBox.Show("Sorry, I can't find that file", "Reading line by line");
                }
            }
        } // end BtnFileLoad_Click

        private void BtnReturn_Click(object sender, EventArgs e)
        {   // CLose the form, thus returning control to the main form
            this.Close();
        }
    }
}

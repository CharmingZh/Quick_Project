﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // for file handling

namespace Lec8Demo
{
    public partial class CaesarShift : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Apply a Caesar shift to some text to illustrate text file input and output

        // Note that open and save dialogs were dragged to the form and renamed suitably.
        // They can be seen in the component tray below the form.

        // Two string constants for the uppercase and lowercase alphabets
        const string sUppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string sLowercase = "abcdefghijklmnopqrstuvwxyz";
        


        public CaesarShift()
        {
            InitializeComponent();
        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {   // Close this form, returning to the main menu
            this.Dispose();
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {   // Find and open a text file, and copy its contents to txbPlaintext
            string sFilename, sInput = "";
            if (DlgOpenFile.ShowDialog() == DialogResult.OK)
            {
                try
                {   // Open a stream reader based on the file name from the dialog
                    sFilename = DlgOpenFile.FileName;
                    StreamReader srInstream = new StreamReader(sFilename);
                    // Read the whole file content into a single string
                    sInput = srInstream.ReadToEnd();
                    srInstream.Close();  // Close the file as soon as you finish reading
                }
                catch
                {
                    MessageBox.Show("Sorry, I can't find that file", "Caesar shift");
                }
            }
            // Place the text in the Plaintext textbox
            TbxPlaintext.Text = sInput;
        } // end BtnLoad_Click

        private void BtnShift_Click(object sender, EventArgs e)
        {   // Apply the specified Caesar shift to the context of txbPlaintext and
            // put the resulting string in txbCiphertext
            int iShift = 26;
            try
            {
                iShift = Convert.ToInt32(TbxShift.Text);
            }
            catch
            {
                MessageBox.Show("That shift isn't an integer. I'll do a shift of 26.", "Caesar shift");
            }

            // Shift the plaintext string, using ShiftCharacter to shift a character at a time
            string sPlain = TbxPlaintext.Text;
            string sCipher = "", sChar;
            while (sPlain != "")
            {
                sChar = sPlain.Substring(0, 1); // Extract the first character
                sPlain = sPlain.Substring(1); // Remove it from the string
                // Shift it (if it's a letter) and add it to the result
                sCipher = sCipher + ShiftCharacter(sChar, iShift);
            }

            // The whole string is shifted; put it in the ciphertext textbox
            TbxCiphertext.Text = sCipher;
        } // end BtnShift_Click

        private string ShiftCharacter(string sChar, int iShift)
        {   // Shift a single character;
            // if it's alphabetic, move it up iShift in the alphabet, cycling back
            // to the start if necessary; otherwise, return it unaltered.

            // You should make a point of understanding the next 5 lines -
            // it might take a little effort!

            if (sUppercase.IndexOf(sChar) > -1) // It's an uppercase letter
                return sUppercase.Substring((sUppercase.IndexOf(sChar) + iShift) % 26, 1);
            else if (sLowercase.IndexOf(sChar) > -1) // It's a lowercase letter
                return sLowercase.Substring((sLowercase.IndexOf(sChar) + iShift) % 26, 1);
            else return sChar;  // It's not a letter
        } // end ShiftCharacter


        private void BtnSave_Click(object sender, EventArgs e)
        {   // Find a file, open it for writing, and write the content of txbCiphertext
            if (DlgSaveFile.ShowDialog() == DialogResult.OK)
            {
                string sFileName = DlgSaveFile.FileName;
                try
                {
                    StreamWriter swOutStream = new StreamWriter(sFileName);
                    swOutStream.Write(TbxCiphertext.Text);  // Write whole lot as one string
                    swOutStream.Flush(); // Writing is buffered; this makes sure we get it all
                    swOutStream.Close(); // Close a file when finished with it
                    MessageBox.Show(sFileName + " saved.","Caesar shift");
                }

                catch (IOException ioe)
                {  // If we know the specific type of error that can occur, we can test just for it
                    MessageBox.Show(ioe.Message, "File error");
                }
            } // end if dialog result OK
        } // end BtnSave_Click
    } // end class
} // end namespace

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // needed for file access

namespace Lec8Demo
{
    public partial class RainfallDemo : Form
    {
        // Simon, May 2015
        // Last updated August 2021
        // Wyong rainfall records as an illustration of 2D arrays
        // This version illustrates text file handling, with several years of rainfall in csv files
        // 2007 was a year of major flooding in early June

        // An int array for the months and days; we're going to ignore the 0-index values,
        // using indexes 1-12 and 1-31
        int[,] iRainfall = new int[13, 32];

        // A file name to hold between loading and saving
        string sFilename;

        // A boolean to note whether the file needs saving
        bool bNeedsSaving;

        public RainfallDemo()
        {
            InitializeComponent();
            // Once the form is drawn, set up the rainfall display
            // Put numbers 1-31 down the left of the display
            TbxSideScale.Clear();
            for (int i = 1; i <= 31; i++)
            {
                TbxSideScale.AppendText(Convert.ToString(i) + "\r\n");
            }
            // And months along the top
            TbxTopScale.Text = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec";
        }

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {   // Close this form and return to the main menu
            this.Dispose();
        }

        // The next three regions are the same as in the previous rainfall demo

        #region Rainfall display
        private void Display(int[,] grid)
        {   // Display the whole rainfall chart in txbxRainGrid
            TbxRainGrid.Clear();
            int iYearTotal = 0;

            // Here we transpose the array by looping the first index within the second

            // Because we're ignoring the 0 indexes, we loop not <= getLength but < getLength,
            // as the length is 1 more than the number of actual values
            for (int iDay = 1; iDay < grid.GetLength(1); iDay++)
            {
                for (int iMonth = 1; iMonth < grid.GetLength(0); iMonth++)
                {
                    TbxRainGrid.AppendText(RightAlign(grid[iMonth, iDay], 4));
                    iYearTotal = iYearTotal + grid[iMonth, iDay];
                }
                if (iDay < grid.GetLength(1) - 1) // Don't 'press Enter' on the last line
                    TbxRainGrid.AppendText("\r\n");
            }
            // Display the total for the year
            lblYearRainfall.Text = string.Format("{0:d}mm", iYearTotal);
        } // end Display

        private string RightAlign(int iNum, int iSize)
        {   // Right-align (non-negative) iNum by left padding with spaces to iSize
            // BUT returning all blanks if iNum is zero
            if (iNum > 0)
            {
                return Convert.ToString(iNum).PadLeft(iSize);
            }
            else
            {
                return " ".PadLeft(iSize);
            }
        } // end RightAlign
        #endregion

        #region Direct input
        private void BtnAcceptEntry_Click(object sender, EventArgs e)
        {// Accept a day's rainfall into the array
            int iDay = 0, iMonth = 0, iRain;
            try
            {
                iDay = Convert.ToInt32(TbxDayNum.Text);
                iMonth = Convert.ToInt32(TbxMonthNum.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter a day number and month number", "Data required");
            }
            if (iDay < 1 || iDay > 31 || iMonth < 1 || iMonth > 12)
            // A good program would do a better validity check
            {
                MessageBox.Show("Please enter valid day and month numbers", "Invalid date");
            }
            else
            {   // Assume non-numeric rainfall is zero (and not worth entering!)
                try
                {
                    iRain = Convert.ToInt32(TbxRainfall.Text);
                }
                catch (Exception ex)
                {
                    iRain = 0;
                }
                // Remember, first index is month
                iRainfall[iMonth, iDay] = iRain;
                bNeedsSaving = true; // Data altered, so file might need saving
                BtnSave.Enabled = true;
            }
            // Display the updated rainfall chart
            Display(iRainfall);
        } // end BtnAcceptEntry_Click
        #endregion

        #region Summary for a month
        private void BtnDisplayMonth_Click(object sender, EventArgs e)
        {// Find the month in question, calculate and display the summary for the month
            int iMonth = 0;
            try
            {
                iMonth = Convert.ToInt32(TbxMonthNum2.Text);
                if (iMonth < 1 || iMonth > 12)
                {
                    MessageBox.Show("Please enter a month number from 1 to 12", "Invalid data");
                }
                else
                {
                    ShowFigures(iRainfall, iMonth);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter a valid month number", "Missing data");
            }
        } // end BtnDisplayMonth_Click


        private void ShowFigures(int[,] iGrid, int iMonth)
        {   // Calculate and show the figures for a single month
            int iDays = 0, iTotal = 0, iMax = iGrid[iMonth, 1];
            for (int iDay = 1; iDay < iGrid.GetLength(1); iDay++)
            {
                iTotal = iTotal + iGrid[iMonth, iDay];
                if (iGrid[iMonth, iDay] > 0) iDays = iDays + 1; // Count days with rain
                if (iGrid[iMonth, iDay] > iMax) iMax = iGrid[iMonth, iDay]; // Find day with most rain
            }
            lblDaysRain.Text = Convert.ToString(iDays);
            lblTotalRain.Text = Convert.ToString(iTotal) + "mm";
            lblMostRain.Text = Convert.ToString(iMax) + "mm";
        } // end ShowFigures
        #endregion

        // This region is new to this version of the demo

        #region File input and output
        private void BtnLoad_Click(object sender, EventArgs e)
        {   // Select a rainfall file for opening
            // First check if the current file needs saving
            if (!bNeedsSaving || MessageBox.Show("You have unsaved changes. Press Cancel and Save if required.",
                "Wyong rainfall", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {   // Ask the user to find the file
                if (DlgOpenRainfallFile.ShowDialog() == DialogResult.OK)
                {
                    try
                    {  // Note that this try covers exceptions thrown in the methods it calls
                        sFilename = DlgOpenRainfallFile.FileName;
                        if (RdbTextfile.Checked)
                        {
                            OpenText(sFilename);
                        }
                        else
                        {
                            OpenBinary(sFilename);
                        }
                        bNeedsSaving = false;  // The file has just been loaded, so it doesn't need saving
                        BtnSave.Enabled = false;
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show("Sorry, I can't find that file", "File problem");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Sorry, I can't make proper sense of that file", "File problem");
                    }
                    Display(iRainfall);
                }  // end if dialog result is OK
            }  // end if file doesn't need saving
        } // end BtnLoad_Click

        private void OpenText(string sFilename)
        {   // Open a text file and read a year's rainfall from it
            StreamReader inStream = File.OpenText(sFilename);
            // That's an alternative to StreamReader inStream = new StreamReader(sFilename);
            Parse(inStream);  // Get the figures
            inStream.Close();  // And close the file
            // If successful, show the filename in the form title bar
            // Use the last occurrence of "\" to remove the path detail
            // The first "\" tells it to take the second literally
            int index = sFilename.LastIndexOf("\\");
            this.Text = "Wyong rainfall records - " + sFilename.Substring(index + 1);
        }  // end OpenText

        private void Parse(StreamReader inStream)
        { // The text file is of known form, 12 lines of comma-separated values for each day
            int iDay, iMonth, index;
            string sMonthLine;
            for (iMonth = 1; iMonth <= 12; iMonth++)
            { // But maybe not always 31 days long, so first clear all the rainfalls
                for (iDay = 1; iDay <= 31; iDay++) iRainfall[iMonth, iDay] = 0;
                sMonthLine = inStream.ReadLine();
                iDay = 1;
                // Now use a while loop, to allow for fewer than 31 days
                // Keep going while the line isn't empty
                while (sMonthLine != "")
                {
                    //MessageBox.Show(monthLine); // This was used for debugging
                    index = sMonthLine.IndexOf(",");
                    if (index == -1) // There's no comma, so there's a last number
                    {
                        iRainfall[iMonth, iDay] = Convert.ToInt32(sMonthLine);
                        // Get rid of that last number
                        sMonthLine = "";
                    }
                    else if (index > 0) // There's something before the first comma
                    {
                        iRainfall[iMonth, iDay] = Convert.ToInt32(sMonthLine.Substring(0, index));
                        // Get rid of the comma and the number that preceded it
                        sMonthLine = sMonthLine.Substring(index + 1);
                    }
                    else // The line starts with a comma
                    {
                        iRainfall[iMonth, iDay] = 0;
                        // Get rid of the comma
                        sMonthLine = sMonthLine.Substring(index + 1);
                    }
                    iDay = iDay + 1;
                } // end while (days of month)
            } // end for each month
            Display(iRainfall);
        } // end Parse

        private void OpenBinary(string sFilename)
        {   // Open a binary file and read a year's rainfall from it
            // Create a new FileStream based on the selected file path and name
            FileStream fsInStream = new FileStream(sFilename, FileMode.Open);
            // Use that FileStream to create a binary file reader
            BinaryReader brInfile = new BinaryReader(fsInStream);
            // Read every number into the array - no need to parse!
            for (int iMonth = 1; iMonth <= 12; iMonth++)
                for (int iDay = 1; iDay <= 31; iDay++)
                    iRainfall[iMonth, iDay] = brInfile.ReadInt32();
            brInfile.Close();  // And close the file

            // If successful, show the filename in the form title bar
            // Use the last occurrence of "\" to remove the path detail
            // The first "\" tells it to take the second literally
            int index = sFilename.LastIndexOf("\\");
            this.Text = "Wyong rainfall records - " + sFilename.Substring(index + 1);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {   // Select a file to save the rainfall figures in
            if (RdbTextfile.Checked)
            {   // For the text file, let's save to the same file it was loaded from, sFilename
                FileStream outFile = new FileStream(sFilename, FileMode.Open, FileAccess.Write);
                StreamWriter outStream = new StreamWriter(outFile);
                // Those 2 lines are an alternative to StreamWriter outStream = new StreamWriter(sFilename);
                int iDay, iMonth;
                string sLineout;
                for (iMonth = 1; iMonth <= 12; iMonth++)
                {
                    sLineout = "";
                    for (iDay = 1; iDay <= 31; iDay++)
                    { // Write a non-zero rainfall or nothing, then a comma
                        if (iRainfall[iMonth, iDay] > 0) sLineout = sLineout + Convert.ToString(iRainfall[iMonth, iDay]);
                        sLineout = sLineout + ",";
                    }
                    outStream.WriteLine(sLineout);
                }
                outStream.Close();
                int index = sFilename.LastIndexOf("\\");
                string sJustFile = sFilename.Substring(index + 1);
                MessageBox.Show("Rainfall saved to " + sJustFile, "Save complete");
                BtnSave.Enabled = false;
                bNeedsSaving = false;

            } // end if RdbTextFile checked
            else
            {   // RdbTextFile isn't checked, so we're saving a binary file; use a dialog this time
                if (DlgSaveRainfallFile.ShowDialog() == DialogResult.OK)
                {
                    try
                    {  // Note that this try covers exceptions thrown in the methods it calls
                        sFilename = DlgSaveRainfallFile.FileName;
                        // Create a new FileStream based on the selected file path and name
                        FileStream fsOutStream = new FileStream(sFilename, FileMode.Create);
                        // Use that FileStream to create a binary file writer
                        BinaryWriter bwOutFile = new BinaryWriter(fsOutStream);
                        // Write every number to the file
                        for (int iMonth = 1; iMonth <= 12; iMonth++)
                            for (int iDay = 1; iDay <= 31; iDay++)
                                bwOutFile.Write(iRainfall[iMonth, iDay]);
                        bwOutFile.Close();

                        // Tell the user it's been saved
                        int index = sFilename.LastIndexOf("\\");
                        string sJustFile = sFilename.Substring(index + 1);
                        MessageBox.Show("Rainfall saved to " + sJustFile, "Save complete");
                        bNeedsSaving = false;  // The file has just been saved, so it doesn't need saving
                        BtnSave.Enabled = false;
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show("Sorry, I can't find that file", "File problem");
                    }
                }
            }  // end if RdbTextFile not checked
        } // end BtnSave_Click

        private void RdbBinaryFile_CheckedChanged(object sender, EventArgs e)
        {   // User has changed file types - and might want to save the current data in the other type
            BtnSave.Enabled = true;
        }
        #endregion

    }
}

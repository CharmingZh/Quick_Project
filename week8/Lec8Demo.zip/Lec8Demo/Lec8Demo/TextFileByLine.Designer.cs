﻿
namespace Lec8Demo
{
    partial class TextFileByLine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnFileLoad = new System.Windows.Forms.Button();
            this.TbxLines = new System.Windows.Forms.TextBox();
            this.DlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.BtnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnFileLoad
            // 
            this.BtnFileLoad.Location = new System.Drawing.Point(79, 12);
            this.BtnFileLoad.Name = "BtnFileLoad";
            this.BtnFileLoad.Size = new System.Drawing.Size(75, 23);
            this.BtnFileLoad.TabIndex = 0;
            this.BtnFileLoad.Text = "File load";
            this.BtnFileLoad.UseVisualStyleBackColor = true;
            this.BtnFileLoad.Click += new System.EventHandler(this.BtnFileLoad_Click);
            // 
            // TbxLines
            // 
            this.TbxLines.Location = new System.Drawing.Point(33, 50);
            this.TbxLines.Multiline = true;
            this.TbxLines.Name = "TbxLines";
            this.TbxLines.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxLines.Size = new System.Drawing.Size(472, 489);
            this.TbxLines.TabIndex = 1;
            // 
            // DlgOpenFile
            // 
            this.DlgOpenFile.FileName = "openFileDialog1";
            // 
            // BtnReturn
            // 
            this.BtnReturn.Location = new System.Drawing.Point(336, 12);
            this.BtnReturn.Name = "BtnReturn";
            this.BtnReturn.Size = new System.Drawing.Size(134, 23);
            this.BtnReturn.TabIndex = 2;
            this.BtnReturn.Text = "Return to main menu";
            this.BtnReturn.UseVisualStyleBackColor = true;
            this.BtnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // TextFileByLine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 569);
            this.Controls.Add(this.BtnReturn);
            this.Controls.Add(this.TbxLines);
            this.Controls.Add(this.BtnFileLoad);
            this.Name = "TextFileByLine";
            this.Text = "Text file line by line";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnFileLoad;
        private System.Windows.Forms.TextBox TbxLines;
        private System.Windows.Forms.OpenFileDialog DlgOpenFile;
        private System.Windows.Forms.Button BtnReturn;
    }
}
﻿namespace Lec8Demo
{
    partial class RainfallDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMainMenu = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.lblMostRain = new System.Windows.Forms.Label();
            this.lblTotalRain = new System.Windows.Forms.Label();
            this.lblDaysRain = new System.Windows.Forms.Label();
            this.LblMost = new System.Windows.Forms.Label();
            this.LblTotal = new System.Windows.Forms.Label();
            this.LblDays = new System.Windows.Forms.Label();
            this.LblMonthN2 = new System.Windows.Forms.Label();
            this.TbxMonthNum2 = new System.Windows.Forms.TextBox();
            this.BtnDisplayMonth = new System.Windows.Forms.Button();
            this.TbxRainGrid = new System.Windows.Forms.TextBox();
            this.LblYear = new System.Windows.Forms.Label();
            this.TbxSideScale = new System.Windows.Forms.TextBox();
            this.TbxTopScale = new System.Windows.Forms.TextBox();
            this.lblYearRainfall = new System.Windows.Forms.Label();
            this.BtnSave = new System.Windows.Forms.Button();
            this.BtnLoad = new System.Windows.Forms.Button();
            this.BtnAcceptEntry = new System.Windows.Forms.Button();
            this.LblMonthN = new System.Windows.Forms.Label();
            this.LblRainfall = new System.Windows.Forms.Label();
            this.TbxMonthNum = new System.Windows.Forms.TextBox();
            this.TbxRainfall = new System.Windows.Forms.TextBox();
            this.LblDayN = new System.Windows.Forms.Label();
            this.TbxDayNum = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.RdbBinaryFile = new System.Windows.Forms.RadioButton();
            this.RdbTextfile = new System.Windows.Forms.RadioButton();
            this.DlgOpenRainfallFile = new System.Windows.Forms.OpenFileDialog();
            this.DlgSaveRainfallFile = new System.Windows.Forms.SaveFileDialog();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnMainMenu
            // 
            this.BtnMainMenu.Location = new System.Drawing.Point(93, 461);
            this.BtnMainMenu.Name = "BtnMainMenu";
            this.BtnMainMenu.Size = new System.Drawing.Size(141, 23);
            this.BtnMainMenu.TabIndex = 63;
            this.BtnMainMenu.Text = "Return to main menu";
            this.BtnMainMenu.UseVisualStyleBackColor = true;
            this.BtnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.lblMostRain);
            this.GroupBox2.Controls.Add(this.lblTotalRain);
            this.GroupBox2.Controls.Add(this.lblDaysRain);
            this.GroupBox2.Controls.Add(this.LblMost);
            this.GroupBox2.Controls.Add(this.LblTotal);
            this.GroupBox2.Controls.Add(this.LblDays);
            this.GroupBox2.Controls.Add(this.LblMonthN2);
            this.GroupBox2.Controls.Add(this.TbxMonthNum2);
            this.GroupBox2.Controls.Add(this.BtnDisplayMonth);
            this.GroupBox2.Location = new System.Drawing.Point(20, 282);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(240, 138);
            this.GroupBox2.TabIndex = 60;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Month\'s figures";
            // 
            // lblMostRain
            // 
            this.lblMostRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostRain.Location = new System.Drawing.Point(136, 113);
            this.lblMostRain.Name = "lblMostRain";
            this.lblMostRain.Size = new System.Drawing.Size(64, 16);
            this.lblMostRain.TabIndex = 25;
            this.lblMostRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotalRain
            // 
            this.lblTotalRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRain.Location = new System.Drawing.Point(136, 84);
            this.lblTotalRain.Name = "lblTotalRain";
            this.lblTotalRain.Size = new System.Drawing.Size(64, 16);
            this.lblTotalRain.TabIndex = 24;
            this.lblTotalRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDaysRain
            // 
            this.lblDaysRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDaysRain.Location = new System.Drawing.Point(136, 55);
            this.lblDaysRain.Name = "lblDaysRain";
            this.lblDaysRain.Size = new System.Drawing.Size(32, 16);
            this.lblDaysRain.TabIndex = 23;
            this.lblDaysRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblMost
            // 
            this.LblMost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMost.Location = new System.Drawing.Point(16, 113);
            this.LblMost.Name = "LblMost";
            this.LblMost.Size = new System.Drawing.Size(112, 16);
            this.LblMost.TabIndex = 22;
            this.LblMost.Text = "Most in one day:";
            this.LblMost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblTotal
            // 
            this.LblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTotal.Location = new System.Drawing.Point(40, 84);
            this.LblTotal.Name = "LblTotal";
            this.LblTotal.Size = new System.Drawing.Size(88, 16);
            this.LblTotal.TabIndex = 21;
            this.LblTotal.Text = "Total rain:";
            this.LblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblDays
            // 
            this.LblDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDays.Location = new System.Drawing.Point(40, 55);
            this.LblDays.Name = "LblDays";
            this.LblDays.Size = new System.Drawing.Size(88, 16);
            this.LblDays.TabIndex = 20;
            this.LblDays.Text = "Days of rain:";
            this.LblDays.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblMonthN2
            // 
            this.LblMonthN2.Location = new System.Drawing.Point(24, 23);
            this.LblMonthN2.Name = "LblMonthN2";
            this.LblMonthN2.Size = new System.Drawing.Size(80, 23);
            this.LblMonthN2.TabIndex = 19;
            this.LblMonthN2.Text = "Month number";
            this.LblMonthN2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxMonthNum2
            // 
            this.TbxMonthNum2.Location = new System.Drawing.Point(112, 23);
            this.TbxMonthNum2.Name = "TbxMonthNum2";
            this.TbxMonthNum2.Size = new System.Drawing.Size(24, 20);
            this.TbxMonthNum2.TabIndex = 18;
            // 
            // BtnDisplayMonth
            // 
            this.BtnDisplayMonth.Location = new System.Drawing.Point(152, 23);
            this.BtnDisplayMonth.Name = "BtnDisplayMonth";
            this.BtnDisplayMonth.Size = new System.Drawing.Size(75, 23);
            this.BtnDisplayMonth.TabIndex = 17;
            this.BtnDisplayMonth.Text = "Display";
            this.BtnDisplayMonth.Click += new System.EventHandler(this.BtnDisplayMonth_Click);
            // 
            // TbxRainGrid
            // 
            this.TbxRainGrid.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxRainGrid.Location = new System.Drawing.Point(332, 34);
            this.TbxRainGrid.Multiline = true;
            this.TbxRainGrid.Name = "TbxRainGrid";
            this.TbxRainGrid.Size = new System.Drawing.Size(344, 440);
            this.TbxRainGrid.TabIndex = 57;
            this.TbxRainGrid.TabStop = false;
            // 
            // LblYear
            // 
            this.LblYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblYear.Location = new System.Drawing.Point(52, 431);
            this.LblYear.Name = "LblYear";
            this.LblYear.Size = new System.Drawing.Size(96, 16);
            this.LblYear.TabIndex = 61;
            this.LblYear.Text = "Year\'s rainfall:";
            this.LblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxSideScale
            // 
            this.TbxSideScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxSideScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxSideScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxSideScale.Location = new System.Drawing.Point(292, 36);
            this.TbxSideScale.Multiline = true;
            this.TbxSideScale.Name = "TbxSideScale";
            this.TbxSideScale.Size = new System.Drawing.Size(32, 440);
            this.TbxSideScale.TabIndex = 59;
            this.TbxSideScale.TabStop = false;
            this.TbxSideScale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TbxTopScale
            // 
            this.TbxTopScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxTopScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxTopScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxTopScale.Location = new System.Drawing.Point(348, 18);
            this.TbxTopScale.Multiline = true;
            this.TbxTopScale.Name = "TbxTopScale";
            this.TbxTopScale.Size = new System.Drawing.Size(336, 16);
            this.TbxTopScale.TabIndex = 58;
            this.TbxTopScale.TabStop = false;
            // 
            // lblYearRainfall
            // 
            this.lblYearRainfall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYearRainfall.Location = new System.Drawing.Point(156, 431);
            this.lblYearRainfall.Name = "lblYearRainfall";
            this.lblYearRainfall.Size = new System.Drawing.Size(64, 16);
            this.lblYearRainfall.TabIndex = 62;
            this.lblYearRainfall.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BtnSave
            // 
            this.BtnSave.Enabled = false;
            this.BtnSave.Location = new System.Drawing.Point(152, 60);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(75, 23);
            this.BtnSave.TabIndex = 67;
            this.BtnSave.Text = "Save rainfall";
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // BtnLoad
            // 
            this.BtnLoad.Location = new System.Drawing.Point(152, 22);
            this.BtnLoad.Name = "BtnLoad";
            this.BtnLoad.Size = new System.Drawing.Size(75, 23);
            this.BtnLoad.TabIndex = 68;
            this.BtnLoad.Text = "Load rainfall";
            this.BtnLoad.UseVisualStyleBackColor = true;
            this.BtnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // BtnAcceptEntry
            // 
            this.BtnAcceptEntry.Location = new System.Drawing.Point(152, 82);
            this.BtnAcceptEntry.Name = "BtnAcceptEntry";
            this.BtnAcceptEntry.Size = new System.Drawing.Size(75, 23);
            this.BtnAcceptEntry.TabIndex = 5;
            this.BtnAcceptEntry.Text = "Accept entry";
            this.BtnAcceptEntry.Click += new System.EventHandler(this.BtnAcceptEntry_Click);
            // 
            // LblMonthN
            // 
            this.LblMonthN.Location = new System.Drawing.Point(24, 52);
            this.LblMonthN.Name = "LblMonthN";
            this.LblMonthN.Size = new System.Drawing.Size(80, 23);
            this.LblMonthN.TabIndex = 4;
            this.LblMonthN.Text = "Month number";
            this.LblMonthN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblRainfall
            // 
            this.LblRainfall.Location = new System.Drawing.Point(24, 84);
            this.LblRainfall.Name = "LblRainfall";
            this.LblRainfall.Size = new System.Drawing.Size(80, 23);
            this.LblRainfall.TabIndex = 3;
            this.LblRainfall.Text = "Rainfall (mm)";
            this.LblRainfall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxMonthNum
            // 
            this.TbxMonthNum.Location = new System.Drawing.Point(112, 52);
            this.TbxMonthNum.Name = "TbxMonthNum";
            this.TbxMonthNum.Size = new System.Drawing.Size(24, 20);
            this.TbxMonthNum.TabIndex = 1;
            // 
            // TbxRainfall
            // 
            this.TbxRainfall.Location = new System.Drawing.Point(112, 84);
            this.TbxRainfall.Name = "TbxRainfall";
            this.TbxRainfall.Size = new System.Drawing.Size(24, 20);
            this.TbxRainfall.TabIndex = 2;
            // 
            // LblDayN
            // 
            this.LblDayN.Location = new System.Drawing.Point(24, 20);
            this.LblDayN.Name = "LblDayN";
            this.LblDayN.Size = new System.Drawing.Size(80, 23);
            this.LblDayN.TabIndex = 7;
            this.LblDayN.Text = "Day number";
            this.LblDayN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxDayNum
            // 
            this.TbxDayNum.Location = new System.Drawing.Point(112, 20);
            this.TbxDayNum.Name = "TbxDayNum";
            this.TbxDayNum.Size = new System.Drawing.Size(24, 20);
            this.TbxDayNum.TabIndex = 0;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.TbxDayNum);
            this.GroupBox1.Controls.Add(this.LblDayN);
            this.GroupBox1.Controls.Add(this.TbxRainfall);
            this.GroupBox1.Controls.Add(this.TbxMonthNum);
            this.GroupBox1.Controls.Add(this.LblRainfall);
            this.GroupBox1.Controls.Add(this.LblMonthN);
            this.GroupBox1.Controls.Add(this.BtnAcceptEntry);
            this.GroupBox1.Location = new System.Drawing.Point(20, 145);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(240, 114);
            this.GroupBox1.TabIndex = 56;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Data entry";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.RdbBinaryFile);
            this.groupBox3.Controls.Add(this.BtnSave);
            this.groupBox3.Controls.Add(this.BtnLoad);
            this.groupBox3.Controls.Add(this.RdbTextfile);
            this.groupBox3.Location = new System.Drawing.Point(20, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(240, 100);
            this.groupBox3.TabIndex = 77;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "File type and actions";
            // 
            // RdbBinaryFile
            // 
            this.RdbBinaryFile.AutoSize = true;
            this.RdbBinaryFile.Location = new System.Drawing.Point(20, 53);
            this.RdbBinaryFile.Name = "RdbBinaryFile";
            this.RdbBinaryFile.Size = new System.Drawing.Size(94, 17);
            this.RdbBinaryFile.TabIndex = 77;
            this.RdbBinaryFile.Text = "Binary file (dat)";
            this.RdbBinaryFile.UseVisualStyleBackColor = true;
            this.RdbBinaryFile.CheckedChanged += new System.EventHandler(this.RdbBinaryFile_CheckedChanged);
            // 
            // RdbTextfile
            // 
            this.RdbTextfile.AutoSize = true;
            this.RdbTextfile.Checked = true;
            this.RdbTextfile.Location = new System.Drawing.Point(20, 32);
            this.RdbTextfile.Name = "RdbTextfile";
            this.RdbTextfile.Size = new System.Drawing.Size(88, 17);
            this.RdbTextfile.TabIndex = 76;
            this.RdbTextfile.TabStop = true;
            this.RdbTextfile.Text = "Text file (csv)";
            this.RdbTextfile.UseVisualStyleBackColor = true;
            // 
            // DlgOpenRainfallFile
            // 
            this.DlgOpenRainfallFile.FileName = "openFileDialog1";
            // 
            // RainfallDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 502);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.BtnMainMenu);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.TbxRainGrid);
            this.Controls.Add(this.LblYear);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.TbxSideScale);
            this.Controls.Add(this.TbxTopScale);
            this.Controls.Add(this.lblYearRainfall);
            this.Name = "RainfallDemo";
            this.Text = "Wyong rainfall 2003-2016";
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnMainMenu;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label lblMostRain;
        internal System.Windows.Forms.Label lblTotalRain;
        internal System.Windows.Forms.Label lblDaysRain;
        internal System.Windows.Forms.Label LblMost;
        internal System.Windows.Forms.Label LblTotal;
        internal System.Windows.Forms.Label LblDays;
        internal System.Windows.Forms.Label LblMonthN2;
        internal System.Windows.Forms.TextBox TbxMonthNum2;
        internal System.Windows.Forms.Button BtnDisplayMonth;
        internal System.Windows.Forms.TextBox TbxRainGrid;
        internal System.Windows.Forms.Label LblYear;
        internal System.Windows.Forms.TextBox TbxSideScale;
        internal System.Windows.Forms.TextBox TbxTopScale;
        internal System.Windows.Forms.Label lblYearRainfall;
        internal System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.Button BtnLoad;
        internal System.Windows.Forms.Button BtnAcceptEntry;
        internal System.Windows.Forms.Label LblMonthN;
        internal System.Windows.Forms.Label LblRainfall;
        internal System.Windows.Forms.TextBox TbxMonthNum;
        internal System.Windows.Forms.TextBox TbxRainfall;
        internal System.Windows.Forms.Label LblDayN;
        internal System.Windows.Forms.TextBox TbxDayNum;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton RdbBinaryFile;
        private System.Windows.Forms.RadioButton RdbTextfile;
        private System.Windows.Forms.OpenFileDialog DlgOpenRainfallFile;
        private System.Windows.Forms.SaveFileDialog DlgSaveRainfallFile;
    }
}
﻿namespace Lec8Demo
{
    partial class FrmLec8Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnRainfall = new System.Windows.Forms.Button();
            this.BtnCaesarShift = new System.Windows.Forms.Button();
            this.BtnListDemo = new System.Windows.Forms.Button();
            this.BtnTextFile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.Location = new System.Drawing.Point(103, 204);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(79, 23);
            this.BtnExit.TabIndex = 9;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnRainfall
            // 
            this.BtnRainfall.Location = new System.Drawing.Point(42, 118);
            this.BtnRainfall.Name = "BtnRainfall";
            this.BtnRainfall.Size = new System.Drawing.Size(201, 23);
            this.BtnRainfall.TabIndex = 7;
            this.BtnRainfall.Text = "Rainfall with file processing";
            this.BtnRainfall.UseVisualStyleBackColor = true;
            this.BtnRainfall.Click += new System.EventHandler(this.BtnRainfall_Click);
            // 
            // BtnCaesarShift
            // 
            this.BtnCaesarShift.Location = new System.Drawing.Point(42, 75);
            this.BtnCaesarShift.Name = "BtnCaesarShift";
            this.BtnCaesarShift.Size = new System.Drawing.Size(201, 23);
            this.BtnCaesarShift.TabIndex = 6;
            this.BtnCaesarShift.Text = "Caesar shift";
            this.BtnCaesarShift.UseVisualStyleBackColor = true;
            this.BtnCaesarShift.Click += new System.EventHandler(this.BtnCaesarShift_Click);
            // 
            // BtnListDemo
            // 
            this.BtnListDemo.Location = new System.Drawing.Point(42, 32);
            this.BtnListDemo.Name = "BtnListDemo";
            this.BtnListDemo.Size = new System.Drawing.Size(201, 23);
            this.BtnListDemo.TabIndex = 5;
            this.BtnListDemo.Text = "List of string";
            this.BtnListDemo.UseVisualStyleBackColor = true;
            this.BtnListDemo.Click += new System.EventHandler(this.BtnListDemo_Click);
            // 
            // BtnTextFile
            // 
            this.BtnTextFile.Location = new System.Drawing.Point(42, 161);
            this.BtnTextFile.Name = "BtnTextFile";
            this.BtnTextFile.Size = new System.Drawing.Size(201, 23);
            this.BtnTextFile.TabIndex = 10;
            this.BtnTextFile.Text = "Text file line by line";
            this.BtnTextFile.UseVisualStyleBackColor = true;
            this.BtnTextFile.Click += new System.EventHandler(this.BtnTextFile_Click);
            // 
            // FrmLec8Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.BtnTextFile);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnRainfall);
            this.Controls.Add(this.BtnCaesarShift);
            this.Controls.Add(this.BtnListDemo);
            this.Name = "FrmLec8Demo";
            this.Text = "Lecture 8 demonstrations";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnRainfall;
        private System.Windows.Forms.Button BtnCaesarShift;
        private System.Windows.Forms.Button BtnListDemo;
        private System.Windows.Forms.Button BtnTextFile;
    }
}


﻿namespace Lec8Demo
{
    partial class CaesarShift
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnLoad = new System.Windows.Forms.Button();
            this.BtnShift = new System.Windows.Forms.Button();
            this.BtnSave = new System.Windows.Forms.Button();
            this.TbxPlaintext = new System.Windows.Forms.TextBox();
            this.TbxCiphertext = new System.Windows.Forms.TextBox();
            this.TbxShift = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnReturn = new System.Windows.Forms.Button();
            this.DlgOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.DlgSaveFile = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // BtnLoad
            // 
            this.BtnLoad.Location = new System.Drawing.Point(36, 51);
            this.BtnLoad.Name = "BtnLoad";
            this.BtnLoad.Size = new System.Drawing.Size(112, 23);
            this.BtnLoad.TabIndex = 0;
            this.BtnLoad.Text = "Load plaintext";
            this.BtnLoad.UseVisualStyleBackColor = true;
            this.BtnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // BtnShift
            // 
            this.BtnShift.Location = new System.Drawing.Point(36, 193);
            this.BtnShift.Name = "BtnShift";
            this.BtnShift.Size = new System.Drawing.Size(112, 23);
            this.BtnShift.TabIndex = 1;
            this.BtnShift.Text = "Encipher";
            this.BtnShift.UseVisualStyleBackColor = true;
            this.BtnShift.Click += new System.EventHandler(this.BtnShift_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(36, 268);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(112, 23);
            this.BtnSave.TabIndex = 2;
            this.BtnSave.Text = "Save ciphertext";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // TbxPlaintext
            // 
            this.TbxPlaintext.Location = new System.Drawing.Point(184, 40);
            this.TbxPlaintext.Multiline = true;
            this.TbxPlaintext.Name = "TbxPlaintext";
            this.TbxPlaintext.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxPlaintext.Size = new System.Drawing.Size(427, 150);
            this.TbxPlaintext.TabIndex = 3;
            // 
            // TbxCiphertext
            // 
            this.TbxCiphertext.Location = new System.Drawing.Point(184, 220);
            this.TbxCiphertext.Multiline = true;
            this.TbxCiphertext.Name = "TbxCiphertext";
            this.TbxCiphertext.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxCiphertext.Size = new System.Drawing.Size(427, 150);
            this.TbxCiphertext.TabIndex = 4;
            // 
            // TbxShift
            // 
            this.TbxShift.Location = new System.Drawing.Point(83, 122);
            this.TbxShift.Name = "TbxShift";
            this.TbxShift.Size = new System.Drawing.Size(33, 20);
            this.TbxShift.TabIndex = 5;
            this.TbxShift.Text = "8";
            this.TbxShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Shift";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Plaintext";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Ciphertext";
            // 
            // BtnReturn
            // 
            this.BtnReturn.Location = new System.Drawing.Point(36, 343);
            this.BtnReturn.Name = "BtnReturn";
            this.BtnReturn.Size = new System.Drawing.Size(112, 23);
            this.BtnReturn.TabIndex = 9;
            this.BtnReturn.Text = "Back to main menu";
            this.BtnReturn.UseVisualStyleBackColor = true;
            this.BtnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // DlgOpenFile
            // 
            this.DlgOpenFile.FileName = "openFileDialog1";
            // 
            // CaesarShift
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 382);
            this.Controls.Add(this.BtnReturn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TbxShift);
            this.Controls.Add(this.TbxCiphertext);
            this.Controls.Add(this.TbxPlaintext);
            this.Controls.Add(this.BtnSave);
            this.Controls.Add(this.BtnShift);
            this.Controls.Add(this.BtnLoad);
            this.Name = "CaesarShift";
            this.Text = "Caesar shift";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnLoad;
        private System.Windows.Forms.Button BtnShift;
        private System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.TextBox TbxPlaintext;
        private System.Windows.Forms.TextBox TbxCiphertext;
        private System.Windows.Forms.TextBox TbxShift;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnReturn;
        private System.Windows.Forms.OpenFileDialog DlgOpenFile;
        private System.Windows.Forms.SaveFileDialog DlgSaveFile;
    }
}
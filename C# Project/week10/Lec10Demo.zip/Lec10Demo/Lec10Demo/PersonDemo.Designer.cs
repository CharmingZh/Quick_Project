﻿namespace Lec10Demo
{
    partial class PersonDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblHeight = new System.Windows.Forms.Label();
            this.LblWeight = new System.Windows.Forms.Label();
            this.LblHgt = new System.Windows.Forms.Label();
            this.LblWgt = new System.Windows.Forms.Label();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnNamesPlus = new System.Windows.Forms.Button();
            this.BtnNames = new System.Windows.Forms.Button();
            this.TbxResults = new System.Windows.Forms.TextBox();
            this.BtnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblHeight
            // 
            this.LblHeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblHeight.Location = new System.Drawing.Point(116, 256);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(56, 23);
            this.LblHeight.TabIndex = 62;
            // 
            // LblWeight
            // 
            this.LblWeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblWeight.Location = new System.Drawing.Point(116, 216);
            this.LblWeight.Name = "LblWeight";
            this.LblWeight.Size = new System.Drawing.Size(56, 23);
            this.LblWeight.TabIndex = 61;
            // 
            // LblHgt
            // 
            this.LblHgt.Location = new System.Drawing.Point(44, 256);
            this.LblHgt.Name = "LblHgt";
            this.LblHgt.Size = new System.Drawing.Size(56, 23);
            this.LblHgt.TabIndex = 60;
            this.LblHgt.Text = "Height";
            this.LblHgt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblWgt
            // 
            this.LblWgt.Location = new System.Drawing.Point(44, 216);
            this.LblWgt.Name = "LblWgt";
            this.LblWgt.Size = new System.Drawing.Size(56, 23);
            this.LblWgt.TabIndex = 59;
            this.LblWgt.Text = "Weight";
            this.LblWgt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TbxName
            // 
            this.TbxName.Location = new System.Drawing.Point(116, 176);
            this.TbxName.Name = "TbxName";
            this.TbxName.Size = new System.Drawing.Size(104, 20);
            this.TbxName.TabIndex = 58;
            // 
            // BtnSearch
            // 
            this.BtnSearch.Location = new System.Drawing.Point(12, 176);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(88, 23);
            this.BtnSearch.TabIndex = 57;
            this.BtnSearch.Text = "Search for";
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnNamesPlus
            // 
            this.BtnNamesPlus.Location = new System.Drawing.Point(12, 120);
            this.BtnNamesPlus.Name = "BtnNamesPlus";
            this.BtnNamesPlus.Size = new System.Drawing.Size(88, 23);
            this.BtnNamesPlus.TabIndex = 56;
            this.BtnNamesPlus.Text = "Names etc";
            this.BtnNamesPlus.Click += new System.EventHandler(this.BtnNamesPlus_Click);
            // 
            // BtnNames
            // 
            this.BtnNames.Location = new System.Drawing.Point(12, 64);
            this.BtnNames.Name = "BtnNames";
            this.BtnNames.Size = new System.Drawing.Size(88, 23);
            this.BtnNames.TabIndex = 55;
            this.BtnNames.Text = "Names";
            this.BtnNames.Click += new System.EventHandler(this.BtnNames_Click);
            // 
            // TbxResults
            // 
            this.TbxResults.Location = new System.Drawing.Point(236, 8);
            this.TbxResults.Multiline = true;
            this.TbxResults.Name = "TbxResults";
            this.TbxResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxResults.Size = new System.Drawing.Size(200, 360);
            this.TbxResults.TabIndex = 54;
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(75, 316);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 63;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // PersonDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 377);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.LblHeight);
            this.Controls.Add(this.LblWeight);
            this.Controls.Add(this.LblHgt);
            this.Controls.Add(this.LblWgt);
            this.Controls.Add(this.TbxName);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.BtnNamesPlus);
            this.Controls.Add(this.BtnNames);
            this.Controls.Add(this.TbxResults);
            this.Name = "PersonDemo";
            this.Text = "Array of person objects";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label LblHeight;
        internal System.Windows.Forms.Label LblWeight;
        internal System.Windows.Forms.Label LblHgt;
        internal System.Windows.Forms.Label LblWgt;
        internal System.Windows.Forms.TextBox TbxName;
        internal System.Windows.Forms.Button BtnSearch;
        internal System.Windows.Forms.Button BtnNamesPlus;
        internal System.Windows.Forms.Button BtnNames;
        internal System.Windows.Forms.TextBox TbxResults;
        private System.Windows.Forms.Button BtnClose;
    }
}
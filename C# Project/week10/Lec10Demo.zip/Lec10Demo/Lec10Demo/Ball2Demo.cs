﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec10Demo
{
    public partial class Ball2Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Create and manipulate an instance of class Ball2
        // Based on an idea from 'C# for Students' by Bell & Parr

        // Apart from replacing Ball1 with Ball2, this code is identical to that in Ball1Demo.
        // The behaviour is very different because the class attributes (iAcross, iDown, etc)
        // have been replaced with properties, which control the possible values of the attributes.

        // Declare a variable of class Ball2, and a graphics object
        Ball2 balRed;
        Graphics graPaper;

        public Ball2Demo()
        {
            InitializeComponent();  // Remember, this statement is provided automatically

            // Once the form is created, get the picture box ready for drawing . . .
            graPaper = PicbxPaper.CreateGraphics();
            // . . . instantiate the new ball . . .
            balRed = new Ball2();
            // . . . and initialise it by giving values to its attributes
            balRed.iAcross = 100;
            balRed.iDown = 200;
            balRed.iRadius = 50;
            balRed.sbColour = new SolidBrush(Color.Red);
        }

        private void BtnBall_Click(object sender, EventArgs e)
        {
            // Draw the ball
            balRed.Draw(graPaper);
        }

        private void BtnUp_Click(object sender, EventArgs e)
        {
            // Move ball up 10 pixels
            balRed.iDown = balRed.iDown - 10;
            balRed.Draw(graPaper);
        }

        private void BtnDown_Click(object sender, EventArgs e)
        {
            // Move ball down 10 pixels
            balRed.iDown = balRed.iDown + 10;
            balRed.Draw(graPaper);
        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            // Move ball left 10 pixels
            balRed.iAcross = balRed.iAcross - 10;
            balRed.Draw(graPaper);
        }

        private void BtnRight_Click(object sender, EventArgs e)
        {
            // Move ball right 10 pixels
            balRed.iAcross = balRed.iAcross + 10;
            balRed.Draw(graPaper);
        }

        private void BtnGrow_Click(object sender, EventArgs e)
        {
            // Make ball 10 pixels bigger (in diameter)
            balRed.iRadius = balRed.iRadius + 5;
            balRed.Draw(graPaper);
        }

        private void BtnShrink_Click(object sender, EventArgs e)
        {
            // Make ball 10 pixels smaller (in diameter)
            balRed.iRadius = balRed.iRadius - 5;
            balRed.Draw(graPaper);
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            // Close this form and return to the main menu
            this.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec10Demo
{
    // Simon, June 2015
    // Last updated August 2021
    // A Person class, to illustrate an array of objects

    class Person
    {
        // Instance variables - each Person will have its own copy of these
        private string _sName;
        private double _dHeight, _dWeight;

    #region Public properties
        public string sName
        {   // We'll make sName read-only, which means that once created it can't be changed
            get
            {
                return _sName;
            }
        }

       public double dWeight
        {   // Property that reflects _dWeight
            get
            {
                return _dWeight;
            }
            set
            {
                _dWeight = value;
            }
        }

        public double dHeight
        {   // Property that reflects _dHeight
            get
            {
                return _dHeight;
            }
            set
            {
                _dHeight = value;
            }

        }

    #endregion

        public Person(string sNameParam, double dWeightParam, double dHeightParam)
        {   // Only one constructor, which takes a name, height, and weight
            _sName = sNameParam;
            _dHeight = dHeightParam;
            _dWeight = dWeightParam;
        } // end constructor

    } // end class
} // end namespace
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec10Demo
{
    public partial class FrmLec10Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Demonstrations for Inft2012 lecture 10, illustrating classes and objects
        // The Ball demonstrations are based on an idea from 'C# for Students' by Bell & Parr

        public FrmLec10Demo()
        {
            InitializeComponent();
        }

        private void BtnBall1_Click(object sender, EventArgs e)
        {   // Create and display a Ball1Demo form
            Ball1Demo FrmBall1Demo = new Ball1Demo();
            FrmBall1Demo.ShowDialog();
        }

        private void BtnBall2_Click(object sender, EventArgs e)
        {   // Create and display a Ball2Demo form
            Ball2Demo FrmBall2Demo = new Ball2Demo();
            FrmBall2Demo.ShowDialog();
        }

        private void BtnBall3_Click(object sender, EventArgs e)
        {   // Create and display a Ball3Demo form
            Ball3Demo FrmBall3Demo = new Ball3Demo();
            FrmBall3Demo.ShowDialog();
        }

        private void BtnBall4_Click(object sender, EventArgs e)
        {   // Create and display a Ball4Demo form
            Ball4Demo FrmBall4Demo = new Ball4Demo();
            FrmBall4Demo.ShowDialog();
        }

        private void BtnPersonArray_Click(object sender, EventArgs e)
        {   // Create and display a PersonDemo form
            PersonDemo FrmPersonDemo = new PersonDemo();
            FrmPersonDemo.ShowDialog();

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Stop the program
            Application.Exit();
        }

    } // end class
} // end namespace

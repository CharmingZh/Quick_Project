﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec10Demo
{
    public partial class Ball4Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Create and manipulate an instance of class Ball4
        // Based on an idea from 'C# for Students' by Bell & Parr

        // In the previous demos, the form kept track of where the ball was, and told
        // the Ball class where to draw it.
        // In this version the Ball class is more self-contained. The ball knows where
        // it is; the form just tells it to move up, down, left, or right, and the Ball
        // class takes care of that.
        // Just for fun, we also have a timer and continuous movement.

        // Declare four variables of class Ball4, and a graphics object
        Ball4 balRed, balBlue, balYellow, balCurrent;
        Graphics graPaper;
        bool bGoingLeft, bGoingUp; // To note direction of continuous movement

        public Ball4Demo()
        {
            InitializeComponent();  // Remember, this statement is provided automatically

            // Once the form is created, get the picture box ready for drawing . . .
            graPaper = PicbxPaper.CreateGraphics();
            // . . . instantiate and initialise 3 new balls, using 3 different constructors
            balRed = new Ball4(35);
            balBlue = new Ball4(Color.Blue);
            balYellow = new Ball4(Color.Yellow, 100, 200, 50);
            // Choose one to be the current ball
            balCurrent = balYellow;
        }

    #region Ball control
        private void BtnUp_Click(object sender, EventArgs e)
        {
            // Move the current ball up by 10 pixels
            balCurrent.MoveUp(graPaper, 10);
            // Note that while MoveUp is a function that returns a boolean,
            // here we call it as we might call a void method, because we have
            // no use for the boolean.
            // Contrast with the use in 'Moving with the timer' below.
        }

        private void BtnDown_Click(object sender, EventArgs e)
        {
            // Move the current ball down by 10 pixels
            balCurrent.MoveDown(graPaper, 10);
        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            // Move the current ball left by 10 pixels
            balCurrent.MoveLeft(graPaper, 10);
        }

        private void BtnRight_Click(object sender, EventArgs e)
        {
            // Move the current ball right by 10 pixels
            balCurrent.MoveRight(graPaper, 10);
        }

        private void BtnGrow_Click(object sender, EventArgs e)
        {
            // Increase the size of the current ball by 10 pixels (diameter)
            balCurrent.Draw(graPaper, balCurrent.iAcross, balCurrent.iDown, balCurrent.iRadius + 5);
        }

        private void BtnShrink_Click(object sender, EventArgs e)
        {
            // Reduce the size of the current ball by 10 pixels (diameter)
            balCurrent.Draw(graPaper, balCurrent.iAcross, balCurrent.iDown, balCurrent.iRadius - 5);
        }
    #endregion

    #region Ball selection
        // Choose which ball is to be operated by the ball control buttons

        private void BtnRedBall_Click(object sender, EventArgs e)
        {
            balCurrent = balRed;
            balCurrent.Draw(graPaper);
        }

        private void BtnBlueBall_Click(object sender, EventArgs e)
        {
            balCurrent = balBlue;
            balCurrent.Draw(graPaper);
        }

        private void BtnYellowBall_Click(object sender, EventArgs e)
        {
            balCurrent = balYellow;
            balCurrent.Draw(graPaper);
        }
    #endregion

    #region Moving with the timer
        private void BtnBounce_Click(object sender, EventArgs e)
        {
            // Start moving - left and up, so long as we're not on the edges
            bGoingLeft = balCurrent.iAcross > balCurrent.iRadius;
            bGoingUp = balCurrent.iDown > balCurrent.iRadius;
            TmrMoving.Start();  // The timer makes the ball keep moving
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            // Stop moving by stopping the timer
            TmrMoving.Stop();
        }

        private void TmrMoving_Tick(object sender, EventArgs e)
        {
            // At each tick of the timer (every 100th of a second), move the ball
            // vertically and horizontally.

            // Horizontal is left or right depending on goingLeft, whose value is
            // inverted when we reach the edge (causing a bounce).
            // Note that now we call moveLeft etc as functions, using the returned
            // boolean values to determine whether we have reached the edge.
            if (bGoingLeft)
                // Move ball left 3 pixels; if at edge, change value of
                // goingLeft, ie change direction
                bGoingLeft = balCurrent.MoveLeft(graPaper, 3);
            else
                // Move ball right 3 pixels; change direction if at edge
                bGoingLeft = !balCurrent.MoveRight(graPaper, 3);

            // Vertical is up or down depending on goingUp, whose value is
            // inverted when we reach the edge (causing a bounce).
            if (bGoingUp)
                // Move ball up 2 pixels; change direction if at edge
                bGoingUp = balCurrent.MoveUp(graPaper, 2);
            else
                // Move ball down 2 pixels; change direction if at edge
                bGoingUp = !balCurrent.MoveDown(graPaper, 2);
        }
    #endregion

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close this form and return to the main menu
            this.Dispose();
        }
        
    } // end class
} // end namespace

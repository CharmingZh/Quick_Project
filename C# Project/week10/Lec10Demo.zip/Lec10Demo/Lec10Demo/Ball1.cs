﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec10Demo
{
    // Simon, June 2015
    // Last updated August 2021
    // First attempt at a Ball class - everything public, accessed by the calling object

    class Ball1
    {   // Public attributes for the location, size, and colour of the ball
        public int iAcross, iDown, iRadius;
        public SolidBrush sbColour;

        public void Draw(Graphics graPaper)
        {   // A public method to draw the circle with its centre at (iAcross, iDown)
            graPaper.Clear(Color.White);
            graPaper.FillEllipse(sbColour, iAcross - iRadius, iDown - iRadius, iRadius * 2, iRadius * 2);
        }
        

    }
}

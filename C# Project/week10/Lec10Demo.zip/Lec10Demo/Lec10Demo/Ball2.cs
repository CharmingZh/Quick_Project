﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec10Demo
{
    class Ball2
    // Simon, June 2015
    // Last updated August 2021
    // Adding properties to the Ball1 class demonstration

    {
        // Ball shouldn't really know the size of the paper it'll be drawn
        // on, so this is a bit of a cheat.
        const int iPaperSize = 300;

        // Private attributes of a ball
        private int _iAcross, _iDown, _iRadius;
        private SolidBrush _sbColour;

        // Public properties to access those attributes

        public int iAcross  // property corresponds to attribute _iAcross
        {
            get
            {
                return _iAcross;
            }
            set
            {
                // Ensure that the ball can't leave the paper
                if (value < iRadius) _iAcross = iRadius;
                else if (value > iPaperSize - iRadius) _iAcross = iPaperSize - iRadius;
                else _iAcross = value;
            }
        }

        public int iDown  // property corresponds to attribute _iDown
        {
            get
            {
                return _iDown;
            }
            set
            {
                // Ensure that the ball can't leave the paper
                if (value < iRadius) _iDown = iRadius;
                else if (value > iPaperSize - iRadius) _iDown = iPaperSize - iRadius;
                else _iDown = value;
            }
        }

        public int iRadius  // property corresponds to attribute _iRadius
        {
            get
            {
                return _iRadius;
            }
            set
            {
                // Ensure that the ball can't get too big for the paper
                // Separate ifs to deal independently with both dimensions
                int iNewRadius = value;
                if (iAcross - iNewRadius < 0) iNewRadius = iAcross; // left edge
                else if (iAcross + iNewRadius > iPaperSize) iNewRadius = iPaperSize - iAcross; // right edge

                if (iDown - iNewRadius < 0) iNewRadius = iDown; // top edge
                else if (iDown + iNewRadius > iPaperSize) iNewRadius = iPaperSize - iDown; // bottom edge

                // Now make sure it can't disappear
                if (iNewRadius < 10) iNewRadius = 10;

                // Finally, assign it to the attribute
                _iRadius = iNewRadius;
            }
        }

        public SolidBrush sbColour  // property corresponds to attribute _sbColour
        {
            get
            {
                return _sbColour;
            }
            set
            {
                _sbColour = value;
            }
        }

        public void Draw(Graphics graPaper)
        {
            // Draw the ball with its centre at (iAcross, iDown)
            // Note that iAcross, iDown, iRadius, and sbColour are now properties, not attributes
            graPaper.Clear(Color.White);
            graPaper.FillEllipse(sbColour, iAcross - iRadius, iDown - iRadius, iRadius * 2, iRadius * 2);
        }
    } // end class
} // end namespace

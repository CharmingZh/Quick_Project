﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec10Demo
{
    class Ball4
    // Simon, June 2015
    // Last updated August 2021
    // Moving is something that a ball does, so movement methods are added to this class
    // The calling code no longer has to concern itself with the ball's coordinates

    {
        // Ball shouldn't really know the size of the paper it'll be drawn
        // on, so this is a bit of a cheat.
        const int iPaperSize = 300;

        // Private attributes of a ball
        private int _iAcross, _iDown, _iRadius;
        private SolidBrush _sbColour;
        private Pen _penBlack = new Pen(Color.Black);

    #region Public properties
        // Public properties to access those attributes
        public int iAcross  // property corresponds to attribute _iAcross
        {
            get
            {
                return _iAcross;
            }
            set
            {
                // Ensure that the ball can't leave the paper
                if (value < iRadius) _iAcross = iRadius;
                else if (value > iPaperSize - iRadius) _iAcross = iPaperSize - iRadius;
                else _iAcross = value;
            }
        }

        public int iDown  // property corresponds to attribute _iDown
        {
            get
            {
                return _iDown;
            }
            set
            {
                // Ensure that the ball can't leave the paper
                if (value < iRadius) _iDown = iRadius;
                else if (value > iPaperSize - iRadius) _iDown = iPaperSize - iRadius;
                else _iDown = value;
            }
        }

        public int iRadius  // property corresponds to attribute _iRadius
        {
            get
            {
                return _iRadius;
            }
            set
            {
                // Ensure that the ball can't get too big for the paper
                // Separate ifs to deal independently with both dimensions
                int iNewRadius = value;
                if (iAcross - iNewRadius < 0) iNewRadius = iAcross; // left edge
                else if (iAcross + iNewRadius > iPaperSize) iNewRadius = iPaperSize - iAcross; // right edge

                if (iDown - iNewRadius < 0) iNewRadius = iDown; // top edge
                else if (iDown + iNewRadius > iPaperSize) iNewRadius = iPaperSize - iDown; // bottom edge

                // Now make sure it can't disappear
                if (iNewRadius < 10) iNewRadius = 10;

                // Finally, assign it to the attribute
                _iRadius = iNewRadius;
            }
        }

        public SolidBrush sbColour  // property corresponds to attribute _sbColour
        {
            get
            {
                return _sbColour;
            }
            set
            {
                _sbColour = value;
            }
        }
    #endregion

    #region Constructors
        // All the constructors use the properties, not the attributes, to ensure
        // that the attributes are given sensible values.

        public Ball4()
        {
            // Default constructor with no parameters
            // This used to be automatic, but now that we have
            // other constructors we must provide this if we want it -
            // even if we don't want it to initialise anything.
        }

        public Ball4(Color colFill, int x, int y, int iRad)
        {
            // Constructor with colour, location, and radius
            sbColour = new SolidBrush(colFill);
            iAcross = x;
            iDown = y;
            iRadius = iRad;
        }

        public Ball4(int x, int y, int iRad)
        {
            // Constructor with location and radius; set a default colour
            sbColour = new SolidBrush(Color.Red);
            iAcross = x;
            iDown = y;
            iRadius = iRad;
        }

        public Ball4(int x, int y)
        {
            // Constructor with location; set default colour and radius
            sbColour = new SolidBrush(Color.Red);
            iAcross = x;
            iDown = y;
            iRadius = 25;
        }

        public Ball4(int iRad)
        {
            // Constructor with radius; set default colour and location
            sbColour = new SolidBrush(Color.Red);
            iAcross = 150;
            iDown = 150;
            iRadius = iRad;
        }

        public Ball4(Color colFill)
        {
            // Constructor with colour; set default location and radius
            sbColour = new SolidBrush(colFill);
            iAcross = 150;
            iDown = 150;
            iRadius = 25;
        }
    #endregion

    #region Draw the ball
        // Two public methods, ones that the outside code can see
        public void Draw(Graphics graPaper, int x, int y, int iRad)
        {
            // Use the properties to set the attributes to the values provided,
            // then call realDraw to do the actual drawing
            iAcross = x;
            iDown = y;
            iRadius = iRad;
            RealDraw(graPaper);
        }

        public void Draw(Graphics graPaper)
        {
            // An overloaded method; two of the same name with different parameters.
            // Draw the ball with whatever attributes it currently has.
            RealDraw(graPaper);
        }

        // And two private methods, visible only within the Ball class
        private void RealDraw(Graphics graPaper)
        {
            // Draw the ball using the instance variables (attributes) to determine its features.
            // Note that we access the attributes by way of the properties, to ensure integrity.
            // Note too that this is now a private method, accessed only from within Ball3.
            graPaper.Clear(Color.White);
            graPaper.FillEllipse(sbColour, iAcross - iRadius, iDown - iRadius, iRadius * 2, iRadius * 2);
            Encircle(graPaper);
        }

        private void Encircle(Graphics graPaper)
        {
            // Draw a black circle round the ball
            graPaper.DrawEllipse(_penBlack, iAcross - iRadius, iDown - iRadius, iRadius * 2, iRadius * 2);
        }
    #endregion

    #region Ball movement
        public bool MoveLeft(Graphics graPaper, int iJump)
        {
            // Move left the specified amount and indicate if it still has room to move
            iAcross = iAcross - iJump;
            Draw(graPaper);
            return iAcross > iRadius; // ie return false if we can't move left any more
        }

        public bool MoveRight(Graphics graPaper, int iJump)
        {
            // Move right the specified amount and indicate if it still has room to move
            iAcross = iAcross + iJump;
            Draw(graPaper);
            return iAcross < iPaperSize - iRadius; // ie return false if we can't move right any more
        }

        public bool MoveUp(Graphics graPaper, int iJump)
        {
            // Move up the specified amount and indicate if it still has room to move
            iDown = iDown - iJump;
            Draw(graPaper);
            return iDown > iRadius; // ie return false if we can't move up any more
        }

        public bool MoveDown(Graphics graPaper, int iJump)
        {
            // Move down the specified amount and indicate if it still has room to move
            iDown = iDown + iJump;
            Draw(graPaper);
            return iDown < iPaperSize - iRadius; // ie return false if we can't move down any more
        }
    #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec10Demo
{
    public partial class PersonDemo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Demonstration of an array of Person objects

        // Declared here to ensure there's only one generator
        Random rand = new Random();

        // A string array initialised at declaration - this will be used just
        // to initialise the array of Person objects
        private string[] sName = {"Alexis Archer", "Barry Bagsley", "Coralie Creevey", "Donal d'Arques", "Ernestine Eccles", "Frank Fellowes", "Gertrude Gainsborough", "Harry Hotspur",
        "Ilona Iliffe", "Jeremy Janssen", "Kellie Kang", "Laurence Lamprey", "Melissa Mundey", "Ngoc Nguyen", "Ondine Oswald", "Peter Peters", "Queenie Quincy", "Randolph Rush", "Simone Semple",
        "Tony Tan", "Ugberta Urdorfer", "Vinnie Verona", "Wilhelmina Williams", "Xenos Xenophon", "Yolande Yorgensen", "Zeke Zammit"};

        // A constant for the size of the Person array
        const int iArraySize = 26;  // Will make an array of 26 elements, indexes 0 to 25

        // And here's the Person array
        // Note: the array itself is initialised here
        private Person[] perClassMember = new Person[iArraySize];

        public PersonDemo()
        {   // In the form's constructor, once the form itself is constructed . . .
            InitializeComponent();
            // Initialise each member of the Person array with a name from the
            // list and random numbers in suitable ranges for height and weight
            for (int i = 0; i < iArraySize; i++)
            {
                // Random weight between 60 and 120
                // Random.NextDouble gives a random number between 0 and 1
                double dWeight = 60 + 60 * rand.NextDouble();
                // Random height between 1.4 and 2.1
                double dHeight = 1.4 + 0.7 * rand.NextDouble();

                // Now the actual initialisation of the i-th array element
                // Note: every element of the array must also be instantiated
                perClassMember[i] = new Person(sName[i], dWeight, dHeight);
            }
        } // end of form constructor

        private void Display(string[] ipip)
        // Display an array of string in ResultsTxtbx, a line at a time
        // Note that the size of the array is not specified
        {
            TbxResults.Clear();
            // Note that indexes go from 0 to 1 below the length
            for (int i = 0; i < ipip.Length; i++)
            {
                TbxResults.AppendText(ipip[i] + "\r\n");
            } // end Display
        }

        private void BtnNames_Click(object sender, EventArgs e)
        {   // Build a new array of 26 strings, just the names, and display it
            string[] sName = new string[iArraySize];
            for (int i = 0; i < iArraySize; i++)
            { // Taking just the sName property of the class member
                sName[i] = perClassMember[i].sName;
            }
            Display(sName);
        }

        private void BtnNamesPlus_Click(object sender, EventArgs e)
        {   // Build a new array of 26 strings, names + weights + heights, and display it
            string[] sNamePlus = new string[iArraySize];
            for (int i = 0; i < iArraySize; i++)
            { // Taking all three properties of the class member
                sNamePlus[i] = perClassMember[i].sName
                    + string.Format("  {0:f1}", perClassMember[i].dWeight)
                    + string.Format("  {0:f2}", perClassMember[i].dHeight);
                // Note inclusion in format string of spaces to separate the parts
            }
            Display(sNamePlus);
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {   // Search for the name provided; if found, display weight & height
            bool bFound = false;
            if (TbxName.Text == "")
            {
                MessageBox.Show("Type the name you're looking for to the right of Search", "Name required");
            }
            else
            {
                // Search the array, element at a time, for the name provided
                int i = 0;
                do
                {
                    if (perClassMember[i].sName == TbxName.Text)
                    {
                        bFound = true;
                    }
                    else
                    {
                        i = i + 1;
                    }
                }
                while (i < iArraySize && !bFound);

                // Either the name has been found, at index i . . .
                if (bFound)
                {
                    LblWeight.Text = string.Format("  {0:f1}", perClassMember[i].dWeight);
                    LblHeight.Text = string.Format("  {0:f2}", perClassMember[i].dHeight);
                }
                // or the whole array has been searched without success
                else
                {
                    MessageBox.Show("That name is not in our records", "Name not found");
                }
            }
        } // end BtnSearch_Click

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close this form and return to main menu
            this.Dispose();
        }

    } // end class
} // end namespace

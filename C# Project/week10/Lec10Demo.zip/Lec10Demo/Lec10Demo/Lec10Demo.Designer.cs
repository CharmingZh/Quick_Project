﻿namespace Lec10Demo
{
    partial class FrmLec10Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnBall1 = new System.Windows.Forms.Button();
            this.BtnBall2 = new System.Windows.Forms.Button();
            this.BtnBall3 = new System.Windows.Forms.Button();
            this.BtnBall4 = new System.Windows.Forms.Button();
            this.BtnPersonArray = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.Location = new System.Drawing.Point(106, 223);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 23);
            this.BtnExit.TabIndex = 0;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnBall1
            // 
            this.BtnBall1.Location = new System.Drawing.Point(72, 13);
            this.BtnBall1.Name = "BtnBall1";
            this.BtnBall1.Size = new System.Drawing.Size(144, 23);
            this.BtnBall1.TabIndex = 1;
            this.BtnBall1.Text = "Ball 1: simple class";
            this.BtnBall1.UseVisualStyleBackColor = true;
            this.BtnBall1.Click += new System.EventHandler(this.BtnBall1_Click);
            // 
            // BtnBall2
            // 
            this.BtnBall2.Location = new System.Drawing.Point(72, 55);
            this.BtnBall2.Name = "BtnBall2";
            this.BtnBall2.Size = new System.Drawing.Size(144, 23);
            this.BtnBall2.TabIndex = 2;
            this.BtnBall2.Text = "Ball 2: adding properties";
            this.BtnBall2.UseVisualStyleBackColor = true;
            this.BtnBall2.Click += new System.EventHandler(this.BtnBall2_Click);
            // 
            // BtnBall3
            // 
            this.BtnBall3.Location = new System.Drawing.Point(72, 97);
            this.BtnBall3.Name = "BtnBall3";
            this.BtnBall3.Size = new System.Drawing.Size(144, 23);
            this.BtnBall3.TabIndex = 3;
            this.BtnBall3.Text = "Ball 3: adding constructors";
            this.BtnBall3.UseVisualStyleBackColor = true;
            this.BtnBall3.Click += new System.EventHandler(this.BtnBall3_Click);
            // 
            // BtnBall4
            // 
            this.BtnBall4.Location = new System.Drawing.Point(72, 139);
            this.BtnBall4.Name = "BtnBall4";
            this.BtnBall4.Size = new System.Drawing.Size(144, 23);
            this.BtnBall4.TabIndex = 4;
            this.BtnBall4.Text = "Ball 4: multiple objects";
            this.BtnBall4.UseVisualStyleBackColor = true;
            this.BtnBall4.Click += new System.EventHandler(this.BtnBall4_Click);
            // 
            // BtnPersonArray
            // 
            this.BtnPersonArray.Location = new System.Drawing.Point(72, 181);
            this.BtnPersonArray.Name = "BtnPersonArray";
            this.BtnPersonArray.Size = new System.Drawing.Size(144, 23);
            this.BtnPersonArray.TabIndex = 5;
            this.BtnPersonArray.Text = "Array of person objects";
            this.BtnPersonArray.UseVisualStyleBackColor = true;
            this.BtnPersonArray.Click += new System.EventHandler(this.BtnPersonArray_Click);
            // 
            // FrmLec10Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.BtnPersonArray);
            this.Controls.Add(this.BtnBall4);
            this.Controls.Add(this.BtnBall3);
            this.Controls.Add(this.BtnBall2);
            this.Controls.Add(this.BtnBall1);
            this.Controls.Add(this.BtnExit);
            this.Name = "FrmLec10Demo";
            this.Text = "Lecture 10 demonstrations";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnBall1;
        private System.Windows.Forms.Button BtnBall2;
        private System.Windows.Forms.Button BtnBall3;
        private System.Windows.Forms.Button BtnBall4;
        private System.Windows.Forms.Button BtnPersonArray;
    }
}


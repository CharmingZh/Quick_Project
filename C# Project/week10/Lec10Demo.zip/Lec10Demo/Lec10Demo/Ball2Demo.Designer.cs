﻿namespace Lec10Demo
{
    partial class Ball2Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnShrink = new System.Windows.Forms.Button();
            this.BtnGrow = new System.Windows.Forms.Button();
            this.BtnLeft = new System.Windows.Forms.Button();
            this.GpbxMove = new System.Windows.Forms.GroupBox();
            this.BtnRight = new System.Windows.Forms.Button();
            this.BtnDown = new System.Windows.Forms.Button();
            this.BtnUp = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnBall = new System.Windows.Forms.Button();
            this.PicbxPaper = new System.Windows.Forms.PictureBox();
            this.GpbxSize = new System.Windows.Forms.GroupBox();
            this.GpbxMove.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicbxPaper)).BeginInit();
            this.GpbxSize.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnShrink
            // 
            this.BtnShrink.Location = new System.Drawing.Point(40, 48);
            this.BtnShrink.Name = "BtnShrink";
            this.BtnShrink.Size = new System.Drawing.Size(24, 24);
            this.BtnShrink.TabIndex = 1;
            this.BtnShrink.Text = "v";
            this.BtnShrink.Click += new System.EventHandler(this.BtnShrink_Click);
            // 
            // BtnGrow
            // 
            this.BtnGrow.Location = new System.Drawing.Point(40, 16);
            this.BtnGrow.Name = "BtnGrow";
            this.BtnGrow.Size = new System.Drawing.Size(24, 24);
            this.BtnGrow.TabIndex = 0;
            this.BtnGrow.Text = "^";
            this.BtnGrow.Click += new System.EventHandler(this.BtnGrow_Click);
            // 
            // BtnLeft
            // 
            this.BtnLeft.Location = new System.Drawing.Point(16, 40);
            this.BtnLeft.Name = "BtnLeft";
            this.BtnLeft.Size = new System.Drawing.Size(24, 24);
            this.BtnLeft.TabIndex = 3;
            this.BtnLeft.Text = "<";
            this.BtnLeft.Click += new System.EventHandler(this.BtnLeft_Click);
            // 
            // GpbxMove
            // 
            this.GpbxMove.Controls.Add(this.BtnLeft);
            this.GpbxMove.Controls.Add(this.BtnRight);
            this.GpbxMove.Controls.Add(this.BtnDown);
            this.GpbxMove.Controls.Add(this.BtnUp);
            this.GpbxMove.Location = new System.Drawing.Point(7, 80);
            this.GpbxMove.Name = "GpbxMove";
            this.GpbxMove.Size = new System.Drawing.Size(104, 104);
            this.GpbxMove.TabIndex = 26;
            this.GpbxMove.TabStop = false;
            this.GpbxMove.Text = "Move";
            // 
            // BtnRight
            // 
            this.BtnRight.Location = new System.Drawing.Point(64, 40);
            this.BtnRight.Name = "BtnRight";
            this.BtnRight.Size = new System.Drawing.Size(24, 24);
            this.BtnRight.TabIndex = 2;
            this.BtnRight.Text = ">";
            this.BtnRight.Click += new System.EventHandler(this.BtnRight_Click);
            // 
            // BtnDown
            // 
            this.BtnDown.Location = new System.Drawing.Point(40, 64);
            this.BtnDown.Name = "BtnDown";
            this.BtnDown.Size = new System.Drawing.Size(24, 24);
            this.BtnDown.TabIndex = 1;
            this.BtnDown.Text = "v";
            this.BtnDown.Click += new System.EventHandler(this.BtnDown_Click);
            // 
            // BtnUp
            // 
            this.BtnUp.Location = new System.Drawing.Point(40, 16);
            this.BtnUp.Name = "BtnUp";
            this.BtnUp.Size = new System.Drawing.Size(24, 24);
            this.BtnUp.TabIndex = 0;
            this.BtnUp.Text = "^";
            this.BtnUp.Click += new System.EventHandler(this.BtnUp_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(23, 315);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(75, 23);
            this.BtnClose.TabIndex = 29;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // BtnBall
            // 
            this.BtnBall.Location = new System.Drawing.Point(23, 24);
            this.BtnBall.Name = "BtnBall";
            this.BtnBall.Size = new System.Drawing.Size(75, 23);
            this.BtnBall.TabIndex = 28;
            this.BtnBall.Text = "Ball";
            this.BtnBall.Click += new System.EventHandler(this.BtnBall_Click);
            // 
            // PicbxPaper
            // 
            this.PicbxPaper.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PicbxPaper.Location = new System.Drawing.Point(127, 24);
            this.PicbxPaper.Name = "PicbxPaper";
            this.PicbxPaper.Size = new System.Drawing.Size(300, 300);
            this.PicbxPaper.TabIndex = 25;
            this.PicbxPaper.TabStop = false;
            // 
            // GpbxSize
            // 
            this.GpbxSize.Controls.Add(this.BtnShrink);
            this.GpbxSize.Controls.Add(this.BtnGrow);
            this.GpbxSize.Location = new System.Drawing.Point(7, 208);
            this.GpbxSize.Name = "GpbxSize";
            this.GpbxSize.Size = new System.Drawing.Size(104, 80);
            this.GpbxSize.TabIndex = 27;
            this.GpbxSize.TabStop = false;
            this.GpbxSize.Text = "Size";
            // 
            // Ball2Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 362);
            this.Controls.Add(this.GpbxMove);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnBall);
            this.Controls.Add(this.PicbxPaper);
            this.Controls.Add(this.GpbxSize);
            this.Name = "Ball2Demo";
            this.Text = "Let\'s play ball";
            this.GpbxMove.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PicbxPaper)).EndInit();
            this.GpbxSize.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button BtnShrink;
        internal System.Windows.Forms.Button BtnGrow;
        internal System.Windows.Forms.Button BtnLeft;
        internal System.Windows.Forms.GroupBox GpbxMove;
        internal System.Windows.Forms.Button BtnRight;
        internal System.Windows.Forms.Button BtnDown;
        internal System.Windows.Forms.Button BtnUp;
        private System.Windows.Forms.Button BtnClose;
        internal System.Windows.Forms.Button BtnBall;
        internal System.Windows.Forms.PictureBox PicbxPaper;
        internal System.Windows.Forms.GroupBox GpbxSize;
    }
}
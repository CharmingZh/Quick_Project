﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec10Demo
{
    public partial class Ball3Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Create and manipulate an instance of class Ball3
        // Based on an idea from 'C# for Students' by Bell & Parr

        // We now have constructors, and have changed the arguments for the draw method

        // Declare a variable of class Ball3, and a graphics object
        Ball3 balOurBall;
        Graphics graPaper;

        public Ball3Demo()
        {
            InitializeComponent();  // Remember, this statement is provided automatically

            // Once the form is created, get the picture box ready for drawing . . .
            graPaper = PicbxPaper.CreateGraphics();
            // . . . instantiate and initialise the new ball using one of the many constructors
            balOurBall = new Ball3(Color.Yellow);
        }

        private void BtnBall_Click(object sender, EventArgs e)
        {
            // Draw the ball with a specified starting position and size
            balOurBall.Draw(graPaper, 100, 200, 50);
        }

        private void BtnUp_Click(object sender, EventArgs e)
        {
            // Move ball up 10 pixels
            balOurBall.Draw(graPaper, balOurBall.iAcross, balOurBall.iDown - 10, balOurBall.iRadius);
        }

        private void BtnDown_Click(object sender, EventArgs e)
        {
            // Move ball down 10 pixels
            balOurBall.Draw(graPaper, balOurBall.iAcross, balOurBall.iDown + 10, balOurBall.iRadius);
        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            // Move ball left 10 pixels
            balOurBall.Draw(graPaper, balOurBall.iAcross - 10, balOurBall.iDown, balOurBall.iRadius);
        }

        private void BtnRight_Click(object sender, EventArgs e)
        {
            // Move ball right 10 pixels
            balOurBall.Draw(graPaper, balOurBall.iAcross + 10, balOurBall.iDown, balOurBall.iRadius);
        }

        private void BtnGrow_Click(object sender, EventArgs e)
        {
            // Make ball 10 pixels bigger (in diameter)
            balOurBall.Draw(graPaper, balOurBall.iAcross, balOurBall.iDown, balOurBall.iRadius + 5);
        }

        private void BtnShrink_Click(object sender, EventArgs e)
        {
            // Make ball 10 pixels smaller (in diameter)
            balOurBall.Draw(graPaper, balOurBall.iAcross, balOurBall.iDown, balOurBall.iRadius - 5);
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            // Close this form and return to the main menu
            this.Dispose();
        }

    }
}

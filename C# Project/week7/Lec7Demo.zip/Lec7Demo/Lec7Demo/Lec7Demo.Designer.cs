﻿namespace Lec7Demo
{
    partial class frmLec7Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnArrayDemo = new System.Windows.Forms.Button();
            this.btnListboxDemo = new System.Windows.Forms.Button();
            this.btnRainfall = new System.Windows.Forms.Button();
            this.btnGameOfLife = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnArrayDemo
            // 
            this.btnArrayDemo.Location = new System.Drawing.Point(44, 34);
            this.btnArrayDemo.Name = "btnArrayDemo";
            this.btnArrayDemo.Size = new System.Drawing.Size(201, 23);
            this.btnArrayDemo.TabIndex = 0;
            this.btnArrayDemo.Text = "Arrays";
            this.btnArrayDemo.UseVisualStyleBackColor = true;
            this.btnArrayDemo.Click += new System.EventHandler(this.btnArrayDemo_Click);
            // 
            // btnListboxDemo
            // 
            this.btnListboxDemo.Location = new System.Drawing.Point(44, 73);
            this.btnListboxDemo.Name = "btnListboxDemo";
            this.btnListboxDemo.Size = new System.Drawing.Size(201, 23);
            this.btnListboxDemo.TabIndex = 1;
            this.btnListboxDemo.Text = "Listboxes";
            this.btnListboxDemo.UseVisualStyleBackColor = true;
            this.btnListboxDemo.Click += new System.EventHandler(this.btnListboxDemo_Click);
            // 
            // btnRainfall
            // 
            this.btnRainfall.Location = new System.Drawing.Point(44, 112);
            this.btnRainfall.Name = "btnRainfall";
            this.btnRainfall.Size = new System.Drawing.Size(201, 23);
            this.btnRainfall.TabIndex = 2;
            this.btnRainfall.Text = "Rainfall (2D array)";
            this.btnRainfall.UseVisualStyleBackColor = true;
            this.btnRainfall.Click += new System.EventHandler(this.btnRainfall_Click);
            // 
            // btnGameOfLife
            // 
            this.btnGameOfLife.Location = new System.Drawing.Point(44, 151);
            this.btnGameOfLife.Name = "btnGameOfLife";
            this.btnGameOfLife.Size = new System.Drawing.Size(201, 23);
            this.btnGameOfLife.TabIndex = 3;
            this.btnGameOfLife.Text = "Game of life (boolean array)";
            this.btnGameOfLife.UseVisualStyleBackColor = true;
            this.btnGameOfLife.Click += new System.EventHandler(this.btnGameOfLife_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(105, 209);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(79, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmLec7Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnGameOfLife);
            this.Controls.Add(this.btnRainfall);
            this.Controls.Add(this.btnListboxDemo);
            this.Controls.Add(this.btnArrayDemo);
            this.Name = "frmLec7Demo";
            this.Text = "Lecture 7 demonstrations";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnArrayDemo;
        private System.Windows.Forms.Button btnListboxDemo;
        private System.Windows.Forms.Button btnRainfall;
        private System.Windows.Forms.Button btnGameOfLife;
        private System.Windows.Forms.Button btnExit;
    }
}


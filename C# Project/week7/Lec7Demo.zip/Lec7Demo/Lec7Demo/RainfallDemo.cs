﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec7Demo
{
    public partial class RainfallDemo : Form
    {   // Simon, May 2015
        // Last updated August 2021
        // Wyong rainfall records as an illustration of 2D arrays
        // 2007 was a year of major flooding in early June

        // It's 'natural' to enter these values a month at a time,
        // but we'll be displaying them with days of month on the vertical,
        // so they will need transposing for display

        // I want to use 1-12 and 1-31 as the indexes, so I need to enter a whole
        // row of extra 0s at the start, and an extra 0 at the start of each row.
        // The array is thus int[13,32], with index 0-12 and 0-31.

        // Remember, nobody would normally enter data like this; it'd be loaded from a database or other file

        int[,] iRainfall = 
                {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 2, 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 44, 0, 0, 0, 0, 0, 0}, //Jan
                {0, 1, 0, 0, 0, 0, 0, 0, 14, 0, 0, 25, 7, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 13, 1, 36, 1, 0, 0, 0}, //Feb
                {0, 8, 5, 0, 0, 14, 0, 0, 1, 8, 0, 0, 4, 0, 0, 0, 0, 0, 6, 1, 0, 22, 0, 0, 0, 22, 10, 4, 0, 0, 0, 0}, //Mar
                {0, 0, 0, 0, 2, 0, 4, 18, 4, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 33, 59, 18, 0, 14, 0, 0, 0}, //Apr
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 2, 0, 0, 0, 0, 0, 0, 4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0}, //May
                {0, 0, 0, 0, 0, 0, 0, 19, 85, 383, 42, 1, 0, 0, 0, 0, 35, 41, 11, 34, 20, 0, 0, 0, 0, 12, 7, 10, 0, 3, 0, 0}, //Jun
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 18, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0}, //Jul
                {0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 118, 12, 7, 1, 0, 1, 0, 0, 0, 0, 0, 0}, //Aug
                {0, 0, 0, 0, 2, 3, 2, 6, 11, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 1, 0, 0, 0, 0}, //Sep
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 13, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 0, 0, 0, 0}, //Oct
                {0, 0, 0, 22, 10, 0, 1, 1, 11, 11, 24, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 3, 4, 1, 0, 0, 0, 0, 7, 0}, //Nov
                {0, 4, 28, 0, 38, 10, 1, 0, 0, 7, 26, 3, 2, 1, 0, 4, 0, 10, 0, 5, 2, 0, 8, 4, 0, 1, 0, 0, 0, 0, 0, 0}}; //Dec

        public RainfallDemo()
        {
            InitializeComponent();
            // Once the form is drawn, set up the rainfall display
            // Put numbers 1-31 down the left of the display
            TbxSideScale.Clear();
            for (int i = 1; i <= 31; i++)
            {
                TbxSideScale.AppendText(Convert.ToString(i) + "\r\n");
            }
            // And months along the top
            TbxTopScale.Text = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec";
            // Now display the rainfall as recorded
            Display(iRainfall);

            // Confirm the size of the array - a debugging aid
            MessageBox.Show(string.Format("Rainfall array size [{0:d},{1:d}]", iRainfall.GetLength(0), iRainfall.GetLength(1)), "Debugging aid");
        }

        private void Display(int[,] iGrid)
        {   // Display the whole rainfall chart in txbxRainGrid
            TbxRainGrid.Clear();
            int iYearTotal = 0;

            // Here we transpose the array by looping the first index within the second

            // Because we're ignoring the 0 indexes, we loop not <= getLength but < getLength,
            // as the length is 1 more than the number of actual values
            for (int iDay = 1; iDay < iGrid.GetLength(1); iDay++)
            {
                for (int iMonth = 1; iMonth < iGrid.GetLength(0); iMonth++)
                {
                    TbxRainGrid.AppendText(RightAlign(iGrid[iMonth, iDay], 4));
                    iYearTotal = iYearTotal + iGrid[iMonth, iDay];
                }
                if (iDay < iGrid.GetLength(1) - 1) // Don't 'press Enter' on the last line
                    TbxRainGrid.AppendText("\r\n");
            }
            // Display the total for the year
            LblYearRainfall.Text = string.Format("{0:d}mm", iYearTotal);
        } // end Display

        private string RightAlign(int iNum, int iSize)
        {   // Right-align (non-negative) iNum by left padding with spaces to iSize
            // BUT returning all blanks if iNum is zero
            if (iNum > 0)
            {
                return Convert.ToString(iNum).PadLeft(iSize);
            }
            else
            {
                return " ".PadLeft(iSize);
            }
        } // end RightAlign

        private void BtnAcceptEntry_Click(object sender, EventArgs e)
        {   // Accept a day's rainfall into the array
            int iDay = 0, iMonth = 0, iRain;
            try
            {
                iDay = Convert.ToInt32(TbxDayNum.Text);
                iMonth = Convert.ToInt32(TbxMonthNum.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter a day number and month number", "Data required");
            }
            if (iDay < 1 || iDay > 31 || iMonth < 1 || iMonth > 12)
            // A good program would do a better validity check
            {
                MessageBox.Show("Please enter valid day and month numbers", "Invalid date");
            }
            else
            {   // Assume non-numeric rainfall is zero (and not worth entering!)
                try
                {
                    iRain = Convert.ToInt32(TbxRainfall.Text);
                }
                catch (Exception ex)
                {
                    iRain = 0;
                }
                // Remember, first index is month
                iRainfall[iMonth, iDay] = iRain;
            }
            // Display the updated rainfall chart
            Display(iRainfall);
        }  // end BtnAcceptEntry_Click

        private void BtnSaveFigures_Click(object sender, EventArgs e)
        {   // This should save the rainfall figures, but that's for later implementation
            MessageBox.Show("Saving to database not yet implemented", "Work in progress");
        }

        private void BtnDisplayMonth_Click(object sender, EventArgs e)
        {   // Find the month in question, calculate and display the summary for the month
            int iMonth = 0;
            try
            {
                iMonth = Convert.ToInt32(TbxMonthNum2.Text);
                if (iMonth < 1 || iMonth > 12)
                {
                    MessageBox.Show("Please enter a month number from 1 to 12", "Invalid data");
                }
                else
                {
                    ShowFigures(iRainfall, iMonth);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter a valid month number", "Missing data");
            }
        }

        private void ShowFigures(int[,] iGrid, int iMonth)
        {   // Calculate and show the figures for a single month
            int iDays = 0, iTotal = 0, iMax = iGrid[iMonth, 1];
            for (int iDay = 1; iDay < iGrid.GetLength(1); iDay++)
            {
                iTotal = iTotal + iGrid[iMonth, iDay];
                if (iGrid[iMonth, iDay] > 0) iDays = iDays + 1; // Count days with rain
                if (iGrid[iMonth, iDay] > iMax) iMax = iGrid[iMonth, iDay]; // Find day with most rain
            }
            LblDaysRain.Text = Convert.ToString(iDays);
            LblTotalRain.Text = Convert.ToString(iTotal) + "mm";
            LblMostRain.Text = Convert.ToString(iMax) + "mm";
        } // end ShowFigures

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {   // Close this form and return to the main menu form
            this.Dispose();
        }

    } // end class
} // end namespace

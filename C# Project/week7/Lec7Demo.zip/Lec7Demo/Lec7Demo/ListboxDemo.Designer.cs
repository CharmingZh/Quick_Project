﻿namespace Lec7Demo
{
    partial class ListboxDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.TbxInput = new System.Windows.Forms.TextBox();
            this.BtnMainMenu = new System.Windows.Forms.Button();
            this.BtnCount = new System.Windows.Forms.Button();
            this.BtnDeselect = new System.Windows.Forms.Button();
            this.BtnRemove = new System.Windows.Forms.Button();
            this.BtnInsert = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.TbxSelected = new System.Windows.Forms.TextBox();
            this.LstbxCourse = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(227, 109);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(100, 23);
            this.Label2.TabIndex = 54;
            this.Label2.Text = "Selected item";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(227, 37);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(100, 23);
            this.Label1.TabIndex = 53;
            this.Label1.Text = "Input";
            // 
            // TbxInput
            // 
            this.TbxInput.Location = new System.Drawing.Point(219, 61);
            this.TbxInput.Name = "TbxInput";
            this.TbxInput.Size = new System.Drawing.Size(104, 20);
            this.TbxInput.TabIndex = 52;
            // 
            // BtnMainMenu
            // 
            this.BtnMainMenu.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnMainMenu.Location = new System.Drawing.Point(230, 309);
            this.BtnMainMenu.Name = "BtnMainMenu";
            this.BtnMainMenu.Size = new System.Drawing.Size(124, 23);
            this.BtnMainMenu.TabIndex = 51;
            this.BtnMainMenu.Text = "Return to main menu";
            this.BtnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // BtnCount
            // 
            this.BtnCount.Location = new System.Drawing.Point(43, 181);
            this.BtnCount.Name = "BtnCount";
            this.BtnCount.Size = new System.Drawing.Size(152, 23);
            this.BtnCount.TabIndex = 50;
            this.BtnCount.Text = "How many courses?";
            this.BtnCount.Click += new System.EventHandler(this.BtnCount_Click);
            // 
            // BtnDeselect
            // 
            this.BtnDeselect.Location = new System.Drawing.Point(43, 309);
            this.BtnDeselect.Name = "BtnDeselect";
            this.BtnDeselect.Size = new System.Drawing.Size(152, 23);
            this.BtnDeselect.TabIndex = 49;
            this.BtnDeselect.Text = "Deselect";
            this.BtnDeselect.Click += new System.EventHandler(this.BtnDeselect_Click);
            // 
            // BtnRemove
            // 
            this.BtnRemove.Location = new System.Drawing.Point(43, 213);
            this.BtnRemove.Name = "BtnRemove";
            this.BtnRemove.Size = new System.Drawing.Size(152, 23);
            this.BtnRemove.TabIndex = 48;
            this.BtnRemove.Text = "Remove selected course";
            this.BtnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // BtnInsert
            // 
            this.BtnInsert.Location = new System.Drawing.Point(43, 277);
            this.BtnInsert.Name = "BtnInsert";
            this.BtnInsert.Size = new System.Drawing.Size(152, 23);
            this.BtnInsert.TabIndex = 47;
            this.BtnInsert.Text = "Insert input before selected";
            this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(43, 245);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(152, 23);
            this.BtnAdd.TabIndex = 46;
            this.BtnAdd.Text = "Add input to end of list";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // TbxSelected
            // 
            this.TbxSelected.Location = new System.Drawing.Point(219, 133);
            this.TbxSelected.Name = "TbxSelected";
            this.TbxSelected.Size = new System.Drawing.Size(104, 20);
            this.TbxSelected.TabIndex = 45;
            // 
            // LstbxCourse
            // 
            this.LstbxCourse.Items.AddRange(new object[] {
            "Comp1050",
            "Desn2270",
            "Info1010",
            "Inft1001",
            "Inft1004",
            "Inft2012",
            "Inft3920",
            "Inft3970"});
            this.LstbxCourse.Location = new System.Drawing.Point(59, 21);
            this.LstbxCourse.Name = "LstbxCourse";
            this.LstbxCourse.Size = new System.Drawing.Size(120, 147);
            this.LstbxCourse.TabIndex = 44;
            this.LstbxCourse.SelectedIndexChanged += new System.EventHandler(this.LstbxCourse_SelectedIndexChanged);
            // 
            // ListboxDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BtnMainMenu;
            this.ClientSize = new System.Drawing.Size(384, 352);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TbxInput);
            this.Controls.Add(this.BtnMainMenu);
            this.Controls.Add(this.BtnCount);
            this.Controls.Add(this.BtnDeselect);
            this.Controls.Add(this.BtnRemove);
            this.Controls.Add(this.BtnInsert);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.TbxSelected);
            this.Controls.Add(this.LstbxCourse);
            this.Name = "ListboxDemo";
            this.Text = "Listbox demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TbxInput;
        internal System.Windows.Forms.Button BtnMainMenu;
        internal System.Windows.Forms.Button BtnCount;
        internal System.Windows.Forms.Button BtnDeselect;
        internal System.Windows.Forms.Button BtnRemove;
        internal System.Windows.Forms.Button BtnInsert;
        internal System.Windows.Forms.Button BtnAdd;
        internal System.Windows.Forms.TextBox TbxSelected;
        internal System.Windows.Forms.ListBox LstbxCourse;
    }
}
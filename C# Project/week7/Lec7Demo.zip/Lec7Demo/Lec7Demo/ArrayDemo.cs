﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec7Demo
{
    public partial class ArrayDemo : Form
    {   // Simon, May 2015
        // Last updated August 2021
        // Demonstration of various features of arrays

        // Some string arrays initialised at declaration
        // Suggesting that bridge and patience order the suits differently
        private string[] sBridgeSuit = { "clubs", "diamonds", "hearts", "spades" };
        private string[] sPatienceSuit = { "spades", "hearts", "clubs", "diamonds" };
        private string[] sName = {"Alexis Archer", "Barry Bagsley", "Coralie Creevey", "Donal d'Arques", "Ernestine Eccles", "Frank Fellowes", "Gertrude Gainsborough", "Harry Hotspur",
        "Ilona Iliffe", "Jeremy Janssen", "Kellie Kang", "Laurence Lamprey", "Melissa Mundey", "Ngoc Nguyen", "Ondine Oswald", "Peter Peters", "Queenie Quincy", "Randolph Rush", "Simone Semple",
        "Tony Tan", "Ugberta Urdorfer", "Vinnie Verona", "Wilhelmina Williams", "Xenos Xenophon", "Yolande Yorgensen", "Zeke Zammit"};

        // A constant for the size of the height and weight arrays
        const int iArraySize = 26;  // Will make arrays of 26 elements, indexes 0 to 25

        // A string array to be initialised on form load
        private string[] sCardNum = new string[14];

        // Two double arrays to be initialised on form load
        private double[] dHeight = new double[iArraySize], dWeight = new double[iArraySize];

        public ArrayDemo()
        {  // This is the form constructor
            InitializeComponent();
            // Initialise the card number array, 14 values, ace at either end
            sCardNum[0] = "ace";
            sCardNum[13] = "ace";
            sCardNum[12] = "king";
            sCardNum[11] = "queen";
            sCardNum[10] = "jack";
            for (int i = 1; i <= 9; i++)
            {
                sCardNum[i] = Convert.ToString(i + 1);  // Cards 2 to 10 are numbers
            }

            // Initialise the height and weight arrays with random numbers in suitable ranges
            Random rand = new Random();
            for (int i = 0; i < iArraySize; i++)
            {
                // Random weight between 60 and 120
                // Random.NextDouble gives a random number between 0 and 1
                dWeight[i] = 60 + 60 * rand.NextDouble();
                // Random height between 1.4 and 2.1
                dHeight[i] = 1.4 + 0.7 * rand.NextDouble();
            }
        }  // end of form constructor

        private void Display(string[] ipip)
        {  // Display an array of string in ResultsTxtbx, a line at a time
           // Note that the size of the array is not specified
            TbxResults.Clear();
            // Note that indexes go from 0 to 1 below the length
            for (int i = 0; i < ipip.Length; i++)
            {
                TbxResults.AppendText(ipip[i] + "\r\n");
            }
            bool bCanDrink = ipip.Length >= 18; // Note that this is never used; it's to remind you of boolean assignment
        }  // end Display

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {  // Close this form and return to the main form
            this.Dispose();
        }

        private void BtnBridgeCards_Click(object sender, EventArgs e)
        {  // Build a new array of 52 strings, cards in bridge order, and display it
            string[] sCardName = new string[52];
            // Use a deck counter to work from 0 to 51
            int iDeckCount = 0;
            // Loop through every card number from 2 to ace within every suit
            for (int iSuit = 0; iSuit <= 3; iSuit++)
                for (int iCard = 1; iCard <= 13; iCard++)
                {
                    sCardName[iDeckCount] = sCardNum[iCard] + " of " + sBridgeSuit[iSuit];
                    iDeckCount = iDeckCount + 1;
                }
            Display(sCardName);
        }  // end BtnBridgeCards_Click

        private void BtnPatienceCards_Click(object sender, EventArgs e)
        {   // Build a new array of 52 strings, cards in patience order, and display it
            string[] sCardName = new string[52];
            // Loop through every card number from 2 to ace within every suit
            // Instead of using a deck counter, calculate the index in the deck using
            // the indexes of the suit and card number
            for (int iSuit = 0; iSuit <= 3; iSuit++)
                for (int iCard = 0; iCard <= 12; iCard++)   // ace to king
                {
                    sCardName[iSuit * 13 + iCard] = sCardNum[iCard] + " of " + sPatienceSuit[iSuit];
                }
            Display(sCardName);
        }  // end BtnPatienceCards_Click

        private void BtnNames_Click(object sender, EventArgs e)
        {   // Display the names in the sName array
            Display(sName);
        }   // end BtnNames_Click

        private void BtnNamesPlus_Click(object sender, EventArgs e)
        {   // Build a new array of 26 strings, names + weights + heights, and display it
            string[] sNamePlus = new string[iArraySize];
            for (int i = 0; i < iArraySize; i++)
            {
                sNamePlus[i] = sName[i] + string.Format("  {0:f1}   {0:f2}", dWeight[i], dHeight[i]);
                // Note inclusion in format string of spaces to separate the parts
            }
            Display(sNamePlus);
        }  // end BtnNamesPlus_Click

        private void BtnSearch_Click(object sender, EventArgs e)
        {   // Search for the name provided; if found, display weight & height
            bool bFound = false;
            if (TbxName.Text == "")
            {
                MessageBox.Show("Type the name you're looking for to the right of Search", "Name required");
            }
            else
            {
                // Search the array, element at a time, for the name provided
                int i = 0;
                do
                {
                    if (sName[i] == TbxName.Text)
                    {
                        bFound = true;
                    }
                    else
                    {
                        i = i + 1;
                    }
                }
                while (i < iArraySize && !bFound);

                // Either the name has been found, at index i . . .
                if (bFound)
                {
                    LblWeight.Text = string.Format("  {0:f1}", dWeight[i]);
                    LblHeight.Text = string.Format("  {0:f2}", dHeight[i]);
                }
                // or the whole array has been searched without success
                else
                {
                    MessageBox.Show("That name is not in our records", "Name not found");
                }
            }  // end else
        }  // end BtnSearch_Click

    }  // end class
}  // end namespace

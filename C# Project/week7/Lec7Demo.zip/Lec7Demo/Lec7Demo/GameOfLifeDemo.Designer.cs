﻿namespace Lec7Demo
{
    partial class GameOfLifeDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblGenCount = new System.Windows.Forms.Label();
            this.LblStopped = new System.Windows.Forms.Label();
            this.LblAllDead = new System.Windows.Forms.Label();
            this.TbxSideScale = new System.Windows.Forms.TextBox();
            this.TbxLifeBoard = new System.Windows.Forms.TextBox();
            this.TbxTopScale = new System.Windows.Forms.TextBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.TbxDemoNum = new System.Windows.Forms.TextBox();
            this.BtnSetDemo = new System.Windows.Forms.Button();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnSingleStep = new System.Windows.Forms.Button();
            this.BtnRun = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.TbxAcross = new System.Windows.Forms.TextBox();
            this.TbxDown = new System.Windows.Forms.TextBox();
            this.LblAcross = new System.Windows.Forms.Label();
            this.LblDown = new System.Windows.Forms.Label();
            this.BtnFlip = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TkbarSpeed = new System.Windows.Forms.TrackBar();
            this.TmrClock = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnMainMenu = new System.Windows.Forms.Button();
            this.GroupBox2.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TkbarSpeed)).BeginInit();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblGenCount
            // 
            this.LblGenCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGenCount.Location = new System.Drawing.Point(16, 533);
            this.LblGenCount.Name = "LblGenCount";
            this.LblGenCount.Size = new System.Drawing.Size(80, 32);
            this.LblGenCount.TabIndex = 59;
            this.LblGenCount.Text = "Generation 0";
            this.LblGenCount.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LblStopped
            // 
            this.LblStopped.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblStopped.Location = new System.Drawing.Point(16, 491);
            this.LblStopped.Name = "LblStopped";
            this.LblStopped.Size = new System.Drawing.Size(88, 24);
            this.LblStopped.TabIndex = 58;
            this.LblStopped.Text = "Run stopped.";
            this.LblStopped.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LblStopped.Visible = false;
            // 
            // LblAllDead
            // 
            this.LblAllDead.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAllDead.Location = new System.Drawing.Point(16, 410);
            this.LblAllDead.Name = "LblAllDead";
            this.LblAllDead.Size = new System.Drawing.Size(88, 70);
            this.LblAllDead.TabIndex = 57;
            this.LblAllDead.Text = "They\'re dead, Dave. They\'re all dead, Dave.";
            this.LblAllDead.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LblAllDead.Visible = false;
            // 
            // TbxSideScale
            // 
            this.TbxSideScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxSideScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxSideScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxSideScale.Location = new System.Drawing.Point(104, 48);
            this.TbxSideScale.Multiline = true;
            this.TbxSideScale.Name = "TbxSideScale";
            this.TbxSideScale.Size = new System.Drawing.Size(32, 512);
            this.TbxSideScale.TabIndex = 56;
            this.TbxSideScale.TabStop = false;
            this.TbxSideScale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TbxLifeBoard
            // 
            this.TbxLifeBoard.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxLifeBoard.Location = new System.Drawing.Point(144, 45);
            this.TbxLifeBoard.Multiline = true;
            this.TbxLifeBoard.Name = "TbxLifeBoard";
            this.TbxLifeBoard.Size = new System.Drawing.Size(512, 512);
            this.TbxLifeBoard.TabIndex = 54;
            this.TbxLifeBoard.TabStop = false;
            // 
            // TbxTopScale
            // 
            this.TbxTopScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxTopScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxTopScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxTopScale.Location = new System.Drawing.Point(147, 13);
            this.TbxTopScale.Multiline = true;
            this.TbxTopScale.Name = "TbxTopScale";
            this.TbxTopScale.Size = new System.Drawing.Size(512, 32);
            this.TbxTopScale.TabIndex = 55;
            this.TbxTopScale.TabStop = false;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.TbxDemoNum);
            this.GroupBox2.Controls.Add(this.BtnSetDemo);
            this.GroupBox2.Location = new System.Drawing.Point(16, 173);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(88, 88);
            this.GroupBox2.TabIndex = 60;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Demos 1-7";
            // 
            // TbxDemoNum
            // 
            this.TbxDemoNum.Location = new System.Drawing.Point(32, 24);
            this.TbxDemoNum.Name = "TbxDemoNum";
            this.TbxDemoNum.Size = new System.Drawing.Size(24, 20);
            this.TbxDemoNum.TabIndex = 18;
            // 
            // BtnSetDemo
            // 
            this.BtnSetDemo.Location = new System.Drawing.Point(7, 56);
            this.BtnSetDemo.Name = "BtnSetDemo";
            this.BtnSetDemo.Size = new System.Drawing.Size(75, 23);
            this.BtnSetDemo.TabIndex = 17;
            this.BtnSetDemo.Text = "Set demo";
            this.BtnSetDemo.Click += new System.EventHandler(this.BtnSetDemo_Click);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.BtnSingleStep);
            this.GroupBox3.Controls.Add(this.BtnRun);
            this.GroupBox3.Controls.Add(this.BtnStop);
            this.GroupBox3.Location = new System.Drawing.Point(16, 277);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(88, 120);
            this.GroupBox3.TabIndex = 61;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Run/stop";
            // 
            // BtnSingleStep
            // 
            this.BtnSingleStep.Location = new System.Drawing.Point(8, 24);
            this.BtnSingleStep.Name = "BtnSingleStep";
            this.BtnSingleStep.Size = new System.Drawing.Size(75, 23);
            this.BtnSingleStep.TabIndex = 12;
            this.BtnSingleStep.Text = "Single step";
            this.BtnSingleStep.Click += new System.EventHandler(this.BtnSingleStep_Click);
            // 
            // BtnRun
            // 
            this.BtnRun.Location = new System.Drawing.Point(8, 56);
            this.BtnRun.Name = "BtnRun";
            this.BtnRun.Size = new System.Drawing.Size(75, 23);
            this.BtnRun.TabIndex = 6;
            this.BtnRun.Text = "Run";
            this.BtnRun.Click += new System.EventHandler(this.BtnRun_Click);
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(8, 88);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(75, 23);
            this.BtnStop.TabIndex = 7;
            this.BtnStop.Text = "Stop";
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // TbxAcross
            // 
            this.TbxAcross.Location = new System.Drawing.Point(56, 80);
            this.TbxAcross.Name = "TbxAcross";
            this.TbxAcross.Size = new System.Drawing.Size(24, 20);
            this.TbxAcross.TabIndex = 1;
            // 
            // TbxDown
            // 
            this.TbxDown.Location = new System.Drawing.Point(56, 48);
            this.TbxDown.Name = "TbxDown";
            this.TbxDown.Size = new System.Drawing.Size(24, 20);
            this.TbxDown.TabIndex = 0;
            // 
            // LblAcross
            // 
            this.LblAcross.Location = new System.Drawing.Point(8, 80);
            this.LblAcross.Name = "LblAcross";
            this.LblAcross.Size = new System.Drawing.Size(40, 23);
            this.LblAcross.TabIndex = 3;
            this.LblAcross.Text = "Across";
            this.LblAcross.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblDown
            // 
            this.LblDown.Location = new System.Drawing.Point(8, 48);
            this.LblDown.Name = "LblDown";
            this.LblDown.Size = new System.Drawing.Size(40, 23);
            this.LblDown.TabIndex = 4;
            this.LblDown.Text = "Down";
            this.LblDown.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnFlip
            // 
            this.BtnFlip.Location = new System.Drawing.Point(8, 112);
            this.BtnFlip.Name = "BtnFlip";
            this.BtnFlip.Size = new System.Drawing.Size(75, 23);
            this.BtnFlip.TabIndex = 5;
            this.BtnFlip.Text = "Flip cell";
            this.BtnFlip.Click += new System.EventHandler(this.BtnFlip_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(8, 16);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(75, 23);
            this.BtnClear.TabIndex = 15;
            this.BtnClear.Text = "Clear board";
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(176, 571);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 63;
            this.label1.Text = "Slower";
            // 
            // TkbarSpeed
            // 
            this.TkbarSpeed.Location = new System.Drawing.Point(217, 564);
            this.TkbarSpeed.Name = "TkbarSpeed";
            this.TkbarSpeed.Size = new System.Drawing.Size(379, 45);
            this.TkbarSpeed.TabIndex = 62;
            this.TkbarSpeed.Value = 3;
            this.TkbarSpeed.Scroll += new System.EventHandler(this.TkbarSpeed_Scroll);
            // 
            // TmrClock
            // 
            this.TmrClock.Interval = 512;
            this.TmrClock.Tick += new System.EventHandler(this.TmrClock_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(602, 571);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 64;
            this.label2.Text = "Faster";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.TbxAcross);
            this.GroupBox1.Controls.Add(this.TbxDown);
            this.GroupBox1.Controls.Add(this.LblAcross);
            this.GroupBox1.Controls.Add(this.LblDown);
            this.GroupBox1.Controls.Add(this.BtnFlip);
            this.GroupBox1.Controls.Add(this.BtnClear);
            this.GroupBox1.Location = new System.Drawing.Point(16, 13);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(88, 144);
            this.GroupBox1.TabIndex = 53;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Manual";
            // 
            // BtnMainMenu
            // 
            this.BtnMainMenu.Location = new System.Drawing.Point(10, 582);
            this.BtnMainMenu.Name = "BtnMainMenu";
            this.BtnMainMenu.Size = new System.Drawing.Size(120, 23);
            this.BtnMainMenu.TabIndex = 65;
            this.BtnMainMenu.Text = "Return to main menu";
            this.BtnMainMenu.UseVisualStyleBackColor = true;
            this.BtnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // GameOfLifeDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 622);
            this.Controls.Add(this.BtnMainMenu);
            this.Controls.Add(this.LblGenCount);
            this.Controls.Add(this.LblStopped);
            this.Controls.Add(this.LblAllDead);
            this.Controls.Add(this.TbxSideScale);
            this.Controls.Add(this.TbxLifeBoard);
            this.Controls.Add(this.TbxTopScale);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TkbarSpeed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.GroupBox1);
            this.Name = "GameOfLifeDemo";
            this.Text = "John Conway\'s Game of Life";
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TkbarSpeed)).EndInit();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label LblGenCount;
        internal System.Windows.Forms.Label LblStopped;
        internal System.Windows.Forms.Label LblAllDead;
        internal System.Windows.Forms.TextBox TbxSideScale;
        internal System.Windows.Forms.TextBox TbxLifeBoard;
        internal System.Windows.Forms.TextBox TbxTopScale;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TextBox TbxDemoNum;
        internal System.Windows.Forms.Button BtnSetDemo;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Button BtnSingleStep;
        internal System.Windows.Forms.Button BtnRun;
        internal System.Windows.Forms.Button BtnStop;
        internal System.Windows.Forms.TextBox TbxAcross;
        internal System.Windows.Forms.TextBox TbxDown;
        internal System.Windows.Forms.Label LblAcross;
        internal System.Windows.Forms.Label LblDown;
        internal System.Windows.Forms.Button BtnFlip;
        internal System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar TkbarSpeed;
        internal System.Windows.Forms.Timer TmrClock;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.Button BtnMainMenu;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec7Demo
{
    public partial class ListboxDemo : Form
    {   // Simon, May 2015
        // Last updated August 2021
        // Simple illustration of some features of listboxes

        public ListboxDemo()
        {
            InitializeComponent();
        }

        private void BtnCount_Click(object sender, EventArgs e)
        {   // Display the number of items in the listbox
            MessageBox.Show("Number of items: " + Convert.ToString(LstbxCourse.Items.Count));
        }

        private void LstbxCourse_SelectedIndexChanged(object sender, EventArgs e)
        {   // Whenever the selection changes, display the selected item and its index
            if (LstbxCourse.SelectedIndex >= 0)
            {
                TbxSelected.Text = string.Format("{0:d}: ", LstbxCourse.SelectedIndex) +
                    LstbxCourse.Text;
            }
            else
            {
                TbxSelected.Clear();  // Because it's just become deselected
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {   // Remove the selected item from the listbox
            if (LstbxCourse.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a course before clicking that button", "Choose course");
            }
            else
            {
                int index = LstbxCourse.SelectedIndex; // Keep so as to select next item
                LstbxCourse.Items.RemoveAt(LstbxCourse.SelectedIndex);
                // Select next item; not necessary, but makes some sense
                if (index < LstbxCourse.Items.Count)
                {
                    LstbxCourse.SelectedIndex = index;
                }
                else if (LstbxCourse.Items.Count > 0)
                {
                    LstbxCourse.SelectedIndex = LstbxCourse.Items.Count - 1;
                }
            }
        }  // end of btnRemove_Click

        private void BtnAdd_Click(object sender, EventArgs e)
        {   // Add the course in the input box to the end of the list
            LstbxCourse.Items.Add(TbxInput.Text);
            // Select the item that was just added; not necessary, but makes sense
            LstbxCourse.SelectedIndex = LstbxCourse.Items.Count - 1;
            TbxInput.Clear();
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            if (LstbxCourse.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a course before clicking that button", "Choose course");
            }
            else
            {
                int index = LstbxCourse.SelectedIndex; // Keep so as to select new item
                LstbxCourse.Items.Insert(LstbxCourse.SelectedIndex, TbxInput.Text);
                // Select the item that was just inserted; not necessary, but makes sense
                LstbxCourse.SelectedIndex = index;
                TbxInput.Clear();
            }
        }

        private void BtnDeselect_Click(object sender, EventArgs e)
        {   // Deselect any selected item in the listbox
            // This will trigger lstbxCourse_SelectedIndexChanged(), which will clear txbxSelected
            LstbxCourse.ClearSelected();
        }

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {   // Close this form and return to the main form
            this.Dispose();
        }

    }  // end class
}  // end namespace

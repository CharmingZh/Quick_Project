﻿namespace Lec7Demo
{
    partial class ArrayDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnPatienceCards = new System.Windows.Forms.Button();
            this.LblHeight = new System.Windows.Forms.Label();
            this.LblWeight = new System.Windows.Forms.Label();
            this.LblHt = new System.Windows.Forms.Label();
            this.LblWgt = new System.Windows.Forms.Label();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnNamesPlus = new System.Windows.Forms.Button();
            this.BtnNames = new System.Windows.Forms.Button();
            this.BtnBridgeCards = new System.Windows.Forms.Button();
            this.TbxResults = new System.Windows.Forms.TextBox();
            this.BtnMainMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnPatienceCards
            // 
            this.BtnPatienceCards.Location = new System.Drawing.Point(12, 65);
            this.BtnPatienceCards.Name = "BtnPatienceCards";
            this.BtnPatienceCards.Size = new System.Drawing.Size(88, 23);
            this.BtnPatienceCards.TabIndex = 54;
            this.BtnPatienceCards.Text = "Patience cards";
            this.BtnPatienceCards.Click += new System.EventHandler(this.BtnPatienceCards_Click);
            // 
            // LblHeight
            // 
            this.LblHeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblHeight.Location = new System.Drawing.Point(116, 265);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(56, 23);
            this.LblHeight.TabIndex = 53;
            this.LblHeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblWeight
            // 
            this.LblWeight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblWeight.Location = new System.Drawing.Point(116, 225);
            this.LblWeight.Name = "LblWeight";
            this.LblWeight.Size = new System.Drawing.Size(56, 23);
            this.LblWeight.TabIndex = 52;
            this.LblWeight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblHt
            // 
            this.LblHt.Location = new System.Drawing.Point(44, 265);
            this.LblHt.Name = "LblHt";
            this.LblHt.Size = new System.Drawing.Size(56, 23);
            this.LblHt.TabIndex = 51;
            this.LblHt.Text = "Height";
            this.LblHt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblWgt
            // 
            this.LblWgt.Location = new System.Drawing.Point(44, 225);
            this.LblWgt.Name = "LblWgt";
            this.LblWgt.Size = new System.Drawing.Size(56, 23);
            this.LblWgt.TabIndex = 50;
            this.LblWgt.Text = "Weight";
            this.LblWgt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TbxName
            // 
            this.TbxName.Location = new System.Drawing.Point(116, 185);
            this.TbxName.Name = "TbxName";
            this.TbxName.Size = new System.Drawing.Size(104, 20);
            this.TbxName.TabIndex = 49;
            // 
            // BtnSearch
            // 
            this.BtnSearch.Location = new System.Drawing.Point(12, 185);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(88, 23);
            this.BtnSearch.TabIndex = 48;
            this.BtnSearch.Text = "Search for";
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnNamesPlus
            // 
            this.BtnNamesPlus.Location = new System.Drawing.Point(12, 145);
            this.BtnNamesPlus.Name = "BtnNamesPlus";
            this.BtnNamesPlus.Size = new System.Drawing.Size(88, 23);
            this.BtnNamesPlus.TabIndex = 47;
            this.BtnNamesPlus.Text = "Names etc";
            this.BtnNamesPlus.Click += new System.EventHandler(this.BtnNamesPlus_Click);
            // 
            // BtnNames
            // 
            this.BtnNames.Location = new System.Drawing.Point(12, 105);
            this.BtnNames.Name = "BtnNames";
            this.BtnNames.Size = new System.Drawing.Size(88, 23);
            this.BtnNames.TabIndex = 46;
            this.BtnNames.Text = "Names";
            this.BtnNames.Click += new System.EventHandler(this.BtnNames_Click);
            // 
            // BtnBridgeCards
            // 
            this.BtnBridgeCards.Location = new System.Drawing.Point(12, 25);
            this.BtnBridgeCards.Name = "BtnBridgeCards";
            this.BtnBridgeCards.Size = new System.Drawing.Size(88, 23);
            this.BtnBridgeCards.TabIndex = 45;
            this.BtnBridgeCards.Text = "Bridge cards";
            this.BtnBridgeCards.Click += new System.EventHandler(this.BtnBridgeCards_Click);
            // 
            // TbxResults
            // 
            this.TbxResults.Location = new System.Drawing.Point(236, 8);
            this.TbxResults.Multiline = true;
            this.TbxResults.Name = "TbxResults";
            this.TbxResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxResults.Size = new System.Drawing.Size(200, 360);
            this.TbxResults.TabIndex = 44;
            // 
            // BtnMainMenu
            // 
            this.BtnMainMenu.Location = new System.Drawing.Point(12, 333);
            this.BtnMainMenu.Name = "BtnMainMenu";
            this.BtnMainMenu.Size = new System.Drawing.Size(139, 23);
            this.BtnMainMenu.TabIndex = 55;
            this.BtnMainMenu.Text = "Return to main menu";
            this.BtnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // ArrayDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 377);
            this.Controls.Add(this.BtnMainMenu);
            this.Controls.Add(this.BtnPatienceCards);
            this.Controls.Add(this.LblHeight);
            this.Controls.Add(this.LblWeight);
            this.Controls.Add(this.LblHt);
            this.Controls.Add(this.LblWgt);
            this.Controls.Add(this.TbxName);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.BtnNamesPlus);
            this.Controls.Add(this.BtnNames);
            this.Controls.Add(this.BtnBridgeCards);
            this.Controls.Add(this.TbxResults);
            this.Name = "ArrayDemo";
            this.Text = "Array demonstration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BtnPatienceCards;
        internal System.Windows.Forms.Label LblHeight;
        internal System.Windows.Forms.Label LblWeight;
        internal System.Windows.Forms.Label LblHt;
        internal System.Windows.Forms.Label LblWgt;
        internal System.Windows.Forms.TextBox TbxName;
        internal System.Windows.Forms.Button BtnSearch;
        internal System.Windows.Forms.Button BtnNamesPlus;
        internal System.Windows.Forms.Button BtnNames;
        internal System.Windows.Forms.Button BtnBridgeCards;
        internal System.Windows.Forms.TextBox TbxResults;
        internal System.Windows.Forms.Button BtnMainMenu;
    }
}
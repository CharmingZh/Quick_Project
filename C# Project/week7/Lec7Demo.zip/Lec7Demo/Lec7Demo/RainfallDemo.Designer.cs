﻿namespace Lec7Demo
{
    partial class RainfallDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.LblMostRain = new System.Windows.Forms.Label();
            this.LblTotalRain = new System.Windows.Forms.Label();
            this.LblDaysRain = new System.Windows.Forms.Label();
            this.LblMost = new System.Windows.Forms.Label();
            this.LblTotal = new System.Windows.Forms.Label();
            this.LblDays = new System.Windows.Forms.Label();
            this.LblMonthN2 = new System.Windows.Forms.Label();
            this.TbxMonthNum2 = new System.Windows.Forms.TextBox();
            this.BtnDisplayMonth = new System.Windows.Forms.Button();
            this.LblMonthN = new System.Windows.Forms.Label();
            this.TbxRainGrid = new System.Windows.Forms.TextBox();
            this.LblYearRainfall = new System.Windows.Forms.Label();
            this.LblYear = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnSaveFigures = new System.Windows.Forms.Button();
            this.TbxDayNum = new System.Windows.Forms.TextBox();
            this.LblDayN = new System.Windows.Forms.Label();
            this.TbxRainfall = new System.Windows.Forms.TextBox();
            this.TbxMonthNum = new System.Windows.Forms.TextBox();
            this.LblRainfall = new System.Windows.Forms.Label();
            this.BtnAcceptEntry = new System.Windows.Forms.Button();
            this.TbxTopScale = new System.Windows.Forms.TextBox();
            this.TbxSideScale = new System.Windows.Forms.TextBox();
            this.BtnMainMenu = new System.Windows.Forms.Button();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.LblMostRain);
            this.GroupBox2.Controls.Add(this.LblTotalRain);
            this.GroupBox2.Controls.Add(this.LblDaysRain);
            this.GroupBox2.Controls.Add(this.LblMost);
            this.GroupBox2.Controls.Add(this.LblTotal);
            this.GroupBox2.Controls.Add(this.LblDays);
            this.GroupBox2.Controls.Add(this.LblMonthN2);
            this.GroupBox2.Controls.Add(this.TbxMonthNum2);
            this.GroupBox2.Controls.Add(this.BtnDisplayMonth);
            this.GroupBox2.Location = new System.Drawing.Point(20, 218);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(240, 176);
            this.GroupBox2.TabIndex = 52;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Month\'s figures";
            // 
            // LblMostRain
            // 
            this.LblMostRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMostRain.Location = new System.Drawing.Point(136, 144);
            this.LblMostRain.Name = "LblMostRain";
            this.LblMostRain.Size = new System.Drawing.Size(64, 16);
            this.LblMostRain.TabIndex = 25;
            this.LblMostRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblTotalRain
            // 
            this.LblTotalRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTotalRain.Location = new System.Drawing.Point(136, 112);
            this.LblTotalRain.Name = "LblTotalRain";
            this.LblTotalRain.Size = new System.Drawing.Size(64, 16);
            this.LblTotalRain.TabIndex = 24;
            this.LblTotalRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblDaysRain
            // 
            this.LblDaysRain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDaysRain.Location = new System.Drawing.Point(136, 80);
            this.LblDaysRain.Name = "LblDaysRain";
            this.LblDaysRain.Size = new System.Drawing.Size(32, 16);
            this.LblDaysRain.TabIndex = 23;
            this.LblDaysRain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblMost
            // 
            this.LblMost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMost.Location = new System.Drawing.Point(16, 144);
            this.LblMost.Name = "LblMost";
            this.LblMost.Size = new System.Drawing.Size(112, 16);
            this.LblMost.TabIndex = 22;
            this.LblMost.Text = "Most in one day:";
            this.LblMost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblTotal
            // 
            this.LblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTotal.Location = new System.Drawing.Point(40, 112);
            this.LblTotal.Name = "LblTotal";
            this.LblTotal.Size = new System.Drawing.Size(88, 16);
            this.LblTotal.TabIndex = 21;
            this.LblTotal.Text = "Total rain:";
            this.LblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblDays
            // 
            this.LblDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDays.Location = new System.Drawing.Point(40, 80);
            this.LblDays.Name = "LblDays";
            this.LblDays.Size = new System.Drawing.Size(88, 16);
            this.LblDays.TabIndex = 20;
            this.LblDays.Text = "Days of rain:";
            this.LblDays.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblMonthN2
            // 
            this.LblMonthN2.Location = new System.Drawing.Point(24, 32);
            this.LblMonthN2.Name = "LblMonthN2";
            this.LblMonthN2.Size = new System.Drawing.Size(80, 23);
            this.LblMonthN2.TabIndex = 19;
            this.LblMonthN2.Text = "Month number";
            this.LblMonthN2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxMonthNum2
            // 
            this.TbxMonthNum2.Location = new System.Drawing.Point(112, 32);
            this.TbxMonthNum2.Name = "TbxMonthNum2";
            this.TbxMonthNum2.Size = new System.Drawing.Size(24, 20);
            this.TbxMonthNum2.TabIndex = 18;
            // 
            // BtnDisplayMonth
            // 
            this.BtnDisplayMonth.Location = new System.Drawing.Point(152, 32);
            this.BtnDisplayMonth.Name = "BtnDisplayMonth";
            this.BtnDisplayMonth.Size = new System.Drawing.Size(75, 23);
            this.BtnDisplayMonth.TabIndex = 17;
            this.BtnDisplayMonth.Text = "Display";
            this.BtnDisplayMonth.Click += new System.EventHandler(this.BtnDisplayMonth_Click);
            // 
            // LblMonthN
            // 
            this.LblMonthN.Location = new System.Drawing.Point(24, 64);
            this.LblMonthN.Name = "LblMonthN";
            this.LblMonthN.Size = new System.Drawing.Size(80, 23);
            this.LblMonthN.TabIndex = 4;
            this.LblMonthN.Text = "Month number";
            this.LblMonthN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxRainGrid
            // 
            this.TbxRainGrid.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxRainGrid.Location = new System.Drawing.Point(332, 38);
            this.TbxRainGrid.Multiline = true;
            this.TbxRainGrid.Name = "TbxRainGrid";
            this.TbxRainGrid.Size = new System.Drawing.Size(344, 440);
            this.TbxRainGrid.TabIndex = 49;
            this.TbxRainGrid.TabStop = false;
            // 
            // LblYearRainfall
            // 
            this.LblYearRainfall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblYearRainfall.Location = new System.Drawing.Point(156, 418);
            this.LblYearRainfall.Name = "LblYearRainfall";
            this.LblYearRainfall.Size = new System.Drawing.Size(64, 16);
            this.LblYearRainfall.TabIndex = 54;
            this.LblYearRainfall.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblYear
            // 
            this.LblYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblYear.Location = new System.Drawing.Point(52, 418);
            this.LblYear.Name = "LblYear";
            this.LblYear.Size = new System.Drawing.Size(96, 16);
            this.LblYear.TabIndex = 53;
            this.LblYear.Text = "Year\'s rainfall:";
            this.LblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.BtnSaveFigures);
            this.GroupBox1.Controls.Add(this.TbxDayNum);
            this.GroupBox1.Controls.Add(this.LblDayN);
            this.GroupBox1.Controls.Add(this.TbxRainfall);
            this.GroupBox1.Controls.Add(this.TbxMonthNum);
            this.GroupBox1.Controls.Add(this.LblRainfall);
            this.GroupBox1.Controls.Add(this.LblMonthN);
            this.GroupBox1.Controls.Add(this.BtnAcceptEntry);
            this.GroupBox1.Location = new System.Drawing.Point(20, 34);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(240, 144);
            this.GroupBox1.TabIndex = 48;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Data entry";
            // 
            // BtnSaveFigures
            // 
            this.BtnSaveFigures.Location = new System.Drawing.Point(152, 88);
            this.BtnSaveFigures.Name = "BtnSaveFigures";
            this.BtnSaveFigures.Size = new System.Drawing.Size(75, 23);
            this.BtnSaveFigures.TabIndex = 8;
            this.BtnSaveFigures.Text = "Save figures";
            this.BtnSaveFigures.Click += new System.EventHandler(this.BtnSaveFigures_Click);
            // 
            // TbxDayNum
            // 
            this.TbxDayNum.Location = new System.Drawing.Point(112, 32);
            this.TbxDayNum.Name = "TbxDayNum";
            this.TbxDayNum.Size = new System.Drawing.Size(24, 20);
            this.TbxDayNum.TabIndex = 0;
            // 
            // LblDayN
            // 
            this.LblDayN.Location = new System.Drawing.Point(24, 32);
            this.LblDayN.Name = "LblDayN";
            this.LblDayN.Size = new System.Drawing.Size(80, 23);
            this.LblDayN.TabIndex = 7;
            this.LblDayN.Text = "Day number";
            this.LblDayN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TbxRainfall
            // 
            this.TbxRainfall.Location = new System.Drawing.Point(112, 96);
            this.TbxRainfall.Name = "TbxRainfall";
            this.TbxRainfall.Size = new System.Drawing.Size(24, 20);
            this.TbxRainfall.TabIndex = 2;
            // 
            // TbxMonthNum
            // 
            this.TbxMonthNum.Location = new System.Drawing.Point(112, 64);
            this.TbxMonthNum.Name = "TbxMonthNum";
            this.TbxMonthNum.Size = new System.Drawing.Size(24, 20);
            this.TbxMonthNum.TabIndex = 1;
            // 
            // LblRainfall
            // 
            this.LblRainfall.Location = new System.Drawing.Point(24, 96);
            this.LblRainfall.Name = "LblRainfall";
            this.LblRainfall.Size = new System.Drawing.Size(80, 23);
            this.LblRainfall.TabIndex = 3;
            this.LblRainfall.Text = "Rainfall (mm)";
            this.LblRainfall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnAcceptEntry
            // 
            this.BtnAcceptEntry.Location = new System.Drawing.Point(152, 40);
            this.BtnAcceptEntry.Name = "BtnAcceptEntry";
            this.BtnAcceptEntry.Size = new System.Drawing.Size(75, 23);
            this.BtnAcceptEntry.TabIndex = 5;
            this.BtnAcceptEntry.Text = "Accept entry";
            this.BtnAcceptEntry.Click += new System.EventHandler(this.BtnAcceptEntry_Click);
            // 
            // TbxTopScale
            // 
            this.TbxTopScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxTopScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxTopScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxTopScale.Location = new System.Drawing.Point(348, 22);
            this.TbxTopScale.Multiline = true;
            this.TbxTopScale.Name = "TbxTopScale";
            this.TbxTopScale.Size = new System.Drawing.Size(336, 16);
            this.TbxTopScale.TabIndex = 50;
            this.TbxTopScale.TabStop = false;
            // 
            // TbxSideScale
            // 
            this.TbxSideScale.BackColor = System.Drawing.SystemColors.Control;
            this.TbxSideScale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxSideScale.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxSideScale.Location = new System.Drawing.Point(292, 40);
            this.TbxSideScale.Multiline = true;
            this.TbxSideScale.Name = "TbxSideScale";
            this.TbxSideScale.Size = new System.Drawing.Size(32, 440);
            this.TbxSideScale.TabIndex = 51;
            this.TbxSideScale.TabStop = false;
            this.TbxSideScale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnMainMenu
            // 
            this.BtnMainMenu.Location = new System.Drawing.Point(93, 465);
            this.BtnMainMenu.Name = "BtnMainMenu";
            this.BtnMainMenu.Size = new System.Drawing.Size(141, 23);
            this.BtnMainMenu.TabIndex = 55;
            this.BtnMainMenu.Text = "Return to main menu";
            this.BtnMainMenu.UseVisualStyleBackColor = true;
            this.BtnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // RainfallDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 502);
            this.Controls.Add(this.BtnMainMenu);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.TbxRainGrid);
            this.Controls.Add(this.LblYearRainfall);
            this.Controls.Add(this.LblYear);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.TbxTopScale);
            this.Controls.Add(this.TbxSideScale);
            this.Name = "RainfallDemo";
            this.Text = "Wyong rainfall 2007";
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label LblMostRain;
        internal System.Windows.Forms.Label LblTotalRain;
        internal System.Windows.Forms.Label LblDaysRain;
        internal System.Windows.Forms.Label LblMost;
        internal System.Windows.Forms.Label LblTotal;
        internal System.Windows.Forms.Label LblDays;
        internal System.Windows.Forms.Label LblMonthN2;
        internal System.Windows.Forms.TextBox TbxMonthNum2;
        internal System.Windows.Forms.Button BtnDisplayMonth;
        internal System.Windows.Forms.Label LblMonthN;
        internal System.Windows.Forms.TextBox TbxRainGrid;
        internal System.Windows.Forms.Label LblYearRainfall;
        internal System.Windows.Forms.Label LblYear;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Button BtnSaveFigures;
        internal System.Windows.Forms.TextBox TbxDayNum;
        internal System.Windows.Forms.Label LblDayN;
        internal System.Windows.Forms.TextBox TbxRainfall;
        internal System.Windows.Forms.TextBox TbxMonthNum;
        internal System.Windows.Forms.Label LblRainfall;
        internal System.Windows.Forms.Button BtnAcceptEntry;
        internal System.Windows.Forms.TextBox TbxTopScale;
        internal System.Windows.Forms.TextBox TbxSideScale;
        private System.Windows.Forms.Button BtnMainMenu;
    }
}
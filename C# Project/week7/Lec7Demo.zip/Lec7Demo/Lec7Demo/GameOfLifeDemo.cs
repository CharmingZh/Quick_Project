﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec7Demo
{
    public partial class GameOfLifeDemo : Form
    {   // Simon, May 2015
        // Last updated August 2021
        // The game of life as a 2-dimensional array of boolean.
        // For more info on John Conway and the game of life, try
        // http://www.math.com/students/wonders/life/life.html

        const int iSize = 36;
        private bool[,] bCell = new bool[iSize + 1, iSize + 1];
        // We're going to use the cells from 1 to iSize in each dimension,
        // ignoring the 0 indexes.
        private bool bGrowing; // instance because 3 methods need to use it
        private int iGenCount; // to count the generations


        public GameOfLifeDemo()
        {
            InitializeComponent();

            // When the form loads, clear the array and the board
            ClearArray();
            DisplayArray();
            // . . . and set up the labels for the across and down axes
            string sTopline = "";
            string sBotLine = "";
            string sSideLine = "";
            // iSize is the number of cells across and down in the big text box
            for (int i = 1; i <= iSize; i++)
            {
                // The down axis just has straight numbers
                sSideLine = sSideLine + Convert.ToString(i) + "\r\n";
                // The across axis has the 10s on top line and units on bottom
                sTopline = sTopline + " ";
                if (i < 10) sTopline = sTopline + " ";
                else sTopline = sTopline + Convert.ToString(i / 10);
                sBotLine = sBotLine + " " + Convert.ToString(i % 10);
            }
            TbxTopScale.Text = sTopline + "\r\n" + sBotLine;
            TbxSideScale.Text = sSideLine;
        } // end of form constructor


        #region The array

        private bool Lifeless()
        {   // Indicator that no cells are left alive
            bool bAllDead = true;
            // If any cell is alive the board is not lifeless
            // Note: braces not needed around a single statement - but be careful!
            for (int i = 1; i <= iSize; i++)
                for (int j = 1; j <= iSize; j++)
                    if (bCell[i, j]) bAllDead = false;
            return bAllDead;
        } // end Lifeless

        private void ClearArray()
        {   // Clear the whole array - set the cell values to false
            for (int i = 1; i <= iSize; i++)
                for (int j = 1; j <= iSize; j++)
                    bCell[i, j] = false;
        } // end ClearArray

        private bool OnBoard(int i, int j)
        {   // Determine whether cell[i,j] is on the board
            // As with most assignments to booleans, no if statements are required
            return i >= 1 && i <= iSize && j >= 1 && j <= iSize;
        } // end OnBoard

        private int Neighbours(int i, int j)
        {   // Count the number of live neighbours of cell(i,j)
            // Note that ideally the space is infinite; but this space has boundaries,
            // so patterns don't behave 'properly' there.
            int iCount = 0;
            // Start with all 9 cells including the one in question . . .
            for (int x = i - 1; x <= i + 1; x++)
                for (int y = j - 1; y <= j + 1; y++)
                    // then ignore the cell itself and any offboard cells
                    if ((x != i || y != j) && OnBoard(x, y))
                        if (bCell[x, y])
                            // and count if the neighbour is live
                            iCount = iCount + 1;
            return iCount;
        } // end Neighbours

        private void NextGeneration()
        {   // Work out the next generation of cells
            // While doing so, check if the array is lifeless

            // A temporary array for the next generation
            bool[,] bNewCell = new bool[iSize + 1, iSize + 1];
            for (int i = 1; i <= iSize; i++)
                for (int j = 1; j <= iSize; j++)
                    // Note boolean assignment - no if required
                    // A next-gen cell lives if this gen has 3 living neighbours
                    // or this gen is alive and has 2 living neighbours
                    //if (onBoard(i,j))
                    bNewCell[i, j] = Neighbours(i, j) == 3 || bCell[i, j] && Neighbours(i, j) == 2;
            // Now copy the temporary array back to the real one
            bCell = bNewCell;
        } // end NextGeneration

        #endregion

        #region The interface

        private void DisplayArray()
        {   // Produce a multi-line string to display the array,
            // then display it in the LifeBoard textbox
            string sDisplay = "";
            for (int i = 1; i <= iSize; i++)
            {
                for (int j = 1; j <= iSize; j++)
                    if (bCell[i, j])
                        sDisplay = sDisplay + " @";
                    else
                        sDisplay = sDisplay + "  ";
                sDisplay = sDisplay + "\r\n";
            }
            TbxLifeBoard.Text = sDisplay;
        } // end DisplayArray

        private void BtnClear_Click(object sender, EventArgs e)
        {   // Clear the board and do whatever else is necessary for a fresh start
            ClearArray();
            DisplayArray();
            iGenCount = 0;
            LblGenCount.Text = "Generation 0";
        }

        private void BtnFlip_Click(object sender, EventArgs e)
        {   // Toggle on or off the cell at the specified location
            int i = 0, j = 0;
            try
            {
                i = Convert.ToInt32(TbxDown.Text);
                j = Convert.ToInt32(TbxAcross.Text);
                if (OnBoard(i, j))
                    bCell[i, j] = !bCell[i, j];
            }
            catch
            {
                MessageBox.Show("You must have numeric values in both coordinate boxes", "Numbers required");
            }
            DisplayArray();
            // Any flip is a new pattern, so restart the generation count . . .
            iGenCount = 0;
            LblGenCount.Text = "Generation 0";
            // . . . and turn off the two stopped labels in case they were on
            LblAllDead.Visible = false;
            LblStopped.Visible = false;
        }

        private void BtnSetDemo_Click(object sender, EventArgs e)
        {   // Set up one of the predefined interesting patterns
            // Take note of all the if statements with single-statement bodies and no braces
            int iDemoNum = 0;
            string sMessage = "";
            try
            {
                iDemoNum = Convert.ToInt32(TbxDemoNum.Text);
            }
            catch { }
            // The default demoNum of 0 deals with the exception below
            if (iDemoNum == 1) Demo1(out sMessage);        // a glider
            else if (iDemoNum == 2) Demo2(out sMessage);   // a glider and a block
            else if (iDemoNum == 3) Demo3(out sMessage);   // 2 gliders, 2 blocks
            else if (iDemoNum == 4) Demo4(out sMessage);   // 2 gliders, 2 blocks
            else if (iDemoNum == 5) Demo5(out sMessage);   // queen bee shuttle with blocks
            else if (iDemoNum == 6) Demo6(out sMessage);   // the r pentomino
            else if (iDemoNum == 7) Demo7(out sMessage);   // a glider gun - it generates gliders
            else MessageBox.Show("Enter a demo number", "Number?");
            DisplayArray();
            iGenCount = 0;
            LblGenCount.Text = "Generation 0";
            if (iDemoNum != 0) MessageBox.Show(sMessage, "Game of Life demonstration " + Convert.ToString(iDemoNum));
        } // end of BtnSetDemo_Click

        private void AdvanceOne()
        {   // Advance a single generation and display the new board and count
            // A separate method because it's called by two different event handlers
            NextGeneration();
            DisplayArray();
            iGenCount = iGenCount + 1;
            LblGenCount.Text = string.Format("Generation {0:d}", iGenCount);
            if (Lifeless())
                LblAllDead.Visible = true;  // The quote is from the TV show Red Dwarf
        } // end AdvanceOne

        private void BtnSingleStep_Click(object sender, EventArgs e)
        {   // Step forward one generation
            AdvanceOne();
        }

        private void BtnRun_Click(object sender, EventArgs e)
        {   // Grow a new generation at each click of the timer
            // The timer will stop when all dead or when the Stop button is clicked
            bGrowing = true;
            LblAllDead.Visible = false;  // In case it was made visible in previous run
            LblStopped.Visible = false;
            AdvanceOne();
            // Turn on the timer whose ticks will advance the generations
            TmrClock.Enabled = true;
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {   // Stop button clicked; tell it to stop growing
            bGrowing = false;
        }

        private void TmrClock_Tick(object sender, EventArgs e)
        {   // At every tick of the clock, show the next generation
            AdvanceOne();
            // If life is extinct, prepare it to stop
            if (Lifeless())
            {
                bGrowing = false;
                LblAllDead.Visible = true; // The quote is from the TV show Red Dwarf
            }
            if (!bGrowing)
            // If it's to stop, stop the clock and show the Stopped label
            {
                TmrClock.Enabled = false;
                LblStopped.Visible = true;
            }
        }

        private void TkbarSpeed_Scroll(object sender, EventArgs e)
        {   // Reset the interval betwen ticks of the timer
            // The trackbar values range from 0 to 10
            // Exercise for the reader: what timer intervals do these values produce?
            TmrClock.Interval = Convert.ToInt32(Math.Pow(2, 12 - TkbarSpeed.Value));
        }

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {   // Close this form and return to the main menu form
            this.Dispose();
        }

        #endregion

        #region Seven demonstration patterns

        private void Demo1(out string sMessage)
        {   // A glider
            sMessage = "A glider";
            ClearArray();
            bCell[7, 23] = true;
            bCell[8, 24] = true;
            bCell[9, 24] = true;
            bCell[9, 23] = true;
            bCell[9, 22] = true;
        }

        private void Demo2(out string sMessage)
        {   // Somewhat more interesting, a glider crashes into a block
            // Dies after 50 generations
            sMessage = "A glider crashes into a block; dies after 50 generations";
            ClearArray();
            // A glider
            bCell[3, 9] = true;
            bCell[4, 10] = true;
            bCell[5, 10] = true;
            bCell[5, 9] = true;
            bCell[5, 8] = true;
            // A block
            bCell[11, 18] = true;
            bCell[11, 19] = true;
            bCell[12, 18] = true;
            bCell[12, 19] = true;
        }

        private void Demo3(out string sMessage)
        {   // A vaguely interesting starting arrangement
            // Two gliders crash into 2 blocks;
            // stability after 146 generations
            sMessage = "Two gliders and two blocks; stability after 146 generations";
            ClearArray();
            // A glider
            bCell[1, 7] = true;
            bCell[2, 8] = true;
            bCell[3, 8] = true;
            bCell[3, 7] = true;
            bCell[3, 6] = true;
            // A glider
            bCell[6, 2] = true;
            bCell[7, 3] = true;
            bCell[8, 3] = true;
            bCell[8, 2] = true;
            bCell[8, 1] = true;
            // A block
            bCell[6, 13] = true;
            bCell[6, 14] = true;
            bCell[7, 13] = true;
            bCell[7, 14] = true;
            // A block
            bCell[11, 8] = true;
            bCell[11, 9] = true;
            bCell[12, 8] = true;
            bCell[12, 9] = true;
        }

        private void Demo4(out string sMessage)
        {   // Slightly different from Demo3, very different outcome
            // Same 2 gliders; blocks a little further over;
            // stability after some 200 generations
            sMessage = "Two gliders and two blocks; stability after 202 generations.";
            ClearArray();
            // A glider
            bCell[1, 7] = true;
            bCell[2, 8] = true;
            bCell[3, 8] = true;
            bCell[3, 7] = true;
            bCell[3, 6] = true;
            // A glider
            bCell[6, 2] = true;
            bCell[7, 3] = true;
            bCell[8, 3] = true;
            bCell[8, 2] = true;
            bCell[8, 1] = true;
            // A block
            bCell[11, 18] = true;
            bCell[11, 19] = true;
            bCell[12, 18] = true;
            bCell[12, 19] = true;
            // A block
            bCell[16, 13] = true;
            bCell[16, 14] = true;
            bCell[17, 13] = true;
            bCell[17, 14] = true;
        }

        private void Demo5(out string sMessage)
        {   // A perpetual pattern
            sMessage = "A queen bee shuttle and two blocks - perpetual";
            ClearArray();
            // A queen bee shuttle
            bCell[15, 15] = true;
            bCell[15, 16] = true;
            bCell[16, 17] = true;
            bCell[17, 18] = true;
            bCell[18, 18] = true;
            bCell[19, 18] = true;
            bCell[20, 17] = true;
            bCell[21, 16] = true;
            bCell[21, 15] = true;
            // And two blocks
            bCell[18, 7] = true;
            bCell[19, 7] = true;
            bCell[18, 8] = true;
            bCell[19, 8] = true;
            bCell[18, 27] = true;
            bCell[19, 27] = true;
            bCell[18, 28] = true;
            bCell[19, 28] = true;
        }

        private void Demo6(out string sMessage)
        {   // The "r" pentomino
            sMessage = "The r pentomino; stability after 291 generations";
            ClearArray();
            bCell[18, 15] = true;
            bCell[18, 16] = true;
            bCell[19, 16] = true;
            bCell[17, 16] = true;
            bCell[17, 17] = true;
        }

        private void Demo7(out string sMessage)
        {   // The Gosper glider gun
            sMessage = "The Gosper glider gun - creates gliders";
            ClearArray();
            bCell[10, 1] = true;
            bCell[10, 2] = true;
            bCell[11, 1] = true;
            bCell[11, 2] = true;
            bCell[10, 11] = true;
            bCell[11, 11] = true;
            bCell[12, 11] = true;
            bCell[9, 12] = true;
            bCell[13, 12] = true;
            bCell[8, 13] = true;
            bCell[14, 13] = true;
            bCell[8, 14] = true;
            bCell[14, 14] = true;
            bCell[11, 15] = true;
            bCell[9, 16] = true;
            bCell[13, 16] = true;
            bCell[10, 17] = true;
            bCell[11, 17] = true;
            bCell[12, 17] = true;
            bCell[11, 18] = true;
            bCell[8, 21] = true;
            bCell[9, 21] = true;
            bCell[10, 21] = true;
            bCell[8, 22] = true;
            bCell[9, 22] = true;
            bCell[10, 22] = true;
            bCell[7, 23] = true;
            bCell[11, 23] = true;
            bCell[6, 25] = true;
            bCell[7, 25] = true;
            bCell[11, 25] = true;
            bCell[12, 25] = true;
            bCell[8, 35] = true;
            bCell[9, 35] = true;
            bCell[8, 36] = true;
            bCell[9, 36] = true;
        }

        #endregion

    } // end class
} // end namespace

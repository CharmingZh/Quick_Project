﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec7Demo
{
    public partial class frmLec7Demo : Form
    {   // Simon, May 2015
        // Combine four different demos for this Inft2012 lecture into a single program,
        // with each demo on its own form being launched from the main menu form.

        public frmLec7Demo()
        {
            InitializeComponent();
        }

        private void btnArrayDemo_Click(object sender, EventArgs e)
        {   // Create a new ArrayDemo form and show it modally
            ArrayDemo frmArrayDemo = new ArrayDemo();
            frmArrayDemo.ShowDialog();
        }

        private void btnListboxDemo_Click(object sender, EventArgs e)
        {   // Create a new ListboxDemo form and show it modally
            ListboxDemo frmListboxDemo = new ListboxDemo();
            frmListboxDemo.ShowDialog();
        }

        private void btnRainfall_Click(object sender, EventArgs e)
        {   // Create a new RainfallDemo form and show it modally
            RainfallDemo frmRainfallDemo = new RainfallDemo();
            frmRainfallDemo.ShowDialog();
        }

        private void btnGameOfLife_Click(object sender, EventArgs e)
        {   // Create a new GameOfLifeDemo form and show it modally
            GameOfLifeDemo frmGameOfLifeDemo = new GameOfLifeDemo();
            frmGameOfLifeDemo.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {   // Stop the program
            Application.Exit();
        }

    } // end class
} // end namespace

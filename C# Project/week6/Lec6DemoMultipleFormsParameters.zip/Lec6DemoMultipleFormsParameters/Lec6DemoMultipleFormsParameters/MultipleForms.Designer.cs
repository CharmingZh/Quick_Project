﻿namespace Lec6DemoMultipleFormsParameters
{
    partial class FrmMultipleForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnParameterDemo = new System.Windows.Forms.Button();
            this.BtnInputBoxDemo = new System.Windows.Forms.Button();
            this.BtnAbout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnExit.Location = new System.Drawing.Point(66, 196);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(153, 23);
            this.BtnExit.TabIndex = 7;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnParameterDemo
            // 
            this.BtnParameterDemo.Location = new System.Drawing.Point(66, 145);
            this.BtnParameterDemo.Name = "BtnParameterDemo";
            this.BtnParameterDemo.Size = new System.Drawing.Size(153, 23);
            this.BtnParameterDemo.TabIndex = 6;
            this.BtnParameterDemo.Text = "Parameter demonstration";
            this.BtnParameterDemo.UseVisualStyleBackColor = true;
            this.BtnParameterDemo.Click += new System.EventHandler(this.BtnParameterDemo_Click);
            // 
            // BtnInputBoxDemo
            // 
            this.BtnInputBoxDemo.Location = new System.Drawing.Point(66, 94);
            this.BtnInputBoxDemo.Name = "BtnInputBoxDemo";
            this.BtnInputBoxDemo.Size = new System.Drawing.Size(153, 23);
            this.BtnInputBoxDemo.TabIndex = 5;
            this.BtnInputBoxDemo.Text = "Input box demonstration";
            this.BtnInputBoxDemo.UseVisualStyleBackColor = true;
            this.BtnInputBoxDemo.Click += new System.EventHandler(this.BtnInputBoxDemo_Click);
            // 
            // BtnAbout
            // 
            this.BtnAbout.Location = new System.Drawing.Point(66, 43);
            this.BtnAbout.Name = "BtnAbout";
            this.BtnAbout.Size = new System.Drawing.Size(153, 23);
            this.BtnAbout.TabIndex = 4;
            this.BtnAbout.Text = "About multiple forms";
            this.BtnAbout.UseVisualStyleBackColor = true;
            this.BtnAbout.Click += new System.EventHandler(this.BtnAbout_Click);
            // 
            // FrmMultipleForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnParameterDemo);
            this.Controls.Add(this.BtnInputBoxDemo);
            this.Controls.Add(this.BtnAbout);
            this.Name = "FrmMultipleForms";
            this.Text = "Multiple forms";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnParameterDemo;
        private System.Windows.Forms.Button BtnInputBoxDemo;
        private System.Windows.Forms.Button BtnAbout;
    }
}


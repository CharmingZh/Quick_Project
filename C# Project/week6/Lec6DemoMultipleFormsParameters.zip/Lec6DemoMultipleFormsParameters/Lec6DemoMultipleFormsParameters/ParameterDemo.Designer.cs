﻿namespace Lec6DemoMultipleFormsParameters
{
    partial class ParameterDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblHeader = new System.Windows.Forms.Label();
            this.BtnClear = new System.Windows.Forms.Button();
            this.TbxA2Before = new System.Windows.Forms.TextBox();
            this.TbxP1End = new System.Windows.Forms.TextBox();
            this.TbxP2End = new System.Windows.Forms.TextBox();
            this.TbxA1After = new System.Windows.Forms.TextBox();
            this.TbxA2After = new System.Windows.Forms.TextBox();
            this.TbxP2Start = new System.Windows.Forms.TextBox();
            this.TbxP1Start = new System.Windows.Forms.TextBox();
            this.TbxA1Before = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TbxDescribe = new System.Windows.Forms.TextBox();
            this.BtnValues = new System.Windows.Forms.Button();
            this.BtnOuts = new System.Windows.Forms.Button();
            this.BtnRefs = new System.Windows.Forms.Button();
            this.BtnFunction = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblHeader
            // 
            this.LblHeader.AutoSize = true;
            this.LblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblHeader.Location = new System.Drawing.Point(23, 19);
            this.LblHeader.Name = "LblHeader";
            this.LblHeader.Size = new System.Drawing.Size(0, 17);
            this.LblHeader.TabIndex = 44;
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(434, 114);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(125, 23);
            this.BtnClear.TabIndex = 43;
            this.BtnClear.Text = "Clear";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // TbxA2Before
            // 
            this.TbxA2Before.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxA2Before.Location = new System.Drawing.Point(314, 121);
            this.TbxA2Before.Name = "TbxA2Before";
            this.TbxA2Before.Size = new System.Drawing.Size(45, 23);
            this.TbxA2Before.TabIndex = 42;
            this.TbxA2Before.Text = "18.75";
            this.TbxA2Before.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxP1End
            // 
            this.TbxP1End.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxP1End.Location = new System.Drawing.Point(238, 223);
            this.TbxP1End.Name = "TbxP1End";
            this.TbxP1End.Size = new System.Drawing.Size(45, 23);
            this.TbxP1End.TabIndex = 41;
            this.TbxP1End.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxP2End
            // 
            this.TbxP2End.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxP2End.Location = new System.Drawing.Point(314, 223);
            this.TbxP2End.Name = "TbxP2End";
            this.TbxP2End.Size = new System.Drawing.Size(45, 23);
            this.TbxP2End.TabIndex = 40;
            this.TbxP2End.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxA1After
            // 
            this.TbxA1After.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxA1After.Location = new System.Drawing.Point(238, 277);
            this.TbxA1After.Name = "TbxA1After";
            this.TbxA1After.Size = new System.Drawing.Size(45, 23);
            this.TbxA1After.TabIndex = 39;
            this.TbxA1After.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxA2After
            // 
            this.TbxA2After.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxA2After.Location = new System.Drawing.Point(314, 277);
            this.TbxA2After.Name = "TbxA2After";
            this.TbxA2After.Size = new System.Drawing.Size(45, 23);
            this.TbxA2After.TabIndex = 38;
            this.TbxA2After.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxP2Start
            // 
            this.TbxP2Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxP2Start.Location = new System.Drawing.Point(314, 173);
            this.TbxP2Start.Name = "TbxP2Start";
            this.TbxP2Start.Size = new System.Drawing.Size(45, 23);
            this.TbxP2Start.TabIndex = 37;
            this.TbxP2Start.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxP1Start
            // 
            this.TbxP1Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxP1Start.Location = new System.Drawing.Point(238, 173);
            this.TbxP1Start.Name = "TbxP1Start";
            this.TbxP1Start.Size = new System.Drawing.Size(45, 23);
            this.TbxP1Start.TabIndex = 36;
            this.TbxP1Start.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbxA1Before
            // 
            this.TbxA1Before.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxA1Before.Location = new System.Drawing.Point(238, 121);
            this.TbxA1Before.Name = "TbxA1Before";
            this.TbxA1Before.Size = new System.Drawing.Size(45, 23);
            this.TbxA1Before.TabIndex = 35;
            this.TbxA1Before.Text = "23.25";
            this.TbxA1Before.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 278);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "Arguments after the call";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(190, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Parameters at end of the call";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Parameters at start of the call";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "Arguments before the call";
            // 
            // TbxDescribe
            // 
            this.TbxDescribe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxDescribe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxDescribe.Location = new System.Drawing.Point(24, 41);
            this.TbxDescribe.Multiline = true;
            this.TbxDescribe.Name = "TbxDescribe";
            this.TbxDescribe.ReadOnly = true;
            this.TbxDescribe.Size = new System.Drawing.Size(551, 68);
            this.TbxDescribe.TabIndex = 30;
            this.TbxDescribe.Text = "Here you\'ll see a brief description of what\'s happening.";
            // 
            // BtnValues
            // 
            this.BtnValues.Location = new System.Drawing.Point(434, 150);
            this.BtnValues.Name = "BtnValues";
            this.BtnValues.Size = new System.Drawing.Size(125, 23);
            this.BtnValues.TabIndex = 29;
            this.BtnValues.Text = "Value parameters";
            this.BtnValues.UseVisualStyleBackColor = true;
            this.BtnValues.Click += new System.EventHandler(this.BtnValues_Click);
            // 
            // BtnOuts
            // 
            this.BtnOuts.Location = new System.Drawing.Point(434, 186);
            this.BtnOuts.Name = "BtnOuts";
            this.BtnOuts.Size = new System.Drawing.Size(125, 23);
            this.BtnOuts.TabIndex = 28;
            this.BtnOuts.Text = "Out parameters";
            this.BtnOuts.UseVisualStyleBackColor = true;
            this.BtnOuts.Click += new System.EventHandler(this.BtnOuts_Click);
            // 
            // BtnRefs
            // 
            this.BtnRefs.Location = new System.Drawing.Point(434, 222);
            this.BtnRefs.Name = "BtnRefs";
            this.BtnRefs.Size = new System.Drawing.Size(125, 23);
            this.BtnRefs.TabIndex = 27;
            this.BtnRefs.Text = "Ref parameters";
            this.BtnRefs.UseVisualStyleBackColor = true;
            this.BtnRefs.Click += new System.EventHandler(this.BtnRefs_Click);
            // 
            // BtnFunction
            // 
            this.BtnFunction.Location = new System.Drawing.Point(434, 258);
            this.BtnFunction.Name = "BtnFunction";
            this.BtnFunction.Size = new System.Drawing.Size(125, 23);
            this.BtnFunction.TabIndex = 26;
            this.BtnFunction.Text = "Function method";
            this.BtnFunction.UseVisualStyleBackColor = true;
            this.BtnFunction.Click += new System.EventHandler(this.BtnFunction_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(434, 294);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(125, 23);
            this.BtnClose.TabIndex = 25;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // ParameterDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 337);
            this.Controls.Add(this.LblHeader);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.TbxA2Before);
            this.Controls.Add(this.TbxP1End);
            this.Controls.Add(this.TbxP2End);
            this.Controls.Add(this.TbxA1After);
            this.Controls.Add(this.TbxA2After);
            this.Controls.Add(this.TbxP2Start);
            this.Controls.Add(this.TbxP1Start);
            this.Controls.Add(this.TbxA1Before);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TbxDescribe);
            this.Controls.Add(this.BtnValues);
            this.Controls.Add(this.BtnOuts);
            this.Controls.Add(this.BtnRefs);
            this.Controls.Add(this.BtnFunction);
            this.Controls.Add(this.BtnClose);
            this.Name = "ParameterDemo";
            this.Text = "Demonstrating parameters";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblHeader;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.TextBox TbxA2Before;
        private System.Windows.Forms.TextBox TbxP1End;
        private System.Windows.Forms.TextBox TbxP2End;
        private System.Windows.Forms.TextBox TbxA1After;
        private System.Windows.Forms.TextBox TbxA2After;
        private System.Windows.Forms.TextBox TbxP2Start;
        private System.Windows.Forms.TextBox TbxP1Start;
        private System.Windows.Forms.TextBox TbxA1Before;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TbxDescribe;
        private System.Windows.Forms.Button BtnValues;
        private System.Windows.Forms.Button BtnOuts;
        private System.Windows.Forms.Button BtnRefs;
        private System.Windows.Forms.Button BtnFunction;
        private System.Windows.Forms.Button BtnClose;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec6DemoMultipleFormsParameters
{
    public partial class ParameterDemo : Form
    {
        // Simon, May 2015
        // Last updated August 2021
        // Demonstrating parameter types in a project demonstrating multiple forms

        public ParameterDemo()
        {
            InitializeComponent();
        }

        #region Housekeeping methods

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close the form by disposing of it
            this.Dispose();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {   // Set the textboxes back to the way they were
            LblHeader.Text = "";
            TbxDescribe.Text = "Here you'll see a brief description of what's happening.";
            TbxA1Before.Text = "23.25";
            TbxA2Before.Text = "18.75";
            TbxP1Start.Text = "";
            TbxP2Start.Text = "";
            TbxP1End.Text = "";
            TbxP2End.Text = "";
            TbxA1After.Text = "";
            TbxA2After.Text = "";
        }

        #endregion

        #region Overloaded Swap methods

        private void Swap(ref double dOne, ref double dTwo)
        {   // Swap two doubles; this method is overloaded with the one below
            // Ref parameters are used because we want the method to swap the arguments
            double dSwapper = dOne;
            dOne = dTwo;
            dTwo = dSwapper;
        } // end of Swap with double parameters

        private void Swap(ref int iOne, ref int iTwo)
        {   // Swap two ints; this method is overloaded with the one above
            // Ref parameters are used because we want the method to swap the arguments
            int iSwapper = iOne;
            iOne = iTwo;
            iTwo = iSwapper;
        } // end of Swap with int parameters

        #endregion

        #region Transferring values in and out of textboxes

        private void GetArguments(out double dArg1, out double dArg2)
        {   // Get two doubles from the arguments pre-call textboxes
            // This method uses out parameters, to pass the values back after getting them
            try
            {
                dArg1 = Convert.ToDouble(TbxA1Before.Text);
                dArg2 = Convert.ToDouble(TbxA2Before.Text);
            }
            catch
            {
                MessageBox.Show("There should be numbers in the top two boxes.\r\nI'll assume values of 23.25 & 18.75.", "Arguments missing");
                dArg1 = 23.25;
                dArg2 = 18.75;
            }
        } // end of GetArguments

        private void DisplayArgumentsAfter(double dArg1, double dArg2)
        {   // Display the two values in the arguments post-call textboxes
            // Doesn't need to change or return anything, so uses value parameters
            TbxA1After.Text = Convert.ToString(dArg1);
            TbxA2After.Text = Convert.ToString(dArg2);
        } // end of DisplayArgumentsAfter

        private void DisplayParametersStart(double dArg1, double dArg2)
        {   // Display the two values in the parameters pre-call textboxes
            // Doesn't need to change or return anything, so uses value parameters
            TbxP1Start.Text = Convert.ToString(dArg1);
            TbxP2Start.Text = Convert.ToString(dArg2);
        } // end of DisplayParametersStart

        private void DisplayParametersEnd(double dArg1, double dArg2)
        {   // Display the two values in the parameters post-call textboxes
            // Doesn't need to change or return anything, so uses value parameters
            TbxP1End.Text = Convert.ToString(dArg1);
            TbxP2End.Text = Convert.ToString(dArg2);
        } // end of DisplayParametersEnd

        #endregion

        #region Value parameters

        private void BtnValues_Click(object sender, EventArgs e)
        {   // Illustrate value parameters by calling a method with two value parameters
            double dArg1, dArg2; // variables local to this method
            GetArguments(out dArg1, out dArg2); // Get the values from the top textboxes

            LblHeader.Text = "Value parameters";
            TbxDescribe.Text =
                "At the start of the method, the parameters take on the values of the arguments.\r\n" +
                "The method then swaps its parameters.\r\n" + "That's all.";

            // Call the method that uses value parameters
            ValueSwap(dArg1, dArg2);

            // Display the arguments after the method call
            DisplayArgumentsAfter(dArg1, dArg2);

        } // end of BtnValues_Click

        private void ValueSwap(double dParam1, double dParam2)
        {   // Take in two value parameters and Swap them
            // Of course there's a not a lot of point in doing this if we then make no use
            // of the swapped values. In this case we simply display them.

            // Display the parameters before any action
            DisplayParametersStart(dParam1, dParam2);

            // Swap the parameters
            Swap(ref dParam1, ref dParam2);

            // Display the parameters after the action
            DisplayParametersEnd(dParam1, dParam2);

        } // end of ValueSwap

        #endregion

        #region Out parameters

        private void BtnOuts_Click(object sender, EventArgs e)
        {   // Illustrate out parameters by calling a method with two out parameters
            double dArg1, dArg2;
            GetArguments(out dArg1, out dArg2); // Get the values from the top textboxes

            LblHeader.Text = "Out parameters";
            TbxDescribe.Text =
                "At the start of the method, the parameters have no values at all.\r\n" +
                "The method gives the parameters values, then swaps them.\r\n" +
                "When the method ends, the values of the parameters are transferred to the arguments.";

            // Call the method that uses out parameters
            OutSwap(out dArg1, out dArg2);

            // Display the arguments after the method call
            DisplayArgumentsAfter(dArg1, dArg2);
 
        }  // end of BtnOuts_Click

        private void OutSwap(out double dParam1, out double dParam2)
        {   // Nothing is passed in with out parameters.
            // Let's give the parameters some initial values.
            dParam1 = 13; dParam2 = 8;

            // Display the parameters before any action
            DisplayParametersStart(dParam1, dParam2);

            // Swap the parameters
            Swap(ref dParam1, ref dParam2);

            // Display the parameters after the action
            DisplayParametersEnd(dParam1, dParam2);

        } // end of OutSwap

       #endregion

        #region Reference parameters

        private void BtnRefs_Click(object sender, EventArgs e)
        {   // Illustrate ref parameters by calling a method with two ref parameters
            double dArg1, dArg2;
            GetArguments(out dArg1, out dArg2); // Get the values from the top textboxes

            LblHeader.Text = "Ref parameters";
            TbxDescribe.Text =
                "At the start of the method, the parameters become alternative names for the arguments.\r\n" +
                "The method swaps the parameters, thus swapping the arguments.\r\n" +
                "Nothing is transferred when the method ends; any change to the parameters is reflected immediately in the arguments.";

            // Call the method that uses ref parameters
            RefSwap(ref dArg1, ref dArg2);

            // Display the arguments after the method call
            DisplayArgumentsAfter(dArg1, dArg2);

        } // end of BtnRefs_Click

        private void RefSwap(ref double dParam1, ref double dParam2)
        {   // Take in two parameters and Swap them
            // Using ref parameters, the parameters and the arguments are the same things

            // Display the parameters before any action
            DisplayParametersStart(dParam1, dParam2);

            // Swap the parameters
            Swap(ref dParam1, ref dParam2);

            // Display the parameters after the action
            DisplayParametersEnd(dParam1, dParam2);

        } // end of RefSwap

        #endregion

        #region Function returning value

        private void BtnFunction_Click(object sender, EventArgs e)
        {   // Illustrate the use of a function to return a single value
            double dArg1, dArg2;
            GetArguments(out dArg1, out dArg2); // Get the values from the top textboxes

            LblHeader.Text = "Function method";
            TbxDescribe.Text =
                "The function method calculates a value (in this case using value parameters) and returns\r\n" +
                "it - not by way of parameters, but where the function was called in an expression.\r\n" +
                "In this case the returned value is used for display in a message box.";

            // Call the function method - in an expression, where a double value would be expected
            MessageBox.Show(String.Format("The sum of the parameters is {0:f0}", Sum(dArg1, dArg2)), "Function method");

            // Display the arguments after the method call
            DisplayArgumentsAfter(dArg1, dArg2);

        } // end of BtnFunction_Click

        private double Sum(double dParam1, double dParam2)
        {   // Take in two parameters and return their sum
            // The sum is all we need to return, so we use value parameters

            // Display the parameters before any action
            DisplayParametersStart(dParam1, dParam2);

            // Display the parameters again
            // We haven't changed them, but we won't be able to display them (or
            // do anything else) after the return statement
            DisplayParametersEnd(dParam1, dParam2);

            // Retun the sum of the parameters. At this point the function ends, and
            // the returned value 'takes the place of' the function call
            return dParam1 + dParam2;

        } // end of Sum function

        #endregion

    } // end of class
} // end of namespace

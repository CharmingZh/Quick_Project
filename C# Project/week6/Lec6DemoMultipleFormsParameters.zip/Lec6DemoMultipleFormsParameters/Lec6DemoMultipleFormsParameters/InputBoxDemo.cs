﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec6DemoMultipleFormsParameters
{
    // Simon, May 2015
    // Last updated August 2021
    // Demonstrating InputBox in the project demonstrating multiple forms

    public partial class InputBoxDemo : Form
    {
        public InputBoxDemo()
        {
            InitializeComponent();
        }

        private void BtnCollect_Click(object sender, EventArgs e)
        {   // When the button is clicked, to collect the data . . .

            // Clear the value labels
            LblName.Text = "";
            LblAge.Text = "";
            LblWeight.Text = "";
            LblHeight.Text = "";

            // Create a single InputBox and instantiate with a name message
            InputBox FrmCollector = new InputBox("What's your name?", "Personal data");
            // Display the form (it remains on display until the user presses a button)
            FrmCollector.ShowDialog();
            // Even when the InputBox is closed it still exists, so we can access its sInputValue property
            LblName.Text = FrmCollector.sInputValue;

            // Now reinstantiate the same InputBox with a different prompt
            FrmCollector = new InputBox("How old are you?", "Personal data");
            FrmCollector.ShowDialog();
            LblAge.Text = FrmCollector.sInputValue;
            // There was no need to convert to a number, because we want a string to display in the label

            // And a third time
            FrmCollector = new InputBox("What's your weight in kg?", "Personal data");
            // Just this time we'll call the InputBox as a function, illustrating how to get and use the answer
            if (FrmCollector.ShowDialog() == DialogResult.Cancel) // If user pressed Esc or the Cancel button
            {
                MessageBox.Show("You'd rather not say?\r\nOh, that's OK.", "Personal data");
                LblWeight.Text = "undisclosed";
            }
            else
            {
                LblWeight.Text = FrmCollector.sInputValue + "kg";
            }

            // And a fourth time
            FrmCollector = new InputBox("And your height in cm?", "Personal data");
            FrmCollector.ShowDialog();
            LblHeight.Text = FrmCollector.sInputValue + "cm";

        }  // end of BtnCollect_Click

        private void BtnClose_Click(object sender, EventArgs e)
        {   // Close the form by disposing of it (even though we've made no use of the data)
            this.Dispose();
        }  // end of BtnClose_Click

    }  // end of class
}  // end of namespace

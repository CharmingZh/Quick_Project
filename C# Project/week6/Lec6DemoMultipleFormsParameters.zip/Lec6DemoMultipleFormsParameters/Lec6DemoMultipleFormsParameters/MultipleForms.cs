﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec6DemoMultipleFormsParameters
{
    // Simon, May 2015
    // Last updated August 2021
    // Main form of project demonstrating multiple forms and different types of parameter

    public partial class FrmMultipleForms : Form
    {
        public FrmMultipleForms()
        {   // Constructor provided by Visual Studio
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Stop the program by exiting the application
            Application.Exit();
        }  // end of BtnExit_Click

        private void BtnAbout_Click(object sender, EventArgs e)
        {   // Declare and instantiate an instance of the AboutBox class
            AboutBox frmAbout = new AboutBox();
            // And display the instance
            frmAbout.ShowDialog();
        }  // end of BtnAbout_Click

        private void BtnInputBoxDemo_Click(object sender, EventArgs e)
        {   // Declare and instantiate an instance of the InputBoxDemo class
            InputBoxDemo frmPersonalData = new InputBoxDemo();
            frmPersonalData.Show();
            // We didn't use ShowDialog, so we can go back & forth between these forms. Is that good?
        }  // end of BtnInputBoxDemo_Click

        private void BtnParameterDemo_Click(object sender, EventArgs e)
        {   // Declare and instantiate an instance of the InputBoxDemo class
            ParameterDemo frmParamDemo = new ParameterDemo();
            frmParamDemo.ShowDialog();
            // This time we used ShowDialog, so we're stuck on this form until we finish with it
        }  // end of BtnParameterDemo_Click

    }  // end of class
}  // end of namespace

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec6DemoMultipleFormsParameters
{
    // Simon, May 2015
    // Last updated August 2021
    // InputBox class for the project demonstrating multiple forms
    // Note that in the form's properties, three values have been changed:
    //   AcceptButton, CancelButton, and StartPosition

    public partial class InputBox : Form
    {
        public InputBox()
        {   // This is what happens if we instantiate an InputBox using new InputBox() with no arguments
            InitializeComponent();
        } // end of default constructor

        public InputBox(string sPrompt, string sTitle)
        {   // This is what happens if we instantiate an InputBox using new InputBox(someString, someOtherString)
            // We wrote this constructor, but we still have to include InitializeComponent();
            InitializeComponent();
            Text = sTitle;  // Text means the Text property of this form; it could have been written this.Text
            LblPrompt.Text = sPrompt;
        } // end of additional constructor

        public string sInputValue
        {   // The InputValue property sets or gets the text in the text box
            // Properties will be covered in detail in the lecture on defining classes
            // Briefly, get is executed when an outside method uses sInputValue in an expression,
            get { return TbxInput.Text; }
            // and set is executed when an outside method assigns to sInputValue
            set { TbxInput.Text = value; }
        } // end of sInputValue property

    } // end of class
} // end of namespace

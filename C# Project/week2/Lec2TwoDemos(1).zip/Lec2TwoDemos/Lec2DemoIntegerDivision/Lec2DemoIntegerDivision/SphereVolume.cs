﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec2DemoIntegerDivision
{
    // Simon, May 2015
    // Last updated August 2021
    // Illustrating a problem with integer division -
    //   and a problem with conversions from number to string

    public partial class FrmSphereVolume : Form
    {
        public FrmSphereVolume()
        {
            InitializeComponent();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            // The volume of a sphere is 4/3 pi r-cubed
            double dRadius = Convert.ToDouble(TbxRadius.Text);
            double dVolume1 = 4 / 3 * Math.PI * dRadius * dRadius * dRadius;
            double dVolume2 = Math.PI * 4 / 3 * dRadius * dRadius * dRadius;
            LblVolume.Text = "The volume of the sphere is " + Convert.ToString(dVolume1);
            MessageBox.Show("The volume of the sphere is " + Convert.ToString(dVolume2), "Compare the volumes");
        }
    }
}

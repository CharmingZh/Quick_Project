﻿namespace Lec2DemoCalculator
{
    partial class FrmCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblResult = new System.Windows.Forms.Label();
            this.LblSecond = new System.Windows.Forms.Label();
            this.LblFirst = new System.Windows.Forms.Label();
            this.LblEquals = new System.Windows.Forms.Label();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.BtnMultiply = new System.Windows.Forms.Button();
            this.BtnSubtract = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.TbxResult = new System.Windows.Forms.TextBox();
            this.TbxSecond = new System.Windows.Forms.TextBox();
            this.TbxFirst = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblResult
            // 
            this.LblResult.Location = new System.Drawing.Point(358, 60);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(100, 23);
            this.LblResult.TabIndex = 43;
            this.LblResult.Text = "Result";
            this.LblResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblSecond
            // 
            this.LblSecond.Location = new System.Drawing.Point(198, 60);
            this.LblSecond.Name = "LblSecond";
            this.LblSecond.Size = new System.Drawing.Size(100, 23);
            this.LblSecond.TabIndex = 42;
            this.LblSecond.Text = "Second number";
            this.LblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblFirst
            // 
            this.LblFirst.Location = new System.Drawing.Point(22, 60);
            this.LblFirst.Name = "LblFirst";
            this.LblFirst.Size = new System.Drawing.Size(100, 23);
            this.LblFirst.TabIndex = 41;
            this.LblFirst.Text = "First number";
            this.LblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblEquals
            // 
            this.LblEquals.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEquals.Location = new System.Drawing.Point(318, 84);
            this.LblEquals.Name = "LblEquals";
            this.LblEquals.Size = new System.Drawing.Size(24, 23);
            this.LblEquals.TabIndex = 40;
            this.LblEquals.Text = "=";
            // 
            // BtnDivide
            // 
            this.BtnDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivide.Location = new System.Drawing.Point(142, 132);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(32, 32);
            this.BtnDivide.TabIndex = 39;
            this.BtnDivide.Text = "/";
            this.BtnDivide.Click += new System.EventHandler(this.BtnDivide_Click);
            // 
            // BtnMultiply
            // 
            this.BtnMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiply.Location = new System.Drawing.Point(142, 92);
            this.BtnMultiply.Name = "BtnMultiply";
            this.BtnMultiply.Size = new System.Drawing.Size(32, 32);
            this.BtnMultiply.TabIndex = 38;
            this.BtnMultiply.Text = "*";
            this.BtnMultiply.Click += new System.EventHandler(this.BtnMultiply_Click);
            // 
            // BtnSubtract
            // 
            this.BtnSubtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSubtract.Location = new System.Drawing.Point(142, 52);
            this.BtnSubtract.Name = "BtnSubtract";
            this.BtnSubtract.Size = new System.Drawing.Size(32, 32);
            this.BtnSubtract.TabIndex = 37;
            this.BtnSubtract.Text = "-";
            this.BtnSubtract.Click += new System.EventHandler(this.BtnSubtract_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.Location = new System.Drawing.Point(142, 12);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(32, 32);
            this.BtnAdd.TabIndex = 36;
            this.BtnAdd.Text = "+";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // TbxResult
            // 
            this.TbxResult.Location = new System.Drawing.Point(358, 84);
            this.TbxResult.Name = "TbxResult";
            this.TbxResult.Size = new System.Drawing.Size(100, 20);
            this.TbxResult.TabIndex = 35;
            // 
            // TbxSecond
            // 
            this.TbxSecond.Location = new System.Drawing.Point(198, 84);
            this.TbxSecond.Name = "TbxSecond";
            this.TbxSecond.Size = new System.Drawing.Size(100, 20);
            this.TbxSecond.TabIndex = 34;
            // 
            // TbxFirst
            // 
            this.TbxFirst.Location = new System.Drawing.Point(22, 84);
            this.TbxFirst.Name = "TbxFirst";
            this.TbxFirst.Size = new System.Drawing.Size(100, 20);
            this.TbxFirst.TabIndex = 33;
            // 
            // FrmCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 176);
            this.Controls.Add(this.LblResult);
            this.Controls.Add(this.LblSecond);
            this.Controls.Add(this.LblFirst);
            this.Controls.Add(this.LblEquals);
            this.Controls.Add(this.BtnDivide);
            this.Controls.Add(this.BtnMultiply);
            this.Controls.Add(this.BtnSubtract);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.TbxResult);
            this.Controls.Add(this.TbxSecond);
            this.Controls.Add(this.TbxFirst);
            this.Name = "FrmCalculator";
            this.Text = "Basic calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label LblResult;
        internal System.Windows.Forms.Label LblSecond;
        internal System.Windows.Forms.Label LblFirst;
        internal System.Windows.Forms.Label LblEquals;
        internal System.Windows.Forms.Button BtnDivide;
        internal System.Windows.Forms.Button BtnMultiply;
        internal System.Windows.Forms.Button BtnSubtract;
        internal System.Windows.Forms.Button BtnAdd;
        internal System.Windows.Forms.TextBox TbxResult;
        internal System.Windows.Forms.TextBox TbxSecond;
        internal System.Windows.Forms.TextBox TbxFirst;
    }
}


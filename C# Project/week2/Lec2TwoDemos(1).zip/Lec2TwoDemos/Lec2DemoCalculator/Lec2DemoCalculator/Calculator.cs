﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec2DemoCalculator
{
    // Simon, May 2015
    // Last updated August 2021
    // A simple calculator to illustrate
    //     arithmetic, variables, textbox I/O, comments, message boxes.
    // Each handler uses a slightly different approach.
    // No one approach is clearly the best.

    public partial class FrmCalculator : Form
    {
        public FrmCalculator()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // Add the contents of TbxFirst and TbxSecond.
            // Display the result in TbxResult and the whole expression
            //   in a MessageBox.
            // Use variables for all arithmetic.
            double dOne, dTwo, dResult;
            dOne = Convert.ToDouble(TbxFirst.Text);
            dTwo = Convert.ToDouble(TbxSecond.Text);
            dResult = dOne + dTwo;
            TbxResult.Text = Convert.ToString(dResult);
            MessageBox.Show(Convert.ToString(dOne) + " + " + Convert.ToString(dTwo) + " = " +
                Convert.ToString(dResult), "Addition");
        }

        private void BtnSubtract_Click(object sender, EventArgs e)
        {
            // Subtract the contents of TbxFirst and TbxSecond.
            // Display the result in TbxResult and the whole expression in
            //   a MessageBox.
            // Do arithmetic directly from the textboxes.
            // Convert strings to double, do arithmetic, then convert result
            //   to a string (twice) for display.
            TbxResult.Text = Convert.ToString(Convert.ToDouble(TbxFirst.Text)
                    - Convert.ToDouble(TbxSecond.Text));
            MessageBox.Show(TbxFirst.Text + " - " + TbxSecond.Text + " = "
                + Convert.ToString(Convert.ToDouble(TbxFirst.Text)
                    - Convert.ToDouble(TbxSecond.Text)), "Subtraction");
        }

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            // Multiply the contents of TbxFirst and TbxSecond.
            // Display the result in TbxResult and the whole expression in
            //   a MessageBox.
            // Do arithmetic directly from the textboxes.
            // Use a variable for the result to avoid double calculation.
            string sResult;
            sResult = Convert.ToString(Convert.ToDouble(TbxFirst.Text)
                        * Convert.ToDouble(TbxSecond.Text));
            TbxResult.Text = sResult;
            MessageBox.Show(TbxFirst.Text + " * " + TbxSecond.Text + " = " +
                    sResult, "Multiplication");
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            // Divide the contents of TbxFirst by the contents of TbxSecond.
            // Display the result in TbxResult and the whole expression in
            //   a MessageBox.
            // Use variables for everything - definite overkill!
            string sOne, sTwo, sResult, sExpression;
            double dOne, dTwo, dResult;
            sOne = TbxFirst.Text;
            sTwo = TbxSecond.Text;
            dOne = Convert.ToDouble(sOne);
            dTwo = Convert.ToDouble(sTwo);
            dResult = dOne / dTwo;
            sResult = Convert.ToString(dResult);
            TbxResult.Text = sResult;
            sExpression = sOne + " / " + sTwo;
            sExpression = sExpression + " = " + sResult; // Concatenating to itself
            MessageBox.Show(sExpression, "Division");
        }

    }
}

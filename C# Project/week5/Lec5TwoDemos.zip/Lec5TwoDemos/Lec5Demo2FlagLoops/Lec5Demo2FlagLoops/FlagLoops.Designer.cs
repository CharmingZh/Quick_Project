﻿namespace Lec5Demo2FlagLoops
{
    partial class FrmFlagLoops
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnChangeLocAndSize = new System.Windows.Forms.Button();
            this.BtnFancierChange = new System.Windows.Forms.Button();
            this.BtnTenFlags = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnChangeLocation = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.PicbxPaper = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicbxPaper)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnChangeLocAndSize
            // 
            this.BtnChangeLocAndSize.Location = new System.Drawing.Point(19, 297);
            this.BtnChangeLocAndSize.Name = "BtnChangeLocAndSize";
            this.BtnChangeLocAndSize.Size = new System.Drawing.Size(96, 23);
            this.BtnChangeLocAndSize.TabIndex = 40;
            this.BtnChangeLocAndSize.Text = "Change size too";
            this.BtnChangeLocAndSize.Click += new System.EventHandler(this.BtnChangeLocAndSize_Click);
            // 
            // BtnFancierChange
            // 
            this.BtnFancierChange.Location = new System.Drawing.Point(19, 265);
            this.BtnFancierChange.Name = "BtnFancierChange";
            this.BtnFancierChange.Size = new System.Drawing.Size(96, 23);
            this.BtnFancierChange.TabIndex = 39;
            this.BtnFancierChange.Text = "Fancier change";
            this.BtnFancierChange.Click += new System.EventHandler(this.BtnFancierChange_Click);
            // 
            // BtnTenFlags
            // 
            this.BtnTenFlags.Location = new System.Drawing.Point(19, 170);
            this.BtnTenFlags.Name = "BtnTenFlags";
            this.BtnTenFlags.Size = new System.Drawing.Size(96, 23);
            this.BtnTenFlags.TabIndex = 38;
            this.BtnTenFlags.Text = "Ten flags";
            this.BtnTenFlags.Click += new System.EventHandler(this.BtnTenFlags_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.Location = new System.Drawing.Point(27, 337);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(80, 23);
            this.BtnQuit.TabIndex = 37;
            this.BtnQuit.Text = "Quit";
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(27, 201);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(80, 23);
            this.BtnClear.TabIndex = 36;
            this.BtnClear.Text = "Clear screen";
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnChangeLocation
            // 
            this.BtnChangeLocation.Location = new System.Drawing.Point(19, 233);
            this.BtnChangeLocation.Name = "BtnChangeLocation";
            this.BtnChangeLocation.Size = new System.Drawing.Size(96, 23);
            this.BtnChangeLocation.TabIndex = 35;
            this.BtnChangeLocation.Text = "Change location";
            this.BtnChangeLocation.Click += new System.EventHandler(this.BtnChangeLocation_Click);
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(11, 121);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(144, 40);
            this.Label2.TabIndex = 34;
            this.Label2.Text = "It was officially proclaimed as a flag of Australia in 1995.";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(11, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(144, 104);
            this.Label1.TabIndex = 33;
            this.Label1.Text = "Designed by Harold Thomas in 1971, this flag was adopted nationally by Aboriginal" +
    " and Torres Strait Islander People in 1972 after being flown over the Aboriginal" +
    " tent embassy in Canberra.";
            // 
            // PicbxPaper
            // 
            this.PicbxPaper.BackColor = System.Drawing.Color.SandyBrown;
            this.PicbxPaper.Location = new System.Drawing.Point(163, 17);
            this.PicbxPaper.Name = "PicbxPaper";
            this.PicbxPaper.Size = new System.Drawing.Size(330, 330);
            this.PicbxPaper.TabIndex = 32;
            this.PicbxPaper.TabStop = false;
            // 
            // FrmFlagLoops
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 377);
            this.Controls.Add(this.BtnChangeLocAndSize);
            this.Controls.Add(this.BtnFancierChange);
            this.Controls.Add(this.BtnTenFlags);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnChangeLocation);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.PicbxPaper);
            this.Name = "FrmFlagLoops";
            this.Text = "The Aboriginal Flag";
            ((System.ComponentModel.ISupportInitialize)(this.PicbxPaper)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button BtnChangeLocAndSize;
        internal System.Windows.Forms.Button BtnFancierChange;
        internal System.Windows.Forms.Button BtnTenFlags;
        internal System.Windows.Forms.Button BtnQuit;
        internal System.Windows.Forms.Button BtnClear;
        internal System.Windows.Forms.Button BtnChangeLocation;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.PictureBox PicbxPaper;
    }
}


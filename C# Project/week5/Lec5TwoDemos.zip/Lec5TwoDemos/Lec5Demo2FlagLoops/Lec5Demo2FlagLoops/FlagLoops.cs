﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec5Demo2FlagLoops
{
    public partial class FrmFlagLoops : Form
    {
        // Simon, May 2015
        // Last updated August 2021
        // Illustrating the use of the counter in for loops
        // Draw ten Aboriginal flags in various arrangements

        // Paper and brushes are used in most methods; if we declare them
        // here, every method throughout the module can access them.
        // private is generally used when declaring variables
        // for the whole class rather than within its methods.

        private SolidBrush brshBlack = new SolidBrush(Color.Black);
        private SolidBrush brshYellow = new SolidBrush(Color.Yellow);
        private SolidBrush brshRed = new SolidBrush(Color.Red);
        private Graphics graPaper;
        
        public FrmFlagLoops()
        {
            InitializeComponent();
            // When the form loads, instantiate and initialise the 'paper'
            graPaper = PicbxPaper.CreateGraphics();
        }

        private void Flag(int iLeft, int iTop, int iSize)
        {   // Draw an Aboriginal flag iLeft across, iTop down, and iSize wide
            // Flag's height is two-thirds its width.
            // Black rectangle at top left, full width, half height
            graPaper.FillRectangle(brshBlack, iLeft, iTop, iSize, iSize / 3);
            // Red rectangle halfway down left, full width, half height
            graPaper.FillRectangle(brshRed, iLeft, iTop + iSize / 3,
                iSize, iSize / 3);
            // Yellow circle one-third across, one-sixth down, one-third
            // width and height
            graPaper.FillEllipse(brshYellow, iLeft + iSize / 3,
                iTop + iSize / 6, iSize / 3, iSize / 3);
        }  // end of flag

        private void BtnClear_Click(object sender, EventArgs e)
        {
            // Clear the paper back to the original colour.
            // Note that this is not the way it was done in the previous version.
            graPaper.Clear(Color.SandyBrown);
        }

        private void BtnTenFlags_Click(object sender, EventArgs e)
        {
            // Use a for loop to draw 10 Aboriginal flags
            for (int i = 1; i <= 10; i++)
            {
                Flag(30, 30, 30);
            }
        }

        private void BtnChangeLocation_Click(object sender, EventArgs e)
        {
            // Draw 10 flags, but use the loop counter to give each one a different location
            for (int i = 1; i <= 10; i++)
            {
                Flag(30 * i, 30 * i, 30);
            }
        }

        private void BtnFancierChange_Click(object sender, EventArgs e)
        {
            // Draw 10 flags, but use the loop counter to give each one a different
            // location in a more complex pattern
            int iAcross = 0; // Initialised because from now on we refer to its previous value
            for (int i = 1; i <= 10; i++)
            {
                if (i == 4 || i == 8)
                {
                    iAcross = iAcross - 40;
                }
                else
                {
                    iAcross = iAcross + 40;
                }
                Flag(iAcross, 30 * i, 30);
            }
        }

        private void BtnChangeLocAndSize_Click(object sender, EventArgs e)
        {
            // Draw 10 flags, but use the loop counter to give each one a different
            // location and a different size
            int iAcross = 0, iDown = 0; // Initialised because from now on we refer to their previous values
            for (int i = 1; i <= 10; i++)
            {
                // Draw a flag whose size (width) is 9 times the loop counter
                Flag(iAcross, iDown, i * 9);
                // Add the flag width to the across coordinate, but wrap round after 220
                iAcross = (iAcross + i * 9) % 220;
                // Add flag height (2/3 of width, ie 6 * loop counter) to the down coordinate
                iDown = iDown + 6 * i;
            }

        }

        private void BtnQuit_Click(object sender, EventArgs e)
        {
            // The preferred way of finishing a running program
            Application.Exit();
        }
    }
}

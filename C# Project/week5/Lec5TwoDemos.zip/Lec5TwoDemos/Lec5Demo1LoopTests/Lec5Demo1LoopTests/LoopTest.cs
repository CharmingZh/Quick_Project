﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec5Demo1LoopTests
{
    public partial class FrmLoopTest : Form
    {
        // Simon, May 2015
        // Last updated August 2021
        // Test while, do-while, and for loops as in the lecture

        public FrmLoopTest()
        {
            InitializeComponent();
        }

        private int LimitingValue() // a function method, of type int
        {
            // Get the limit from the textbox - or 0 if there's none there
            // This is an int function method, and returns the value
            try
            {
                return Convert.ToInt32(TbxLimit.Text);
            }
            catch
            // Note that we don't have to specify an Exception or its type
            {
                MessageBox.Show("Please put a whole number in the Limiting value box", "Missing data");
                return 0;
            }
        } // end LimitingValue

        private void BtnWhile_Click(object sender, EventArgs e)
        {
            // Display numbers and squares while squares are below specified limit
            // This next line is a function call; the value is returned to the right side
            // of the assigmment, and is then assigned to the variable on the left.
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            int i = 1;
            int iSquare = 1;
            while (iSquare < iLimit)
            {
                TbxOutput.AppendText(String.Format("{0:d}   {1:d}\r\n", i, iSquare));
                i = i + 1;
                iSquare = i * i;
            }
        }  // end BtnWhile_Click

        private void BtnDoWhile_Click(object sender, EventArgs e)
        {
            // Display numbers and squares until square exceeds specified limit
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            int i = 0;
            int iSquare;
            do
            {
                i = i + 1;
                iSquare = i * i;
                TbxOutput.AppendText(String.Format("{0:d}   {1:d}\r\n", i, iSquare));
            }
            while (iSquare < iLimit);
        }  // end BtnDoWhile_Click

        private void BtnFor_Click(object sender, EventArgs e)
        {
            // Display numbers up to specified limit and their squares
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            int iSquare;
            for (int i = 1; i <= iLimit; i++)
            {
                iSquare = i * i;
                TbxOutput.AppendText(String.Format("{0:d}   {1:d}\r\n", i, iSquare));
            }
        }  // end BtnFor_Click

        private void BtnNestedFor_Click(object sender, EventArgs e)
        {
            // Simple illustration of a loop within a loop
            int iFactorial;
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            for (int i = 1; i <= iLimit; i++)
            {
                iFactorial = 1;
                for (int j = 1; j <= i; j++)
                {
                    iFactorial = iFactorial * j;
                } // end for j
                TbxOutput.AppendText(String.Format("{0:d}! is {1:d}\r\n", i, iFactorial));
            }  // end for i
        }  // end BtnNestedFor_Click

        private void BtnWhile2_Click(object sender, EventArgs e)
        {
            // A simple while loop, 1 to limiting value
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            int i = 1;
            while (i < iLimit)
            {
                TbxOutput.AppendText(String.Format("{0:d}\r\n", i));
                i = i + 1;
            }
        }  // end BtnWhile2_Click

        private void BtnDoWhile2_Click(object sender, EventArgs e)
        {
            // A simple do-while loop, 1 to limiting value
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            int i = 0;
            do
            {
                i = i + 1;
                TbxOutput.AppendText(String.Format("{0:d}\r\n", i));
            }
            while (i <= iLimit);
        }  // end BtnDoWhile2_Click

        private void BtnFor2_Click(object sender, EventArgs e)
        {
            // A simple for loop, 1 to limiting value
            int iLimit = LimitingValue();
            TbxOutput.Clear();
            for (int i = 1; i <= iLimit; i++)
            {
                TbxOutput.AppendText(String.Format("{0:d}\r\n", i));
            }
        }  // end BtnFor2_Click
    }  // end Class frmLoopTest
}  //  end Namespace

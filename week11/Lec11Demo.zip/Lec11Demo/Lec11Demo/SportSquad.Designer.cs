﻿namespace Lec11Demo
{
    partial class SportSquad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnDelete = new System.Windows.Forms.Button();
            this.TbxPhone = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnNewPlayer = new System.Windows.Forms.Button();
            this.TbxRating = new System.Windows.Forms.TextBox();
            this.TbxFeesOwing = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnPrevious = new System.Windows.Forms.Button();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.TbxHealth = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.TbxBehaviour = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.TbxGamesPlayed = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.TbxPosition = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.ChbxSelect = new System.Windows.Forms.CheckBox();
            this.LsbCurrentTeam = new System.Windows.Forms.ListBox();
            this.BtnNext = new System.Windows.Forms.Button();
            this.BtnPlayGame = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnPayFees = new System.Windows.Forms.Button();
            this.LblPlayerNum = new System.Windows.Forms.Label();
            this.BtnReturn = new System.Windows.Forms.Button();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(202, 344);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(90, 23);
            this.BtnDelete.TabIndex = 44;
            this.BtnDelete.Text = "Delete player";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // TbxPhone
            // 
            this.TbxPhone.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxPhone.Location = new System.Drawing.Point(120, 48);
            this.TbxPhone.Name = "TbxPhone";
            this.TbxPhone.ReadOnly = true;
            this.TbxPhone.Size = new System.Drawing.Size(152, 20);
            this.TbxPhone.TabIndex = 2;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(24, 24);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(35, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Name";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BtnNewPlayer
            // 
            this.BtnNewPlayer.Location = new System.Drawing.Point(202, 377);
            this.BtnNewPlayer.Name = "BtnNewPlayer";
            this.BtnNewPlayer.Size = new System.Drawing.Size(90, 23);
            this.BtnNewPlayer.TabIndex = 43;
            this.BtnNewPlayer.Text = "New player";
            this.BtnNewPlayer.UseVisualStyleBackColor = true;
            this.BtnNewPlayer.Click += new System.EventHandler(this.BtnNewPlayer_Click);
            // 
            // TbxRating
            // 
            this.TbxRating.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxRating.Location = new System.Drawing.Point(120, 246);
            this.TbxRating.Name = "TbxRating";
            this.TbxRating.ReadOnly = true;
            this.TbxRating.Size = new System.Drawing.Size(152, 20);
            this.TbxRating.TabIndex = 10;
            // 
            // TbxFeesOwing
            // 
            this.TbxFeesOwing.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxFeesOwing.Location = new System.Drawing.Point(120, 72);
            this.TbxFeesOwing.Name = "TbxFeesOwing";
            this.TbxFeesOwing.ReadOnly = true;
            this.TbxFeesOwing.Size = new System.Drawing.Size(152, 20);
            this.TbxFeesOwing.TabIndex = 15;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(24, 48);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(38, 13);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Phone";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BtnPrevious
            // 
            this.BtnPrevious.Location = new System.Drawing.Point(42, 344);
            this.BtnPrevious.Name = "BtnPrevious";
            this.BtnPrevious.Size = new System.Drawing.Size(24, 23);
            this.BtnPrevious.TabIndex = 37;
            this.BtnPrevious.Text = "<";
            this.BtnPrevious.UseVisualStyleBackColor = true;
            this.BtnPrevious.Click += new System.EventHandler(this.BtnPrevious_Click);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.TbxRating);
            this.GroupBox1.Controls.Add(this.TbxPhone);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Controls.Add(this.TbxFeesOwing);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.TbxHealth);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.TbxBehaviour);
            this.GroupBox1.Controls.Add(this.Label4);
            this.GroupBox1.Controls.Add(this.TbxGamesPlayed);
            this.GroupBox1.Controls.Add(this.Label5);
            this.GroupBox1.Controls.Add(this.TbxPosition);
            this.GroupBox1.Controls.Add(this.Label6);
            this.GroupBox1.Controls.Add(this.Label7);
            this.GroupBox1.Controls.Add(this.TbxName);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Controls.Add(this.ChbxSelect);
            this.GroupBox1.Location = new System.Drawing.Point(20, 19);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(288, 308);
            this.GroupBox1.TabIndex = 36;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Current squad members";
            // 
            // TbxHealth
            // 
            this.TbxHealth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxHealth.Location = new System.Drawing.Point(120, 96);
            this.TbxHealth.Multiline = true;
            this.TbxHealth.Name = "TbxHealth";
            this.TbxHealth.ReadOnly = true;
            this.TbxHealth.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxHealth.Size = new System.Drawing.Size(152, 48);
            this.TbxHealth.TabIndex = 3;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(24, 72);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(61, 13);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Fees owing";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbxBehaviour
            // 
            this.TbxBehaviour.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxBehaviour.Location = new System.Drawing.Point(120, 148);
            this.TbxBehaviour.Multiline = true;
            this.TbxBehaviour.Name = "TbxBehaviour";
            this.TbxBehaviour.ReadOnly = true;
            this.TbxBehaviour.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxBehaviour.Size = new System.Drawing.Size(152, 46);
            this.TbxBehaviour.TabIndex = 13;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(24, 96);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(70, 13);
            this.Label4.TabIndex = 3;
            this.Label4.Text = "Health issues";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbxGamesPlayed
            // 
            this.TbxGamesPlayed.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxGamesPlayed.Location = new System.Drawing.Point(120, 198);
            this.TbxGamesPlayed.Name = "TbxGamesPlayed";
            this.TbxGamesPlayed.ReadOnly = true;
            this.TbxGamesPlayed.Size = new System.Drawing.Size(152, 20);
            this.TbxGamesPlayed.TabIndex = 12;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(24, 152);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(87, 13);
            this.Label5.TabIndex = 4;
            this.Label5.Text = "Behaviour issues";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbxPosition
            // 
            this.TbxPosition.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxPosition.Location = new System.Drawing.Point(120, 222);
            this.TbxPosition.Name = "TbxPosition";
            this.TbxPosition.ReadOnly = true;
            this.TbxPosition.Size = new System.Drawing.Size(152, 20);
            this.TbxPosition.TabIndex = 4;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(24, 204);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(74, 13);
            this.Label6.TabIndex = 5;
            this.Label6.Text = "Games played";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(24, 228);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(89, 13);
            this.Label7.TabIndex = 6;
            this.Label7.Text = "Preferred position";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbxName
            // 
            this.TbxName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxName.Location = new System.Drawing.Point(120, 24);
            this.TbxName.Name = "TbxName";
            this.TbxName.ReadOnly = true;
            this.TbxName.Size = new System.Drawing.Size(152, 20);
            this.TbxName.TabIndex = 1;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(24, 252);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(72, 13);
            this.Label8.TabIndex = 7;
            this.Label8.Text = "Season rating";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ChbxSelect
            // 
            this.ChbxSelect.AutoSize = true;
            this.ChbxSelect.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ChbxSelect.Location = new System.Drawing.Point(24, 284);
            this.ChbxSelect.Name = "ChbxSelect";
            this.ChbxSelect.Size = new System.Drawing.Size(123, 17);
            this.ChbxSelect.TabIndex = 8;
            this.ChbxSelect.Text = "Select for next game";
            this.ChbxSelect.UseVisualStyleBackColor = true;
            this.ChbxSelect.CheckedChanged += new System.EventHandler(this.ChbxSelect_CheckedChanged);
            // 
            // LsbCurrentTeam
            // 
            this.LsbCurrentTeam.FormattingEnabled = true;
            this.LsbCurrentTeam.Location = new System.Drawing.Point(24, 24);
            this.LsbCurrentTeam.Name = "LsbCurrentTeam";
            this.LsbCurrentTeam.Size = new System.Drawing.Size(136, 264);
            this.LsbCurrentTeam.TabIndex = 18;
            // 
            // BtnNext
            // 
            this.BtnNext.Location = new System.Drawing.Point(152, 344);
            this.BtnNext.Name = "BtnNext";
            this.BtnNext.Size = new System.Drawing.Size(24, 23);
            this.BtnNext.TabIndex = 38;
            this.BtnNext.Text = ">";
            this.BtnNext.UseVisualStyleBackColor = true;
            this.BtnNext.Click += new System.EventHandler(this.BtnNext_Click);
            // 
            // BtnPlayGame
            // 
            this.BtnPlayGame.Location = new System.Drawing.Point(318, 344);
            this.BtnPlayGame.Name = "BtnPlayGame";
            this.BtnPlayGame.Size = new System.Drawing.Size(75, 23);
            this.BtnPlayGame.TabIndex = 41;
            this.BtnPlayGame.Text = "Play game";
            this.BtnPlayGame.UseVisualStyleBackColor = true;
            this.BtnPlayGame.Click += new System.EventHandler(this.BtnPlayGame_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.LsbCurrentTeam);
            this.GroupBox2.Location = new System.Drawing.Point(368, 19);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(184, 308);
            this.GroupBox2.TabIndex = 40;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Current selected team";
            // 
            // BtnPayFees
            // 
            this.BtnPayFees.Location = new System.Drawing.Point(410, 344);
            this.BtnPayFees.Name = "BtnPayFees";
            this.BtnPayFees.Size = new System.Drawing.Size(75, 23);
            this.BtnPayFees.TabIndex = 42;
            this.BtnPayFees.Text = "Pay fees";
            this.BtnPayFees.UseVisualStyleBackColor = true;
            this.BtnPayFees.Click += new System.EventHandler(this.BtnPayFees_Click);
            // 
            // LblPlayerNum
            // 
            this.LblPlayerNum.AutoSize = true;
            this.LblPlayerNum.Location = new System.Drawing.Point(72, 349);
            this.LblPlayerNum.Name = "LblPlayerNum";
            this.LblPlayerNum.Size = new System.Drawing.Size(66, 13);
            this.LblPlayerNum.TabIndex = 39;
            this.LblPlayerNum.Text = "Player 0 of 0";
            // 
            // BtnReturn
            // 
            this.BtnReturn.Location = new System.Drawing.Point(368, 377);
            this.BtnReturn.Name = "BtnReturn";
            this.BtnReturn.Size = new System.Drawing.Size(75, 23);
            this.BtnReturn.TabIndex = 45;
            this.BtnReturn.Text = "Return";
            this.BtnReturn.UseVisualStyleBackColor = true;
            this.BtnReturn.Click += new System.EventHandler(this.BtnReturn_Click);
            // 
            // SportSquad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 412);
            this.Controls.Add(this.BtnReturn);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnNewPlayer);
            this.Controls.Add(this.BtnPrevious);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.BtnNext);
            this.Controls.Add(this.BtnPlayGame);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.BtnPayFees);
            this.Controls.Add(this.LblPlayerNum);
            this.Name = "SportSquad";
            this.Text = "Sport squad";
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnDelete;
        internal System.Windows.Forms.TextBox TbxPhone;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button BtnNewPlayer;
        internal System.Windows.Forms.TextBox TbxRating;
        internal System.Windows.Forms.TextBox TbxFeesOwing;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnPrevious;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox TbxHealth;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox TbxBehaviour;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox TbxGamesPlayed;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TbxPosition;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox TbxName;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.CheckBox ChbxSelect;
        internal System.Windows.Forms.ListBox LsbCurrentTeam;
        internal System.Windows.Forms.Button BtnNext;
        internal System.Windows.Forms.Button BtnPlayGame;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Button BtnPayFees;
        internal System.Windows.Forms.Label LblPlayerNum;
        private System.Windows.Forms.Button BtnReturn;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec11Demo
{
    // Simon, June 2015, with thanks to David Foster
    // Last updated August 2021
    // Illustration of abstract classes, derived classes, inheritance . . .

    public partial class AddTeacher : Form
    {
        // Declare an Employee, which might yet be a Teacher, Secretary, or Cleaner
        Employee empNewStaffMember;

        public AddTeacher()
        {
            InitializeComponent();
        }

        private void BtnAddTeacher_Click(object sender, EventArgs e)
        {   // Add the details from the form to the new Employee, now known to be a Teacher
            // Start by instantiating the Employee as a Teacher
            empNewStaffMember = new Teacher(TbxFirstName.Text, TbxSurname.Text, TbxQual.Text,
                TbxPhone.Text, TbxExtn.Text, TbxCourse1.Text, TbxCourse2.Text,
                TbxCourse3.Text, DtpBirthdate.Value);

            // Form a string to display some information
            // First the instance attribute, which belongs to each instance
            string sMessage = String.Format("Employee number (instance): {0:d}", empNewStaffMember.iEmployeeNumber);
            // And the static attribute, which belongs to the whole class
            sMessage = sMessage + String.Format("\r\nNext employee number (static): {0:d}", Employee.iNextEmployeeNumber);
            MessageBox.Show(sMessage, "Instance and static attributes");
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Close this form and return to the main menu
            this.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec11Demo
{
    // Simon, June 2015, with thanks to David Foster
    // Last updated August 2021
    // Illustration of abstract classes, derived classes, inheritance . . .

    class Cleaner : Employee
    // Cleaner is a derived class of Employee
    {
        #region Private attributes

        // All attributes other than these
        // are inherited from Employee
        private string _sBuilding1;
        private string _sBuilding2;
        private string _sBuilding3;

        #endregion

        #region Public properties

        // All properties other than these
        // are inherited from Employee
        public string sCleansBuilding1
        {
            get
            {
                return _sBuilding1;
            }
            set
            {
                _sBuilding1 = value;
            }
        }

        public string sCleansBuilding2
        {
            get
            {
                return _sBuilding2;
            }
            set
            {
                _sBuilding2 = value;
            }
        }

        public string sCleansBuilding3
        {
            get
            {
                return _sBuilding3;
            }
            set
            {
                _sBuilding3 = value;
            }
        }

        #endregion

    } // end class
} // end namespace

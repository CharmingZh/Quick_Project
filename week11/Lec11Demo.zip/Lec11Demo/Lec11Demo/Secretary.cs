﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec11Demo
{
    // Simon, June 2015, with thanks to David Foster
    // Last updated August 2021
    // Illustration of abstract classes, derived classes, inheritance . . .

    class Secretary : Employee
    // Secretary is a derived class of Employee
    {
        #region Private attributes

        // All attributes other than these
        // are inherited from Employee
        private string _sFaculty;
        private string _sTeacher1;
        private string _sTeacher2;
        private string _sTeacher3;

        #endregion

        #region Public properties

        // All properties other than these
        // are inherited from Employee
        public string sInFaculty
        {
            get
            {
                return _sFaculty;
            }
            set
            {
                _sFaculty = value;
                _sFaculty = base.sGetName();  // What would this alternative do?
            }
        }

        public string sHelpsTeacher1
        {
            get
            {
                return _sTeacher1;
            }
            set
            {
                _sTeacher1 = value;
            }
        }

        public string sHelpsTeacher2
        {
            get
            {
                return _sTeacher2;
            }
            set
            {
                _sTeacher2 = value;
            }
        }

        public string sHelpsTeacher3
        {
            get
            {
                return _sTeacher3;
            }
            set
            {
                _sTeacher3 = value;
            }
        }

        #endregion

    } // end class
} // end namespace

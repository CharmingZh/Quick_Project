﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec11Demo
{
    class Player
    // Simon, June 2015
    // Last updated August 2021
    // Player class to demonstrate an array of objects
    {
        #region Private attributes
        // Prefixing each one with "_" makes it really easy to distinguish
        // between attributes and properties
        private string _sName, _sPhone, _sHealth, _sBehaviour, _sPosition;
        private double _dFeesOwing, _dRating;
        private int _iGamesPlayed;
        private bool _bSelected;
        #endregion

        #region Public properties
        public string sName
        { // Read-only, so if a player does change name, a new registration is required
            get
            {
                return _sName;
            }
        }

        public string sPhone
        { // Simple echo
            get
            {
                return _sPhone;
            }
            set
            {
                _sPhone = value;
            }
        }

        public string sHealth
        { // Simple echo
            get
            {
                return _sHealth;
            }
            set
            {
                _sHealth = value;
            }
        }

        public string sBehaviour
        { // Behaviour notations never go away; new ones just get added on
            get
            {
                return _sBehaviour;
            }
            set
            {
                if (value != "")
                    // If no new behaviour issues were entered, do nothing
                    if (_sBehaviour == "")
                    {  
                        _sBehaviour = value;
                    }
                    else
                    {
                        _sBehaviour = _sBehaviour + "\r\n" + value;
                    }
            }
        }

        public string sPosition
        { // Simple echo
            get
            {
                return _sPosition;
            }
            set
            {
                _sPosition = value;
            }
        }

        public double dFeesOwing
        { // myFeesOwing can be changed only by the PayFee method
            get
            {
                return _dFeesOwing;
            }
        }

        public double dRating
        { // myRating can be changed only by the NewRating method
            get
            {
                return _dRating;
            }
        }

        public int iGamesPlayed
        { // myGamesPlayed can be incremented only by the NewRating method
            get
            {
                return _iGamesPlayed;
            }
        }

        public bool bSelected
        { // Simple echo
            get
            {
                return _bSelected;
            }
            set
            {
                _bSelected = value;
            }
        }
        #endregion

        #region Constructors
        public Player(string sNewName, string sNewPhone, string sNewHealth, string sNewPosition)
        // The 'normal' constructor to be used on registration
        {
            _sName = sNewName;
            _sPhone = sNewPhone;
            _sHealth = sNewHealth;
            _sPosition = sNewPosition;
            // Default values for remaining attributes
            _sBehaviour = "";
            _dFeesOwing = 325;
            _dRating = 0;
            _iGamesPlayed = 0;
            _bSelected = false;
        }

        public Player(string sNewName, string sNewPhone, string sNewHealth,
            string sNewPosition, string sNewBehaviour, double dNewFeesOwing,
            double dNewRating, int iNewGamesPlayed, bool bNewSelected)
        // An extra constructor, just to populate some records for the demo
        {
            _sName = sNewName;
            _sPhone = sNewPhone;
            _sHealth = sNewHealth;
            _sPosition = sNewPosition;
            _sBehaviour = sNewBehaviour;
            _dFeesOwing = dNewFeesOwing;
            _dRating = dNewRating;
            _iGamesPlayed = iNewGamesPlayed;
            _bSelected = bNewSelected;
        }
        #endregion

        #region Public methods
        public void PayFee(double dPayment, out double dChange)
        // Accept a fee payment and return the amount of change owing
        {
            _dFeesOwing = _dFeesOwing - dPayment;
            if (_dFeesOwing >= 0)
            {
                dChange = 0;
            }
            else
            {
                dChange = -_dFeesOwing;
                _dFeesOwing = 0;
            }
        }

        public void NewRating(double dThisRating)
        // Make an average rating for the season by working in this rating
        // with the current season rating
        // It's important that this be done before incrementing the games,
        // so this method is the only one that does that increment.
        // _dRating * _iGamesPlayed gives a 'total rating' up to this game;
        // we add the rating for this game, then divide by the new number
        // of games to get the new average rating.
        {
            _dRating = (_dRating * _iGamesPlayed + dThisRating) / (_iGamesPlayed + 1);
            _iGamesPlayed = _iGamesPlayed + 1;
        }
        #endregion
    }
}

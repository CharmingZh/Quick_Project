﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec11Demo
{
    // Simon, June 2015, with thanks to David Foster
    // Last updated August 2021
    // Illustration of abstract classes, derived classes, inheritance . . .

    class Teacher : Employee
    // Teacher is a derived class of Employee
    {
        #region Private attributes

        // All attributes other than these
        // are inherited from Employee
        private string _sHighestQual;
        private string _sCourse1;
        private string _sCourse2;
        private string _sCourse3;

        #endregion

        #region Public properties

        // All properties other than these
        // are inherited from Employee
        public string sHighestQual
        {
            get
            {
                return _sHighestQual;
            }
            set
            {
                _sHighestQual = value;
            }
        }

        public string sCourse1
        {
            get
            {
                return _sCourse1;
            }
            set
            {
                _sCourse1 = value;
            }
        }

        public string sCourse2
        {
            get
            {
                return _sCourse2;
            }
            set
            {
                _sCourse2 = value;
            }
        }

        public string sCourse3
        {
            get
            {
                return _sCourse3;
            }
            set
            {
                _sCourse3 = value;
            }
        }

        #endregion

        #region Constructor

        public Teacher(string sFName, string sLName, string sQual, string sPhone, string sExt,
            string sCrse1, string sCrse2, string sCrse3, DateTime dateDob)
            : base(sFName, sLName, sPhone, sExt, dateDob) // A new Teacher is a new Employee . . .
        {
            // With some extra features . . .
            sHighestQual = sQual;
            sCourse1 = sCrse1;
            sCourse2 = sCrse2;
            sCourse3 = sCrse3;
        }

        #endregion

    } // end class
} // end namespace

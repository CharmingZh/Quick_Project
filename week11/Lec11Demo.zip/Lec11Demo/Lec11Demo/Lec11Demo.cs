﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec11Demo
{
    public partial class FrmLec11Demo : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Demonstrations of classes and objects for Inft2012

        public FrmLec11Demo()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {   // Halt the program
            Application.Exit();
        }

        private void BtnSportSquad_Click(object sender, EventArgs e)
        {   // Create and display a new SportSquad form
            SportSquad FrmSportSquad = new SportSquad();
            FrmSportSquad.ShowDialog();
        }

        private void BtnHumanResources_Click(object sender, EventArgs e)
        {   // Create and display a new AddTeacher form
            AddTeacher FrmAddTeacher = new AddTeacher();
            FrmAddTeacher.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec11Demo
{
    // Simon, June 2015, with thanks to David Foster
    // Last updated August 2021
    // Illustration of abstract classes, derived classes, inheritance . . .

    public abstract class Employee
    // A parent class for all types of employee
    {
        // A class-level variable
        public static int iNextEmployeeNumber = 1;

        #region Private attributes

        // These are instance variables
        private int _iEmpNum;
        private string _sFirstName;
        private string _sLastName;
        private string _sPhone;
        private string _sExtn;
        private DateTime _dtmDateOfBirth;

        #endregion

        #region Public properties

        public int iEmployeeNumber
        { // A read-only property
            get
            {
                return _iEmpNum;
            }
        }

        public string sFirstName
        {
            get
            {
                return _sFirstName;
            }
            set
            {
                _sFirstName = value;
            }
        }

        public string sLastame
        {
            get
            {
                return _sLastName;
            }
            set
            {
                _sLastName = value;
            }
        }

        public string sPhoneNumber
        {
            get
            {
                return _sPhone;
            }
            set
            {
                _sPhone = value;
            }
        }

        public string sExtension
        {
            get
            {
                return _sExtn;
            }
            set
            {
                _sExtn = value;
            }
        }

        public DateTime dtmBirthdate
        {
            get
            {
                return _dtmDateOfBirth;
            }
            set
            {
                _dtmDateOfBirth = value;
            }
        }

        #endregion

        #region Constructors

        public Employee(string sFName, string sLName, string sPhone,
            string sExt, DateTime dtmDob)
        // A constructor for Employee - subtype still unknown
        {
            _iEmpNum = iNextEmployeeNumber;
            iNextEmployeeNumber = iNextEmployeeNumber + 1;

            sFirstName = sFName;
            sLastame = sLName;
            sPhoneNumber = sPhone;
            sExtension = sExt;
            dtmBirthdate = dtmDob;
        }

        public Employee()
        // A default constructor with no parameters
        {
            _iEmpNum = iNextEmployeeNumber;
            iNextEmployeeNumber = iNextEmployeeNumber + 1;
        }

        #endregion

        #region Other methods

        protected string sGetName()
        {
            return sLastame + ", " + sFirstName;
        }

        #endregion

    }
}

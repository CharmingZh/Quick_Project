﻿namespace Lec11Demo
{
    partial class AddTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DtpBirthdate = new System.Windows.Forms.DateTimePicker();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnAddTeacher = new System.Windows.Forms.Button();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.TbxCourse3 = new System.Windows.Forms.TextBox();
            this.TbxCourse2 = new System.Windows.Forms.TextBox();
            this.TbxCourse1 = new System.Windows.Forms.TextBox();
            this.TbxExtn = new System.Windows.Forms.TextBox();
            this.TbxPhone = new System.Windows.Forms.TextBox();
            this.TbxQual = new System.Windows.Forms.TextBox();
            this.TbxSurname = new System.Windows.Forms.TextBox();
            this.TbxFirstName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // DtpBirthdate
            // 
            this.DtpBirthdate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpBirthdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtpBirthdate.Location = new System.Drawing.Point(182, 319);
            this.DtpBirthdate.Name = "DtpBirthdate";
            this.DtpBirthdate.Size = new System.Drawing.Size(234, 26);
            this.DtpBirthdate.TabIndex = 121;
            this.DtpBirthdate.Value = new System.DateTime(1960, 3, 9, 23, 37, 0, 0);
            // 
            // BtnClose
            // 
            this.BtnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClose.Location = new System.Drawing.Point(270, 399);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(152, 40);
            this.BtnClose.TabIndex = 120;
            this.BtnClose.Text = "Close";
            this.BtnClose.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnAddTeacher
            // 
            this.BtnAddTeacher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAddTeacher.Location = new System.Drawing.Point(46, 399);
            this.BtnAddTeacher.Name = "BtnAddTeacher";
            this.BtnAddTeacher.Size = new System.Drawing.Size(152, 40);
            this.BtnAddTeacher.TabIndex = 119;
            this.BtnAddTeacher.Text = "Add teacher";
            this.BtnAddTeacher.Click += new System.EventHandler(this.BtnAddTeacher_Click);
            // 
            // Label9
            // 
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(24, 321);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(152, 23);
            this.Label9.TabIndex = 118;
            this.Label9.Text = "Date of Birth";
            // 
            // Label8
            // 
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(24, 284);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(152, 23);
            this.Label8.TabIndex = 117;
            this.Label8.Text = "Course 3";
            // 
            // Label7
            // 
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(24, 247);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(152, 23);
            this.Label7.TabIndex = 116;
            this.Label7.Text = "Course 2";
            // 
            // Label6
            // 
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(24, 210);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(152, 23);
            this.Label6.TabIndex = 115;
            this.Label6.Text = "Course 1";
            // 
            // Label5
            // 
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(24, 173);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(152, 23);
            this.Label5.TabIndex = 114;
            this.Label5.Text = "Ext";
            // 
            // Label4
            // 
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(24, 136);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(152, 23);
            this.Label4.TabIndex = 113;
            this.Label4.Text = "Phone Number";
            // 
            // Label3
            // 
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(24, 99);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(152, 23);
            this.Label3.TabIndex = 112;
            this.Label3.Text = "Highest Qual";
            // 
            // Label2
            // 
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(24, 62);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(152, 23);
            this.Label2.TabIndex = 111;
            this.Label2.Text = "Surname";
            // 
            // Label1
            // 
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(24, 25);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(152, 23);
            this.Label1.TabIndex = 110;
            this.Label1.Text = "First Name";
            // 
            // TbxCourse3
            // 
            this.TbxCourse3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxCourse3.Location = new System.Drawing.Point(184, 282);
            this.TbxCourse3.Name = "TbxCourse3";
            this.TbxCourse3.Size = new System.Drawing.Size(232, 26);
            this.TbxCourse3.TabIndex = 109;
            // 
            // TbxCourse2
            // 
            this.TbxCourse2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxCourse2.Location = new System.Drawing.Point(184, 245);
            this.TbxCourse2.Name = "TbxCourse2";
            this.TbxCourse2.Size = new System.Drawing.Size(232, 26);
            this.TbxCourse2.TabIndex = 108;
            this.TbxCourse2.Text = "INFT2012";
            // 
            // TbxCourse1
            // 
            this.TbxCourse1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxCourse1.Location = new System.Drawing.Point(184, 208);
            this.TbxCourse1.Name = "TbxCourse1";
            this.TbxCourse1.Size = new System.Drawing.Size(232, 26);
            this.TbxCourse1.TabIndex = 107;
            this.TbxCourse1.Text = "INFT1004";
            // 
            // TbxExtn
            // 
            this.TbxExtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxExtn.Location = new System.Drawing.Point(184, 171);
            this.TbxExtn.Name = "TbxExtn";
            this.TbxExtn.Size = new System.Drawing.Size(64, 26);
            this.TbxExtn.TabIndex = 106;
            this.TbxExtn.Text = "1234";
            // 
            // TbxPhone
            // 
            this.TbxPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxPhone.Location = new System.Drawing.Point(184, 134);
            this.TbxPhone.Name = "TbxPhone";
            this.TbxPhone.Size = new System.Drawing.Size(152, 26);
            this.TbxPhone.TabIndex = 105;
            this.TbxPhone.Text = "02 9876 5432";
            // 
            // TbxQual
            // 
            this.TbxQual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxQual.Location = new System.Drawing.Point(184, 97);
            this.TbxQual.Name = "TbxQual";
            this.TbxQual.Size = new System.Drawing.Size(232, 26);
            this.TbxQual.TabIndex = 104;
            this.TbxQual.Text = "Master of Computing";
            // 
            // TbxSurname
            // 
            this.TbxSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxSurname.Location = new System.Drawing.Point(184, 60);
            this.TbxSurname.Name = "TbxSurname";
            this.TbxSurname.Size = new System.Drawing.Size(232, 26);
            this.TbxSurname.TabIndex = 103;
            this.TbxSurname.Text = "Foster";
            // 
            // TbxFirstName
            // 
            this.TbxFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxFirstName.Location = new System.Drawing.Point(184, 23);
            this.TbxFirstName.Name = "TbxFirstName";
            this.TbxFirstName.Size = new System.Drawing.Size(232, 26);
            this.TbxFirstName.TabIndex = 102;
            this.TbxFirstName.Text = "David";
            // 
            // AddTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 462);
            this.Controls.Add(this.DtpBirthdate);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnAddTeacher);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TbxCourse3);
            this.Controls.Add(this.TbxCourse2);
            this.Controls.Add(this.TbxCourse1);
            this.Controls.Add(this.TbxExtn);
            this.Controls.Add(this.TbxPhone);
            this.Controls.Add(this.TbxQual);
            this.Controls.Add(this.TbxSurname);
            this.Controls.Add(this.TbxFirstName);
            this.Name = "AddTeacher";
            this.Text = "Add a teacher";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker DtpBirthdate;
        internal System.Windows.Forms.Button BtnClose;
        internal System.Windows.Forms.Button BtnAddTeacher;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TbxCourse3;
        internal System.Windows.Forms.TextBox TbxCourse2;
        internal System.Windows.Forms.TextBox TbxCourse1;
        internal System.Windows.Forms.TextBox TbxExtn;
        internal System.Windows.Forms.TextBox TbxPhone;
        internal System.Windows.Forms.TextBox TbxQual;
        internal System.Windows.Forms.TextBox TbxSurname;
        internal System.Windows.Forms.TextBox TbxFirstName;
    }
}
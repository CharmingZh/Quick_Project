﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec11Demo
{
    public partial class InputBox : Form
    {   // Simon, June 2015
        // Last updated August 2021
        // This class provides an input box in the style of Visual Basic

        // It was added using Project / Add Windows Form

        public InputBox()
        {   // We've left the default constructor
            InitializeComponent();
        }

        public InputBox(string sPrompt, string sTitle)
        { // This constructor sets the prompt and title in the box
            // Trying to position the InputBox, but so far failing . . .
            //Point here = Cursor.Position;
            //this.Location = here;
            //MessageBox.Show(string.Format("Cursor position ({0:d}, {1:d})", here.X, here.Y));
            InitializeComponent();
            Text = sTitle;  // Text means the Text property of this form; it could have been written this.Text
            LblPrompt.Text = sPrompt;
        }

        public string sInputValue
        { // The InputValue property sets or gets the text in the text box
            get { return TbxInput.Text; }
            set { TbxInput.Text = value; }
        }
    }
}

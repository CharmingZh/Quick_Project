﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lec11Demo
{
    public partial class SportSquad : Form
    {
        // Simon, June 2015
        // Last updated August 2021
        // Illustration of an array of objects

        // An array of Players; we won't be using the one with index zero
        Player[] plrSquad = new Player[25];
        // iSquadSize is how many players we currently have
        // iCurrent is particularly important. At any one time we are dealing with (eg displaying,
        // updating) one of the squad. This variable maintains the index of that player, so
        // plrSquad[iCurrent] is always the player that we're dealing with.
        int iCurrent, iSquadSize;
        // A boolean to facilitate dual use of the New player button
        bool bEnteringData = false;
        // Background colour of the textboxes, for restoring after changing it
        Color clrOldBackColour;

        public SportSquad()
        {
            InitializeComponent();
            // On form load . . .
            // Remember the background colour of the textboxes, for restoring after changing it
            clrOldBackColour = TbxName.BackColor;
            // Instantiate & initialise the first 5 squad members (ignoring the one with index 0)
            plrSquad[1] = new Player("Sue Mee", "4325 1982", "", "wing", "", 325, 4.2, 7, true);
            plrSquad[2] = new Player("Yvonne Decker", "4348 5622", "", "short leg", "argues with umpire", 325, 5.6, 5, true);
            plrSquad[3] = new Player("Mark Mancktelow", "4385 3241", "bruised ribs", "short stop", "", 275, 8.5, 2, false);
            plrSquad[4] = new Player("Li Hwang Gao", "4325 9420", "asthma", "spiker", "", 0, 4, 1, true);
            plrSquad[5] = new Player("Eric Hopper", "4396 5178", "", "silly mid on", "short temper", 150, 6, 7, true);
            iCurrent = 1;   // Current player for display purposes
            iSquadSize = 5;    // Number of members currently in squad
            DisplayCurrentPlayer();
            DisplayTeam();
        }

        #region Displays
        private void DisplayCurrentPlayer()
        { // Display the current player (plrSquad[iCurrent]) on the form
            if (iCurrent > 0)
            { // The strings are a simple assignment
                TbxName.Text = plrSquad[iCurrent].sName;
                TbxPhone.Text = plrSquad[iCurrent].sPhone;
                TbxHealth.Text = plrSquad[iCurrent].sHealth;
                TbxPosition.Text = plrSquad[iCurrent].sPosition;
                TbxBehaviour.Text = plrSquad[iCurrent].sBehaviour;
                // The numbers need formatting
                TbxFeesOwing.Text = string.Format("{0:c}", plrSquad[iCurrent].dFeesOwing);
                TbxRating.Text = string.Format("{0:f1}", plrSquad[iCurrent].dRating);
                TbxGamesPlayed.Text = string.Format("{0:d}", plrSquad[iCurrent].iGamesPlayed);
                // The boolean determines the checked state of the checkbox
                ChbxSelect.Checked = plrSquad[iCurrent].bSelected;
            }
            else
            { // There are no squad members: clear the display
                TbxName.Clear();
                TbxPhone.Clear();
                TbxHealth.Clear();
                TbxPosition.Clear();
                TbxBehaviour.Clear();
                TbxFeesOwing.Clear();
                TbxRating.Clear();
                TbxGamesPlayed.Clear();
                ChbxSelect.Checked = false;
            }
            // Set the message between the navigation buttons
            LblPlayerNum.Text = string.Format("Player {0:d} of {1:d}", iCurrent, iSquadSize);
        }

        private void DisplayTeam()
        { // See which players are currently selected and list them in the listbox
            // First clear the listbox . . .
            LsbCurrentTeam.Items.Clear();
            for (int i = 1; i <= iSquadSize; i++)
            {
                if (plrSquad[i].bSelected)
                {
                    LsbCurrentTeam.Items.Add(plrSquad[i].sName);
                }
            }
        }
        #endregion

        #region Navigation
        private void BtnPrevious_Click(object sender, EventArgs e)
        { // Move to the previous player - or the last player if we're at the start
            iCurrent = iCurrent - 1;
            if (iCurrent <= 0) iCurrent = iSquadSize;
            DisplayCurrentPlayer();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        { // Move to the next player - or the first player if we're at the end
            iCurrent = iCurrent + 1;
            if (iCurrent > iSquadSize) iCurrent = 1;
            DisplayCurrentPlayer();
        }

        private void BtnNewPlayer_Click(object sender, EventArgs e)
        { // Dual purpose button; start and finish entering details of new player
            if (!bEnteringData) // The button has been clicked for a first time
            {
                bEnteringData = true;
                iCurrent = 0;  // To clear the display
                DisplayCurrentPlayer();
                // Permit the relevant textboxes to receive input
                TbxName.ReadOnly = false;
                TbxPhone.ReadOnly = false;
                TbxHealth.ReadOnly = false;
                TbxPosition.ReadOnly = false;
                // Give the relevant textboxes a highlight colour
                TbxName.BackColor = Color.PaleTurquoise;
                TbxPhone.BackColor = Color.PaleTurquoise;
                TbxHealth.BackColor = Color.PaleTurquoise;
                TbxPosition.BackColor = Color.PaleTurquoise;
                MessageBox.Show("Please enter name, phone, current health\r\nissues (if any), and preferred position, then\r\npress the New player button again", "New player");
            }
            else // The button has been clicked for a subsequent time
            {
                if (TbxName.Text == "" || TbxPhone.Text == "" || TbxPosition.Text == "")
                { // Some data still missing; note that Health issues are not obligatory
                    MessageBox.Show("Please enter name, phone, current health\r\nissues (if any), and preferred position, then\r\npress the New player button again", "New player");
                }
                else
                { // We're ready to instantiate and initialise the new player
                    bEnteringData = false;
                    iSquadSize = iSquadSize + 1;
                    iCurrent = iSquadSize;
                    plrSquad[iCurrent] = new Player(TbxName.Text, TbxPhone.Text,
                        TbxHealth.Text, TbxPosition.Text);
                    // Restore the textboxes to their former state
                    TbxName.ReadOnly = true;
                    TbxPhone.ReadOnly = true;
                    TbxHealth.ReadOnly = true;
                    TbxPosition.ReadOnly = true;
                    TbxName.BackColor = clrOldBackColour;
                    TbxPhone.BackColor = clrOldBackColour;
                    TbxHealth.BackColor = clrOldBackColour;
                    TbxPosition.BackColor = clrOldBackColour;
                    DisplayCurrentPlayer();
                }  // end of inner else (checking if required fields are filled)
            }  // end of outer else (checking if this was the first or second click of the button)
        }  // end of BtnNewPlayer_Click

        private void BtnDelete_Click(object sender, EventArgs e)
        {  // Delete the current player - after confirming
            if (iSquadSize < 1)
                MessageBox.Show("No players to delete", "No can do");
            else if (MessageBox.Show("Are you sure you want to delete " + plrSquad[iCurrent].sName + "?",
                "Double check", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                // Delete the player by moving all the subsequent players one position back in the array
                for (int i = iCurrent; i < iSquadSize; i++)
                    plrSquad[i] = plrSquad[i + 1];
                // Adjust the size of the squad
                iSquadSize = iSquadSize - 1;
                // Work out which player to display now
                if (iCurrent > iSquadSize) iCurrent = iSquadSize;
                DisplayCurrentPlayer();
                DisplayTeam();
            }
        }
        #endregion

        #region Operations on current player
        private void BtnPlayGame_Click(object sender, EventArgs e)
        { // Collect and update properties after a game
            // For convenience, use a custom-built InputBox
            plrSquad[iCurrent].sHealth = InputString("Health issues after game?", "Debrief");
            // How does this next assignment add any new issues to the existing ones?
            plrSquad[iCurrent].sBehaviour = InputString("Any new behaviour issues?", "Debrief");
            plrSquad[iCurrent].NewRating(InputDouble("Rating (/10) for this game?", "Debrief"));
            DisplayCurrentPlayer();
        }

        private void BtnPayFees_Click(object sender, EventArgs e)
        {  // Accept a fee payment and calculate any change required
            double dChange;
            plrSquad[iCurrent].PayFee(InputDouble("Amount tendered", "Fee payment"), out dChange);
            DisplayCurrentPlayer();
            if (dChange > 0)
                MessageBox.Show(string.Format("All fees now paid. Here's {0:c} change.", dChange), "Thank you");
            else
                MessageBox.Show("Payment received", "Thank you");
        }

        private void ChbxSelect_CheckedChanged(object sender, EventArgs e)
        {
            // If selection is checked or unchecked . . .
            // register the change - unless it's for Player 0
            if (iCurrent > 0)
                plrSquad[iCurrent].bSelected = ChbxSelect.Checked;
            // and refresh the current team display
            DisplayTeam();
        }
        #endregion

        #region InputBox methods
        private string InputString(string sPrompt, string sTitle)
        {   // Use a (custom-built) InputBox to get a string from the user
            InputBox inbox = new InputBox(sPrompt, sTitle);
            DialogResult drResult = inbox.ShowDialog();
            if (drResult == DialogResult.OK)
                return inbox.sInputValue;
            else  // Cancel button was pressed
                return "";
        }

        private double InputDouble(string sPrompt, string sTitle)
        {   // Use a (custom-built) InputBox to get a double from the user
            InputBox inbox = new InputBox(sPrompt, sTitle);
            // Display InputBox as a Dialog; result will be OK or Cancel
            DialogResult drResult = inbox.ShowDialog();
            if (drResult == DialogResult.OK)
                try
                {
                    return Convert.ToDouble(inbox.sInputValue);
                }
                catch (Exception ex)
                { // If the string won't convert, return 0
                    return 0;
                }
            else // Cancel button was pressed
                return 0;
        }
        #endregion

        private void BtnReturn_Click(object sender, EventArgs e)
        {   // Close this form and return to the main form
            this.Dispose();
        }

    } // end class
} // end namespace

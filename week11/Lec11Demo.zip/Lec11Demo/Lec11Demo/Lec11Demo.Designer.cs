﻿namespace Lec11Demo
{
    partial class FrmLec11Demo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSportSquad = new System.Windows.Forms.Button();
            this.BtnHumanResources = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnSportSquad
            // 
            this.BtnSportSquad.Location = new System.Drawing.Point(72, 40);
            this.BtnSportSquad.Name = "BtnSportSquad";
            this.BtnSportSquad.Size = new System.Drawing.Size(127, 23);
            this.BtnSportSquad.TabIndex = 0;
            this.BtnSportSquad.Text = "Sport squad";
            this.BtnSportSquad.UseVisualStyleBackColor = true;
            this.BtnSportSquad.Click += new System.EventHandler(this.BtnSportSquad_Click);
            // 
            // BtnHumanResources
            // 
            this.BtnHumanResources.Location = new System.Drawing.Point(72, 91);
            this.BtnHumanResources.Name = "BtnHumanResources";
            this.BtnHumanResources.Size = new System.Drawing.Size(127, 23);
            this.BtnHumanResources.TabIndex = 1;
            this.BtnHumanResources.Text = "Human resources";
            this.BtnHumanResources.UseVisualStyleBackColor = true;
            this.BtnHumanResources.Click += new System.EventHandler(this.BtnHumanResources_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.Location = new System.Drawing.Point(98, 145);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(75, 23);
            this.BtnExit.TabIndex = 2;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // FrmLec11Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnHumanResources);
            this.Controls.Add(this.BtnSportSquad);
            this.Name = "FrmLec11Demo";
            this.Text = "Lecture 11 demonstrations";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnSportSquad;
        private System.Windows.Forms.Button BtnHumanResources;
        private System.Windows.Forms.Button BtnExit;
    }
}

